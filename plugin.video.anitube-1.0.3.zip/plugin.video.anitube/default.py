"""Ponto de entrada do add-on de vídeo Kodi."""

import os
import sys
from urllib.parse import parse_qs, urlencode

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from resources.lib.catalog import Catalog
from resources.lib.source import BASE, SECTIONS, SourceError, kodi_url, resolve, site_url

PLUGIN_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
ADDON = xbmcaddon.Addon()
DIALOG = xbmcgui.Dialog()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))


def route(action, **params):
    return "{}?{}".format(PLUGIN_URL, urlencode({"action": action, **params}))


def add(label, action, folder=True, **params):
    entry = xbmcgui.ListItem(label=label)
    if action == "play":
        entry.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(HANDLE, route(action, **params), entry, folder)


def add_entries(entries, action, **params):
    for entry in entries:
        add(entry["label"], action, folder=action != "play", url=entry["url"], **params)


def notify(message):
    DIALOG.notification("AniTube", message, xbmcgui.NOTIFICATION_INFO, 5000)


def home():
    for label, url in SECTIONS.items():
        add(label, "catalog", url=url)
    add("Gêneros e temporadas", "categories")
    add("Buscar no catálogo salvo", "search")
    add("Sincronizar catálogos e episódios", "sync", folder=False)
    add("Sincronizar também os menus dos players", "sync", folder=False, players="1")


def page(catalog, action, url, **params):
    data, stale, _ = catalog.get_page(action, url)
    if stale:
        notify("Exibindo dados salvos. O site está indisponível.")
    if action == "catalog":
        if data["letters"]:
            add("Filtrar por letra", "letters", url=url)
        add_entries(data["items"], "episodes")
        if data["next"]:
            add("Próxima página", "catalog", url=data["next"])
    elif action == "episodes":
        add_entries(data["items"], "players")
    else:
        add_entries(data["items"], "play", episode=url)


def categories(catalog):
    entries = catalog.cached_entries("menus", ("home", "catalog"))
    if not entries:
        failures = 0
        for kind, url in [("home", BASE)] + [("catalog", url) for url in SECTIONS.values()]:
            try:
                catalog.get_page(kind, url)
            except SourceError:
                failures += 1
        entries = catalog.cached_entries("menus", ("home", "catalog"))
        if not entries:
            notify("O site está indisponível." if failures == 4
                   else "Nenhum gênero ou temporada foi encontrado.")
    add_entries(sorted(entries, key=lambda entry: entry["label"].casefold()), "catalog")


def sync(catalog, include_players):
    dialog = xbmcgui.DialogProgress()
    dialog.create("AniTube", "Preparando a sincronização")
    monitor = xbmc.Monitor()

    def progress(counts, pending):
        message = ("Páginas do catálogo: {pages}\nListas de episódios: {titles}\n"
                   "Menus de players: {players} · Pendentes: {pending}").format(pending=pending, **counts)
        completed = counts["pages"] + counts["titles"] + counts["players"]
        percent = int(100 * completed / max(1, completed + pending + 1))
        dialog.update(percent, message)

    def cancelled():
        return dialog.iscanceled() or monitor.abortRequested()

    try:
        counts = catalog.sync(progress, cancelled, lambda: monitor.waitForAbort(0.5),
                              include_players)
        if cancelled():
            status = "Sincronização interrompida"
        elif counts["paused"]:
            status = "Sincronização pausada após falhas consecutivas"
        elif counts["failed"] or counts["stale"]:
            status = "Sincronização concluída com dados indisponíveis"
        else:
            status = "Sincronização concluída"
    finally:
        dialog.close()
    DIALOG.ok("AniTube", ("{}\nPáginas de catálogo: {{pages}}\nListas de episódios: {{titles}}\n"
                         "Menus de players: {{players}}\nPáginas antigas reutilizadas: {{stale}}\n"
                         "Páginas indisponíveis no cache: {{failed}}").format(status).format(**counts))


def play(catalog, episode, target):
    data, _ = catalog.load("players", episode)
    if data is None or target not in {entry["url"] for entry in data["items"]}:
        raise SourceError("Essa opção não está na lista de players do episódio.")
    url, referer = resolve(target, data["referer"])
    xbmcplugin.setResolvedUrl(HANDLE, True, xbmcgui.ListItem(path=kodi_url(url, referer)))


def run():
    os.makedirs(PROFILE, exist_ok=True)
    catalog = Catalog(os.path.join(PROFILE, "catalog.sqlite3"))
    query = parse_qs(sys.argv[2].lstrip("?"))
    action = query.get("action", ["home"])[0]
    url = query.get("url", [""])[0]
    succeeded = True
    try:
        if action == "home":
            home()
        elif action in {"catalog", "episodes", "players", "letters"}:
            if not site_url("", url):
                raise SourceError("Esse endereço não pertence ao AniTube.")
            if action == "letters":
                data, _, _ = catalog.get_page("catalog", url)
                add_entries(data["letters"], "catalog")
            else:
                page(catalog, action, url)
        elif action == "search":
            term = DIALOG.input("Buscar no catálogo salvo")
            if term.strip():
                results = catalog.search(term)
                if not results:
                    notify("Nenhum título encontrado no catálogo salvo.")
                add_entries(results, "episodes")
        elif action == "categories":
            categories(catalog)
        elif action == "sync":
            sync(catalog, query.get("players") == ["1"])
        elif action == "play":
            play(catalog, query.get("episode", [""])[0], url)
        else:
            raise SourceError("Menu indisponível.")
    except SourceError as exc:
        succeeded = False
        xbmc.log("[AniTube] {}: {}".format(action, exc), xbmc.LOGWARNING)
        notify(str(exc))
        if action == "play":
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    finally:
        if action != "play":
            xbmcplugin.endOfDirectory(HANDLE, succeeded=succeeded, cacheToDisc=False)


if __name__ == "__main__":
    run()
