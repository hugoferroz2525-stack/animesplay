# AniTube para Kodi

Add-on de vídeo em português para Kodi 19 ou mais recente com Python 3. A instalação usa apenas a biblioteca padrão do Python e as APIs do Kodi.

## Instalação

1. No Kodi, abra **Add-ons → Instalar de um arquivo ZIP**.
2. Se solicitado, habilite **Fontes desconhecidas** nas configurações de add-ons.
3. Selecione `plugin.video.anitube-1.0.3.zip`.
4. Abra **Add-ons → Add-ons de vídeo → AniTube**.

## Navegação e sincronização

- **Animes legendados**, **Animes dublados** e **Doramas** usam as listagens públicas do AniTube. O add-on segue a paginação e mostra os filtros por letra quando estão disponíveis na página.
- **Gêneros e temporadas** mostra as categorias descobertas nos links públicos das páginas lidas.
- **Buscar no catálogo salvo** pesquisa títulos que já foram lidos, aceitando buscas sem acento.
- **Sincronizar catálogos e episódios** percorre as páginas descobertas e grava as listas de episódios.
- **Sincronizar também os menus dos players** inclui as opções de cada episódio. Essa etapa pode demorar em um catálogo grande. É possível cancelar e rodar novamente. Páginas recentes são reutilizadas e cada página é gravada assim que é processada. A sincronização faz uma pausa de meio segundo entre consultas ao site e encerra a sessão após cinco falhas consecutivas.

## Cache e reprodução

O Kodi guarda o cache em `special://profile/addon_data/plugin.video.anitube/catalog.sqlite3`. As categorias da página inicial têm validade de uma hora, as páginas de catálogo têm validade de um dia, as listas de episódios têm validade de seis horas e os menus dos players têm validade de 30 minutos. Após esse prazo, uma atualização malsucedida mantém a versão salva disponível.

O menu do episódio apresenta os players encontrados no HTML, incluindo SD, HD e FULLHD quando publicados. O resolvedor segue redirecionamentos HTTP e links públicos de continuação, além de reconhecer iframes, fontes de vídeo e alguns formatos de configuração declarativa. Um intermediário que dependa de JavaScript executável, CAPTCHA, autenticação ou DRM pode exigir interação do navegador.

O cache armazena títulos, listas e opções de player. Para reproduzir durante uma queda do AniTube, a opção precisa ter sido salva antes e o encurtador e o servidor de vídeo precisam continuar acessíveis. O add-on resolve a URL de mídia na hora de tocar.

## Verificação

Execute `python3 -m unittest discover -s tests -v` na raiz do projeto. Os testes usam páginas simuladas para percorrer o catálogo, as três opções de player, o fluxo do encurtador e o acesso ao cache após falha.

Durante o desenvolvimento, as rotas indexadas do site ainda apareciam nas buscas, mas a consulta ao domínio redirecionou para o Google. A cobertura do catálogo e a reprodução nos servidores reais ficaram pendentes de validação ao vivo.
