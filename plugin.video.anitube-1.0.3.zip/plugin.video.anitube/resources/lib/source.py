"""Leitura de páginas públicas e resolução de mídias declaradas pelos players."""

import gzip
import ipaddress
import json
import re
import socket
from html.parser import HTMLParser
from http.client import HTTPException
from io import BytesIO
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urljoin, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

BASE = "https://www.anitube.vip/"
HOSTS = {"www.anitube.vip", "anitube.vip"}
SECTIONS = {
    "Animes legendados": urljoin(BASE, "anime"),
    "Animes dublados": urljoin(BASE, "animes-dublado"),
    "Doramas": urljoin(BASE, "doramas"),
}
USER_AGENT = "Mozilla/5.0 (compatible; AniTubeKodi/1.0)"
LIMIT = 5 * 1024 * 1024
CATALOG_PATH = re.compile(
    r"^/(?:anime|animes-dublado|doramas|genero/[^/]+|temporada/[^/]+/\d{4})"
    r"(?:/page/\d+)?(?:/(?:[a-z]|0-9|all))?/?$", re.I
)
TITLE_PATH = re.compile(r"^/(?:anime|animes-dublado|doramas)/[^/]+/?$", re.I)
EPISODE_PATH = re.compile(r"^/video/\d+/?$|(?:^|[/_-])(?:episodios?|episode|ep)(?:[/_\s-]*\d|/)", re.I)
EPISODE_LABEL = re.compile(r"(?:^|\W)(?:epis[oó]dio|episode|ep)\s*[.:-]?\s*\d", re.I)
PLAYER_LABEL = re.compile(
    r"\b(?:player|op[cç][aã]o|servidor)(?:\s*(?:n[º°.]\s*)?(?:[0-9]+|full\s*hd|fhd|hd|sd|[a-z]))?\b", re.I
)
WATCH_LABEL = re.compile(
    r"^(?:(?:clique aqui para |continuar para |ir para o )?(?:assistir|player|v[ií]deo)"
    r"(?:\s+(?:agora|online|ao v[ií]deo))?|continuar|continue|watch(?: now)?|play"
    r"|(?:get|go to) (?:the )?link|(?:acessar|abrir|obter|gerar) (?:o )?link|prosseguir)$", re.I
)
MEDIA_TYPE = re.compile(r"^(?:video/|application/(?:x-mpegurl|vnd\.apple\.mpegurl|dash\+xml))", re.I)
QUALITY_LABEL = re.compile(r"(?:sd|hd|fhd|full\s*hd|\d{3,4}p)", re.I)
MEDIA_PATH = re.compile(r"\.(?:m3u8|mpd|mp4|webm|mkv|mov|m4v)$", re.I)


class SourceError(Exception):
    pass


def web_url(base, value):
    if not isinstance(value, str) or not value.strip() or value.lstrip().startswith("#"):
        return ""
    try:
        url = urljoin(base, value.strip()).split("#", 1)[0]
        parts = urlsplit(url)
        if (parts.scheme in ("http", "https") and parts.hostname and not parts.username
                and not parts.password and parts.port in (None, 80, 443)
                and not any(char.isspace() or ord(char) < 32 or char in "\\|" for char in url)):
            return url
    except ValueError:
        pass
    return ""


def site_url(base, value):
    url = web_url(base, value)
    return url if url and urlsplit(url).hostname in HOSTS else ""


def public_url(url, only_site=False):
    if not web_url("", url) or (only_site and not site_url("", url)):
        raise SourceError("O endereço está fora da origem permitida.")
    parts = urlsplit(url)
    try:
        addresses = socket.getaddrinfo(parts.hostname, parts.port or
                                       (443 if parts.scheme == "https" else 80),
                                       type=socket.SOCK_STREAM)
    except OSError as exc:
        raise SourceError("Não foi possível localizar o servidor.") from exc
    if not addresses or any(not ipaddress.ip_address(row[4][0]).is_global for row in addresses):
        raise SourceError("O servidor não fornece um endereço público.")


class Redirects(HTTPRedirectHandler):
    max_redirections = 6

    def __init__(self, only_site):
        self.only_site = only_site

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if self.only_site and not site_url("", newurl):
            raise SourceError("O AniTube redirecionou para outro domínio.")
        public_url(newurl, self.only_site)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def fetch(url, only_site=True, referer=""):
    public_url(url, only_site)
    headers = {"User-Agent": USER_AGENT}
    if referer:
        headers["Referer"] = referer
    try:
        opener = build_opener(Redirects(only_site))
        with opener.open(Request(url, headers=headers), timeout=10) as response:
            final = response.geturl()
            kind = response.headers.get_content_type()
            if MEDIA_TYPE.match(kind) or (kind == "application/octet-stream"
                                         and MEDIA_PATH.search(urlsplit(final).path)):
                return final, "", True
            if kind not in ("text/html", "application/xhtml+xml", "text/plain"):
                raise SourceError("O servidor respondeu com um formato desconhecido.")
            body = response.read(LIMIT + 1)
            if response.headers.get("Content-Encoding", "").lower() == "gzip":
                if len(body) > LIMIT:
                    raise SourceError("A página excede o tamanho permitido.")
                with gzip.GzipFile(fileobj=BytesIO(body)) as packed:
                    body = packed.read(LIMIT + 1)
            if len(body) > LIMIT:
                raise SourceError("A página excede o tamanho permitido.")
            encoding = response.headers.get_content_charset() or "utf-8"
            content = body.decode(encoding, errors="replace")
            if kind == "text/plain" and content.lstrip("\ufeff \t\r\n").startswith("#EXTM3U"):
                return final, "", True
            return final, content, False
    except HTTPError as exc:
        exc.close()
        raise SourceError("O servidor respondeu com HTTP {}.".format(exc.code)) from exc
    except URLError as exc:
        raise SourceError("Não foi possível conectar ao servidor ({}).".format(
            type(exc.reason).__name__)) from exc
    except (OSError, EOFError, HTTPException, LookupError, ValueError) as exc:
        raise SourceError("Não foi possível obter a página do servidor.") from exc


class Document(HTMLParser):
    """Coleta links, menus de player e metadados sem executar JavaScript."""

    def __init__(self, html):
        super().__init__(convert_charrefs=True)
        self.links = []
        self.elements = []
        self.choices = []
        self.next_links = []
        self.scripts = []
        self.panels = {}
        self.stack = []
        self.active_choices = []
        self.script = None
        self.feed(html)
        self.close()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        self.elements.append((tag, attrs))
        if tag in ("iframe", "video", "source"):
            for _, panel_id in self.stack + [(tag, attrs.get("id"))]:
                if panel_id:
                    for key in TARGET_ATTRS:
                        if attrs.get(key):
                            self.panels.setdefault(panel_id, attrs[key])
                            break
        if tag not in {"area", "base", "br", "col", "embed", "hr", "img", "input",
                       "link", "meta", "param", "source", "track", "wbr"}:
            self.stack.append((tag, attrs.get("id")))
        if tag in ("a", "button", "option", "li"):
            self.active_choices.append((len(self.stack), tag, attrs, [], []))
        elif tag == "img" and attrs.get("alt"):
            for _, _, _, _, images in self.active_choices:
                images.append(attrs["alt"])
        if tag == "link" and "next" in (attrs.get("rel") or "").lower().split():
            self.next_links.append(attrs.get("href"))
        if tag == "script":
            self.script = []

    def handle_endtag(self, tag):
        for index in range(len(self.stack) - 1, -1, -1):
            if self.stack[index][0] == tag:
                while self.active_choices and self.active_choices[-1][0] > index:
                    self.finish_choice()
                del self.stack[index:]
                break
        if tag == "script" and self.script is not None:
            self.scripts.append("".join(self.script))
            self.script = None

    def finish_choice(self):
        _, tag, attrs, words, images = self.active_choices.pop()
        label = (" ".join("".join(words).split()) or attrs.get("aria-label")
                 or attrs.get("title") or " ".join(images))
        if tag == "a":
            self.links.append((attrs, label))
        self.choices.append((attrs, label))

    def close(self):
        super().close()
        while self.active_choices:
            self.finish_choice()

    def handle_data(self, data):
        if self.script is None:
            for _, _, _, words, _ in self.active_choices:
                words.append(data)
        if self.script is not None:
            self.script.append(data)


def unique(items):
    entries = {}
    for entry in items:
        entries.setdefault(entry["url"], entry)
    return list(entries.values())


def item(label, url):
    return {"label": label, "url": url}


def parse_page(url, html, page_type):
    document = Document(html)
    items, menus, letters, next_page = [], [], [], ""
    root = urlsplit(url).path.rstrip("/")
    section = re.sub(r"/page/\d+.*$|/(?:[a-z]|0-9|all)$", "", root, flags=re.I)
    for attrs, label in document.links:
        link = site_url(url, attrs.get("href"))
        if not link or link == url:
            continue
        path = urlsplit(link).path.rstrip("/")
        rel = (attrs.get("rel") or "").lower().split()
        if "next" in rel or re.search(r"\b(?:pr[oó]xim[ao]|next)\b|^[›»]+$", label, re.I):
            if CATALOG_PATH.fullmatch(path) and (
                    path == section or path.startswith(section + "/")):
                next_page = next_page or link
        if not label:
            continue
        is_letter = re.fullmatch(r"[a-z]|0[-–]9|all|todos", label, re.I)
        if page_type == "catalog" and is_letter and CATALOG_PATH.fullmatch(path):
            if path == section or path.startswith(section + "/"):
                letters.append(item(label.upper(), link))
        elif page_type == "catalog" and TITLE_PATH.fullmatch(path) and not CATALOG_PATH.fullmatch(path):
            if label.casefold() not in {"download", "assistir", "baixar", "ver mais"}:
                items.append(item(label, link))
        elif page_type == "episodes" and (EPISODE_PATH.search(path) or EPISODE_LABEL.search(label)):
            if not CATALOG_PATH.fullmatch(path) and label.casefold() != "download":
                items.append(item(label, link))
        if CATALOG_PATH.fullmatch(path) and path.startswith(("/genero/", "/temporada/")):
            if not re.search(r"/page/\d+", path) and not is_letter and not label.isdecimal():
                menus.append(item(label, link))
    for value in document.next_links:
        link = site_url(url, value)
        if link and link != url:
            path = urlsplit(link).path.rstrip("/")
            if CATALOG_PATH.fullmatch(path) and (
                    path == section or path.startswith(section + "/")):
                next_page = link
                break
    return {"items": unique(items), "menus": unique(menus), "letters": unique(letters),
            "next": next_page}


TARGET_ATTRS = ("data-lazy-src", "data-src", "data-url", "data-href", "data-link", "data-player-url",
                "data-embed", "data-video", "data-iframe", "href", "src", "value")


def target_url(base, attrs):
    for key in TARGET_ATTRS:
        value = attrs.get(key)
        if key == "value" and value and not value.startswith(("http", "//", "/")):
            continue
        target = web_url(base, value)
        if target:
            return target
    return ""


def navigation_target(url, attrs):
    target = target_url(url, attrs)
    if not target:
        onclick = attrs.get("onclick") or ""
        literal = re.search(
            r"""(?:window\.open\(\s*|(?:window\.)?location(?:\.href)?\s*=\s*)['"]([^'"]+)""",
            onclick,
        )
        if literal:
            target = web_url(url, literal.group(1))
    return target


def player_options(url, html):
    document = Document(html)
    choices = []
    frames = []
    for tag, attrs in document.elements:
        if tag in ("iframe", "video", "source"):
            target = target_url(url, attrs)
            if target and target != url:
                frames.append(target)
    # Fragment targets are resolved using markup from the same page.
    for attrs, label in document.choices:
        match = PLAYER_LABEL.search(label) or QUALITY_LABEL.fullmatch(label)
        marker = " ".join(attrs.get(key) or "" for key in ("id", "class", "data-player"))
        target = navigation_target(url, attrs)
        fragment = attrs.get("data-bs-target") or attrs.get("data-target") or attrs.get("href") or ""
        if not target and fragment.startswith("#"):
            target = document.panels.get(fragment[1:], "")
            target = web_url(url, target)
        if target and target != url and (match or re.search(r"\bplayer[-_]?\d*\b", marker, re.I)):
            choices.append(item(label if match else "Player {}".format(len(choices) + 1),
                                target))
    if choices:
        return unique(choices)
    return unique([item("Player {}".format(index), target)
                   for index, target in enumerate(dict.fromkeys(frames), 1)])


def playback_candidates(url, html):
    document = Document(html)
    media, navigation, frames = [], [], []
    for tag, attrs in document.elements:
        target = ""
        destination = media
        if tag == "iframe":
            frame = target_url(url, attrs)
            if frame:
                frames.append(frame)
        elif tag in ("video", "source"):
            target = target_url(url, attrs)
        elif tag == "meta" and (attrs.get("http-equiv") or "").lower() == "refresh":
            destination = navigation
            match = re.search(r";\s*url\s*=\s*(.+)", attrs.get("content") or "", re.I)
            if match:
                target = web_url(url, match.group(1).strip(" \"'"))
        elif tag == "meta" and (attrs.get("property") or "").lower() in {
                "og:video", "og:video:url", "og:video:secure_url"}:
            target = web_url(url, attrs.get("content"))
        if target:
            destination.append(target)
    for script in document.scripts:
        for match in re.finditer(r'''["']?(?:file|src|source|contentUrl)["']?\s*:\s*(?:"([^"\n]+)"|'([^'\n]+)')''', script):
            value = match.group(1) or match.group(2)
            if match.group(1):
                try:
                    value = json.loads('"' + value + '"')
                except ValueError:
                    continue
            else:
                value = value.replace(r"\/", "/")
            target = web_url(url, value)
            if target and MEDIA_PATH.search(urlsplit(target).path):
                media.append(target)
        try:
            metadata = json.loads(script)
        except ValueError:
            continue
        if isinstance(metadata, dict) and metadata.get("@type") == "VideoObject":
            target = web_url(url, metadata.get("contentUrl"))
            if target:
                media.append(target)
    for attrs, label in document.choices:
        target = target_url(url, attrs)
        if target and MEDIA_PATH.search(urlsplit(target).path):
            media.append(target)
        elif WATCH_LABEL.fullmatch(label):
            target = navigation_target(url, attrs)
            if target:
                navigation.append(target)
    return list(dict.fromkeys(media + navigation + frames))


def resolve(target, referer, get=fetch):
    pending = [(target, referer, 0)]
    attempted, parsed = set(), set()
    while pending and len(attempted) < 16:
        current, parent, depth = pending.pop(0)
        if current in parsed or (current, parent) in attempted or depth > 8:
            continue
        attempted.add((current, parent))
        try:
            final, html, is_media = get(current, only_site=False, referer=parent)
        except SourceError:
            continue
        if is_media:
            return final, parent
        parsed.add(current)
        if final != current and final in parsed:
            continue
        parsed.add(final)
        pending[0:0] = [(child, final, depth + 1)
                        for child in playback_candidates(final, html) if child not in parsed]
    raise SourceError("O player não forneceu um vídeo reproduzível.")


def kodi_url(url, referer):
    return "{}|User-Agent={}&Referer={}".format(url, quote(USER_AGENT, safe=""),
                                               quote(referer, safe=""))
