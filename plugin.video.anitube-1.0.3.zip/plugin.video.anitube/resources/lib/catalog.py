"""Cache persistente e sincronização do catálogo."""

import json
import sqlite3
import time
import unicodedata
from collections import deque
from contextlib import closing

from .source import BASE, SECTIONS, SourceError, fetch, parse_page, player_options, unique

FRESHNESS = {"home": 3600, "catalog": 86400, "episodes": 21600, "players": 1800}


def searchable(value):
    normalized = unicodedata.normalize("NFKD", value.casefold())
    return "".join(char for char in normalized if not unicodedata.combining(char))


class Catalog:
    def __init__(self, database, get=fetch):
        self.database = database
        self.get = get
        with closing(self.connect()) as db, db:
            db.execute("""CREATE TABLE IF NOT EXISTS pages (
                kind TEXT NOT NULL, url TEXT NOT NULL, body TEXT NOT NULL,
                updated REAL NOT NULL, PRIMARY KEY (kind, url))""")

    def connect(self):
        return sqlite3.connect(self.database, timeout=10)

    def load(self, kind, url):
        with closing(self.connect()) as db:
            row = db.execute("SELECT body, updated FROM pages WHERE kind=? AND url=?",
                             (kind, url)).fetchone()
        return (json.loads(row[0]), row[1]) if row else (None, 0)

    def save(self, kind, url, data):
        with closing(self.connect()) as db, db:
            db.execute("""INSERT OR REPLACE INTO pages(kind, url, body, updated)
                VALUES (?, ?, ?, ?)""", (kind, url, json.dumps(data, ensure_ascii=False), time.time()))

    def get_page(self, kind, url):
        cached, timestamp = self.load(kind, url)
        if cached is not None and time.time() - timestamp < FRESHNESS[kind]:
            return cached, False, False
        try:
            final, html, media = self.get(url)
            if media:
                raise SourceError("O site retornou mídia no lugar de uma página.")
            if kind == "players":
                data = {"items": player_options(final, html), "referer": final}
            else:
                data = parse_page(final, html, kind)
            if kind == "players" and not data["items"]:
                raise SourceError("A página do episódio abriu, mas nenhum player foi identificado.")
            if not data["items"]:
                if kind != "home" or not data["menus"]:
                    raise SourceError("A página não apresentou entradas reconhecíveis.")
            self.save(kind, url, data)
            return data, False, True
        except SourceError:
            if cached is None:
                raise
            return cached, True, True

    def cached_entries(self, column, kinds):
        placeholders = ",".join("?" for _ in kinds)
        with closing(self.connect()) as db:
            rows = db.execute("SELECT body FROM pages WHERE kind IN (" + placeholders + ")",
                              kinds)
            return unique([entry for (body,) in rows
                           for entry in json.loads(body).get(column, [])])

    def search(self, query):
        terms = searchable(query).split()
        if not terms:
            return []
        matches = [entry for entry in self.cached_entries("items", ("catalog",))
                   if all(term in searchable(entry["label"]) for term in terms)]
        return sorted(matches, key=lambda entry: searchable(entry["label"]))

    def sync(self, progress, cancel, pause, include_players=False):
        queues = {kind: deque() for kind in ("home", "catalog", "episodes", "players")}
        seen = set()
        counts = {"pages": 0, "titles": 0, "players": 0, "stale": 0, "failed": 0, "paused": False}
        consecutive_failures = 0

        def enqueue(kind, url):
            key = (kind, url)
            if url and key not in seen:
                seen.add(key)
                queues[kind].append(url)

        enqueue("home", BASE)
        for url in SECTIONS.values():
            enqueue("catalog", url)
        while any(queues.values()) and not cancel():
            kind, queue = next((kind, queue) for kind, queue in queues.items() if queue)
            url = queue.popleft()
            progress(counts, sum(map(len, queues.values())))
            try:
                data, stale, requested = self.get_page(kind, url)
            except SourceError:
                counts["failed"] += 1
                consecutive_failures += 1
                if consecutive_failures >= 5:
                    counts["paused"] = True
                    break
                pause()
                continue
            counts["stale"] += int(stale)
            if requested:
                consecutive_failures = consecutive_failures + 1 if stale else 0
                if consecutive_failures >= 5:
                    counts["paused"] = True
                    break
            if kind == "catalog":
                counts["pages"] += 1
                enqueue("catalog", data["next"])
                all_pages = [entry for entry in data["letters"] if entry["label"] in {"ALL", "TODOS"}]
                for entry in all_pages or data["letters"]:
                    enqueue("catalog", entry["url"])
                for entry in data["items"]:
                    enqueue("episodes", entry["url"])
            elif kind == "episodes":
                counts["titles"] += 1
                if include_players:
                    for entry in data["items"]:
                        enqueue("players", entry["url"])
            elif kind == "players":
                counts["players"] += 1
            for entry in data.get("menus", []):
                enqueue("catalog", entry["url"])
            if requested:
                pause()
        return counts
