import json
import re
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from contextlib import closing
import os
import socket
import ssl
import sys
import time
from urllib.parse import urlencode, parse_qsl
from urllib.error import HTTPError, URLError
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
from animesplay.storage.library import Store
from animesplay.network.client import Client
from animesplay.sources.goyabu import Adapter
from animesplay.catalog.grouping import group, edition_audio, audio_editions, AUDIO_NAMES, SOURCE_NAMES
from animesplay.catalog.recommendations import suggest
from animesplay.playback.validation import MediaUnavailable
from animesplay.playback.engine import Engine, PlaybackCancelled, option_key
from animesplay.kodi.video_info import apply
from animesplay.kodi import diagnostics
from animesplay.metadata.tmdb import apply_saved, identify, db, saved_records, season_episode_records
from animesplay.metadata.tmdb import API, metadata_ttl
from animesplay.metadata.config import DEFAULT_API_KEY
from animesplay.storage.cache import Cache
from animesplay.kodi.routes import DIRECTORIES
from animesplay.storage.navigation import Navigation
from animesplay.kodi.presentation import episode_label, text
from animesplay.metadata.trailers import find_trailer
from animesplay.metadata.aniskip import Associations
from animesplay.sources.public_sites import AnimesOnlineCC, MetiAnimes
from animesplay.sources.websites import Digital, Sushi, Aniture, Onlines
from animesplay.metadata.enrichment import Enricher, normalized
from animesplay.storage.history import History, PENDING, media_key, public_episode

PAGE_SIZE = 24


def packed(item):
    return json.dumps(item, ensure_ascii=False, separators=(',', ':'))

class Plugin:

    def __init__(self, query=None):
        self.addon = xbmcaddon.Addon('plugin.video.animesplay')
        self.handle = int(sys.argv[1])
        self.base = 'plugin://plugin.video.animesplay/'
        self.profile = str(Path(xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))) / 'painel-goyabu')
        self.store = Store(self.profile)
        self.navigation = Navigation(self.profile)
        try:
            cache_ttl = (300, 900, 3600)[int(self.addon.getSetting('catalog_cache_minutes') or 1)]
        except (ValueError, TypeError, IndexError):
            cache_ttl = 900
        client_options = {'profile': self.profile, 'cache_enabled': self.addon.getSetting('catalog_cache_enabled') != 'false',
                          'cache_ttl': cache_ttl}
        self.source = Adapter(Client(**client_options))
        self.sources = {
            MetiAnimes.id: MetiAnimes(Client(timeout=25, **client_options)),
            'goyabu': self.source,
            **{cls.id:cls(Client(timeout=20, **client_options)) for cls in (Digital,Sushi,Aniture,Onlines)},
        }
        self.enricher = Enricher(self.profile, self.addon.getSetting('tmdb_token').strip() or DEFAULT_API_KEY, self.addon.getSetting('metadata_cache_enabled') != 'false')
        self.active_source = self.source
        self.args = query if query is not None else dict(parse_qsl(sys.argv[2][1:]))
        self.action = self.args.get('action', 'home')
        self.icon = self.addon.getAddonInfo('icon')
        self.fanart = self.addon.getAddonInfo('fanart')
        self.media_path = Path(__file__).resolve().parents[4] / 'resources/media'
        self.decorated = self.addon.getSetting('decorated_menus') != 'false'

    def menu(self, label, action, description='', key=None, **params):
        decorated = '[B][COLOR gold]>[/COLOR] [COLOR white]' + label + '[/COLOR][/B]' if self.decorated else label
        art_key='search' if (key or action)=='discover' else key or action
        icon = self.media_path / (art_key + '.jpg')
        if not icon.is_file():icon = self.media_path / ((key or action) + '.png')
        self.row(decorated, action, description=description, icon=str(icon) if icon.is_file() else None, **params)

    def adapter(self, item=None):
        provider = item.get('provider', 'goyabu') if item else self.args.get('provider', 'goyabu')
        if provider not in self.sources:
            raise ValueError('Fonte desconhecida.')
        self.active_source = self.sources[provider]
        return self.active_source

    def url(self, **kw):
        action=kw.pop('action','home');item=kw.pop('item',None)
        if item is not None and hasattr(self,'navigation'):
            key=self.navigation.put(json.loads(item) if isinstance(item,str) else item)
            return self.base+action+'/'+key+('?' + urlencode(kw) if kw else '')
        if item is not None:kw['item']=item
        return self.base+'?' + urlencode({'section':'goyabu','action':action,**kw})

    def context(self, item):
        source = item.get('url')
        extra = []
        if source:
            extra.append(('Associar metadados TMDB', 'RunPlugin(' + self.url(action='identify', item=packed(item)) + ')'))
        if item.get('mediatype') == 'tvshow':
            extra.append(('Ver trailer', 'RunPlugin(' + self.url(action='trailer', item=packed(item)) + ')'))
        if item.get('show_url'):
            parent = {'id': item['show_url'], 'url': item['show_url'], 'title': item.get('showtitle') or 'Anime',
                      'provider': item.get('provider', 'goyabu'), 'audio': item.get('audio', '')}
            extra.append(('Ver outros episódios', 'Container.Update(' + self.url(action='episodes', item=packed(parent)) + ')'))
        if item.get('show_url') and type(item.get('episode')) is int:
            next_url = self.url(action='next_episode', item=packed(item))
            extra.append(('Próximo episódio', 'Container.Update(' + next_url + ')'))
        if type(item.get('episode')) is int:
            extra.append(('Escolher player ou qualidade', 'RunPlugin(' + self.url(action='choose_player', item=packed(item)) + ')'))
            extra.append(('Configurar AniSkip neste episódio', 'RunPlugin(' +
                          self.url(action='aniskip', item=packed(item)) + ')'))
        return extra + [('Adicionar à minha lista', 'RunPlugin(' + self.url(action='favorite', item=packed(item)) + ')'), ('Configurações', 'Addon.OpenSettings(' + self.addon.getAddonInfo('id') + ')')]

    def row(self, label, action, folder=True, description='', icon=None, context_menu=None, item=None, records=None, section='goyabu', **kw):
        if label == 'Próxima página':
            page=int(kw.get('page',self.args.get('page',1)))+int(kw.get('offset',0))//PAGE_SIZE
            label='[COLOR yellow]Próxima página {}[/COLOR]'.format(page)
            description='Sua próxima aventura está na página {}. Continue explorando novos animes e episódios.'.format(page)
            icon=str(self.media_path/'next.jpg')
        if item and (item.get('mediatype')=='episode' or item.get('landing_episode')) and action in ('play','servers'):label=episode_label(item)
        label=text(label)
        li = xbmcgui.ListItem(label)
        li.setArt({'icon': icon or self.icon, 'thumb': icon or self.icon, 'fanart': self.fanart})
        if self.decorated and not item:
            li.setArt({'fanart': str(self.media_path / 'explore.jpg')})
        li.getVideoInfoTag().setPlot(description)
        if item:
            apply(li, item, xbmc)
            if item.get('url'):
                if records is None:
                    self.apply_item_metadata(li, item)
                elif item['url'] in records:
                    apply_saved(li, self.profile, item['url'], xbmc, record=records[item['url']])
            kw['item'] = packed(item)
        if label.startswith('[COLOR yellow]Próxima página '):
            li.getVideoInfoTag().setPlot(description)
            li.setArt({'icon':str(self.media_path/'next.jpg'),'thumb':str(self.media_path/'next.jpg'),'fanart':str(self.media_path/'explore.jpg')})
        if not folder and action == 'play':
            li.setProperty('IsPlayable', 'true')
        li.addContextMenuItems(context_menu or [('Configurações', 'Addon.OpenSettings(' + self.addon.getAddonInfo('id') + ')')])
        xbmcplugin.addDirectoryItem(self.handle, self.url(action=action, **kw) if section == 'goyabu' else self.base + '?section=animesbr', li, folder)

    def apply_item_metadata(self, li, item):
        source = item['url']
        parent = item.get('show_url')
        records = saved_records(self.profile, [source, parent])
        record = records.get(source) or season_episode_records(records.get(parent), [item]).get(source)
        if record:
            apply_saved(li, self.profile, source, xbmc, record=record)

    def listing(self, items, season=None):
        records = saved_records(self.profile, [item.get('url') for item in items])
        records = {**season_episode_records(season, items), **records}
        for item in items:
            episode = item.get('mediatype') == 'episode'
            action = 'play' if episode else 'servers'
            label = item['title']
            if episode or item.get('landing_episode'):label=episode_label(item)
            self.row(label, action, folder=not episode, icon=item.get('icon'), context_menu=self.context(item),
                     item=item, records=records, **({'choice':'auto'} if episode else {}))

    def local_page(self, items, more=False, **params):
        offset = max(0, int(self.args.get('offset', '0')))
        visible = items[offset:offset + PAGE_SIZE]
        if len(items) > offset + PAGE_SIZE:
            next_params = {**params, 'offset': offset + PAGE_SIZE}
        elif more and visible:
            next_params = {**params, 'page': int(params.get('page', 1)) + 1}
        else:
            next_params = None
        return visible, next_params

    def list_editions(self, item):
        choices = audio_editions(item.get('variants', [item]))
        expanded=[]
        for audio,variants in choices:
            if audio=='unknown':
                expanded.extend((kind,[dict(v,audio=kind) for v in variants]) for kind in ('dub','sub'))
            else:expanded.append((audio,variants))
        merged={}
        for audio,variants in expanded:merged.setdefault(audio,[]).extend(variants)
        for audio, variants in merged.items():
            self.row(AUDIO_NAMES[audio], 'sources', item=dict(item, variants=variants), icon=item.get('icon'))

    def list_sources(self, variants):
        for index, variant in enumerate(variants, 1):
            self.row('Servidor {}'.format(index), 'episodes', item=variant, icon=variant.get('icon'),
                     context_menu=self.context(variant))

    def open_sources(self):
        item = json.loads(self.args['item'])
        self.list_sources(item.get('variants', [item]))

    def show_options(self, item):
        options = self.adapter(item).options(item)
        if not options:
            xbmcgui.Dialog().notification('AnimesPlay', 'Nenhum player encontrado neste episódio')
            return
        self.row('[B]Reproduzir automaticamente[/B]', 'play', False, item=item, choice='auto')
        for option in options:
            self.row(option['label'], 'play', False, item=item, choice=option_key(option))

    def main(self):
        if self.action == 'choose_player':
            item=json.loads(self.args['item'])
            options=self.adapter(item).options(item)
            selected=xbmcgui.Dialog().contextmenu(['Player {}'.format(i+1) for i in range(len(options))])
            if 0 <= selected < len(options):
                xbmc.executebuiltin('PlayMedia('+self.url(action='play',item=packed(item),choice=option_key(options[selected]))+')')
            return
        if self.action == 'open_settings':
            self.addon.openSettings()
            return
        if self.action == 'diagnostics':
            diagnostics.show(self.profile)
            return
        if self.action == 'clear_catalog':
            cleared = self.source.client.clear_catalog()
            message = 'Cache do catálogo limpo.' if cleared else 'Não foi possível limpar o cache.'
            xbmcgui.Dialog().notification('AnimesPlay', message)
            return
        if self.action == 'clear_metadata_cache':
            cleared = Cache(self.profile).clear()
            xbmcgui.Dialog().notification('AnimesPlay', 'Cache TMDB limpo.' if cleared else 'Falha ao limpar cache TMDB.')
            return
        if self.action == 'aniskip':
            self.configure_aniskip(json.loads(self.args['item']))
            return
        if self.action == 'subtitles_help':
            if xbmc.getCondVisibility('Player.HasVideo'):
                xbmc.executebuiltin('ActivateWindow(subtitlesearch)')
            return
        if self.action == 'autoplay':
            current = json.loads(self.args['item'])
            item = self.adapter(current).next_episode(current)
            if item:
                self.play(item, interactive=False)
            else:
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        if self.action == 'identify':
            item = json.loads(self.args['item'])
            identify(self.profile, item['url'], item['title'], self.addon, xbmc, xbmcgui)
            return
        if self.action == 'trailer':
            item = json.loads(self.args['item'])
            self.show_trailer(item)
            return
        if self.action == 'remove':
            self.store.remove(self.args['id'])
            xbmc.executebuiltin('Container.Refresh')
            return
        if self.action == 'favorite':
            self.store.favorite(json.loads(self.args['item']))
            xbmcgui.Dialog().notification('Minha lista', 'Anime adicionado')
            return
        if self.action == 'play':
            self.play(json.loads(self.args['item']))
            return
        route = DIRECTORIES.get(self.action)
        if not route:
            raise ValueError('Rota desconhecida')
        getattr(self, route)()
        content = 'tvshows' if self.action in ('catalog','explore','latest_sources','latest','search','favorites','recommendations','discover','by_genre') else 'episodes' if self.action in ('episodes','continue') else 'files'
        xbmcplugin.setContent(self.handle, content)
        xbmcplugin.endOfDirectory(self.handle, cacheToDisc=False)

    def home(self):
        for label, action, description in (
            ('Continuar assistindo', 'continue', 'Retome os episódios pelo progresso salvo no Kodi.'),
            ('Últimos episódios', 'latest_sources', 'Novos episódios das seis fontes, com suas imagens e informações quando disponíveis.'),
            ('Explorar animes', 'explore', 'Catálogos, gêneros e edições de áudio.'),
            ('Buscar em todas as fontes', 'search', 'Uma busca nas seis fontes, consultadas em paralelo.'),
            ('Minha lista', 'favorites', 'Seus animes e episódios favoritos.'),
            ('Destaques de anime · TMDB', 'discover', 'Animações japonesas populares no TMDB; selecione para buscar nas fontes.'),
            ('Ajustes e manutenção', 'settings_menu', 'Configurações, cache e diagnóstico.'),
        ):
            self.menu(label, action, description)

    def explore(self):
        self.catalog_page()

    def latest_sources(self):
        self.catalog_page()

    def collect(self, method, *args):
        result=[];failures=[];errors=[]
        with ThreadPoolExecutor(max_workers=3) as pool:
            jobs={key:pool.submit(getattr(source,method),*args) for key,source in self.sources.items()}
            for key,job in jobs.items():
                try:result.extend(job.result())
                except (OSError,ValueError) as error:
                    failures.append(key);errors.append(error)
        if len(errors)==len(self.sources):raise errors[0]
        if failures:
            xbmcgui.Dialog().notification('AnimesPlay','Alguns servidores estão temporariamente indisponíveis.')
        return result

    def settings_menu(self):
        settings = 'Addon.OpenSettings(' + self.addon.getAddonInfo('id') + ')'
        self.row('Configurações', 'open_settings', folder=False,
                 context_menu=[('Abrir configurações', settings)])
        if xbmc.getCondVisibility('Player.HasVideo'):
            self.row('Pesquisar legendas no Kodi', 'subtitles_help', folder=False)
        self.menu('Limpar cache dos catálogos', 'clear_catalog', key='cache', folder=False,
                  description='Atualiza as páginas sem apagar favoritos, histórico ou associações TMDB.')
        self.menu('Limpar cache de consultas TMDB', 'clear_metadata_cache', key='cache', folder=False)
        self.menu('Diagnóstico de navegação', 'diagnostics', key='diagnostics', folder=False)

    def genres(self):
        for genre in self.sources['metianimes'].genres():
            self.menu(genre['title'], 'by_genre', key='genres', genre_url=genre['url'])

    def genre_catalog(self):
        page = max(1, int(self.args.get('page', 1)))
        items = self.sources['metianimes'].genre(self.args['genre_url'], page)
        visible, next_params = self.local_page(group(items), more=bool(items), page=page,
                                               genre_url=self.args['genre_url'])
        self.listing(visible)
        if next_params:
            self.row('Próxima página', 'by_genre', **next_params)

    def discover(self):
        token = self.addon.getSetting('tmdb_token').strip() or DEFAULT_API_KEY
        if not token:
            xbmcgui.Dialog().ok('TMDB', 'Configure uma chave ou token TMDB nos ajustes.')
            return
        page = max(1, int(self.args.get('page', 1)))
        data = API(self.profile, token, self.addon.getSetting('metadata_cache_enabled') != 'false',
                   metadata_ttl(self.addon)).discover(page)
        for entry in data.get('results', []):
            title = entry.get('name') or entry.get('original_name')
            if title:
                image = 'https://image.tmdb.org/t/p/w500' + entry['poster_path'] if entry.get('poster_path') else None
                self.row(title, 'search', q=title, description=entry.get('overview', ''), icon=image)
        if page < min(data.get('total_pages', 1), 500):
            self.row('Próxima página', 'discover', page=page + 1)

    def recommendations(self):
        catalog = self.source.catalog(1)
        items = suggest(self.profile, History(self.profile).recently_watched(), catalog)
        if items:
            self.listing(items[:PAGE_SIZE])
        else:
            xbmcgui.Dialog().notification('AnimesPlay',
                'As sugestões usam gêneros de obras associadas ao TMDB no catálogo e no histórico.')

    def catalog_page(self):
        page = max(1, int(self.args.get('page', '1')))
        source = self.adapter()
        if 'provider' in self.args:
            items = source.catalog(page) if self.action in ('catalog','explore') else source.latest(page)
        else:
            items = self.collect('catalog' if self.action in ('catalog','explore') else 'latest', page)
        if self.action in ('latest','latest_sources'):
            works=[]
            for item in items:
                works.append(dict(item,mediatype='tvshow',landing_episode=True,episode_title=item.get('episode_title') or item['title'],title=item.get('showtitle') or re.sub(r'(?i)^EP\s*\d+\s*|\s*(?:epis[oó]dio|EP)\s*\d+.*','',item['title']).strip() or item['title']))
            items=works
        diagnostics.record(self.profile, self.action, 'ok', self.active_source.client.last_request if 'provider' in self.args else {}, items=len(items))
        has_remote_items = bool(items)
        is_catalog = self.action in ('catalog','explore','latest_sources','latest')
        audio = self.args.get('audio')
        if is_catalog and audio in ('dub', 'sub'):
            items = [item for item in items if edition_audio(item) == audio]
        visible, next_params = self.local_page(group(items) if is_catalog else items,
                                               more=has_remote_items, page=page, **({'provider':self.args['provider']} if 'provider' in self.args else {}), **({'audio': audio} if audio else {}))
        visible=group(self.enricher.shows(visible))
        if self.action in ('latest','latest_sources'):visible=self.enrich_latest(visible)
        self.listing(visible)
        if next_params or (is_catalog and audio and not items and has_remote_items):
            self.row('Próxima página', self.action, **(next_params or {'page': page + 1, 'audio': audio, 'provider': self.args.get('provider', 'goyabu')}))
        elif page == 1 and not items:
            xbmcgui.Dialog().notification('AnimesPlay', 'A página carregou, mas nenhum item foi reconhecido.')

    def enrich_latest(self, items):
        def enrich(item):
            try:
                adapter=self.sources[item.get('provider','goyabu')]
                parent=adapter.parent(item['url'])
                if not parent:return item
                parent=self.enricher.show(parent)
                episode=dict(item,mediatype='episode',show_url=parent['url'],showtitle=parent['title'])
                episode=self.enricher.episodes(parent,[episode])[0]
                return dict(item,**{k:episode[k] for k in ('episode_title','plot','icon','art','season','show_url','showtitle') if k in episode})
            except (OSError,ValueError,KeyError):return item
        with ThreadPoolExecutor(max_workers=3) as pool:return list(pool.map(enrich,items))

    def search(self):
        query = self.args.get('q')
        if query is None:
            query = xbmcgui.Dialog().input('Buscar anime')
        if query.strip():
            self.store.search(query)
            page = int(self.args.get('page', 1))
            if 'provider' in self.args:
                items = group(self.adapter().search(query, page))
            else:
                items = []
                failures = []
                with ThreadPoolExecutor(max_workers=3) as pool:
                    jobs = {provider: pool.submit(source.search, query, page)
                            for provider, source in self.sources.items()}
                    for provider, result in jobs.items():
                        try:
                            items.extend(result.result())
                        except (OSError, ValueError):
                            failures.append('Servidor {}'.format(list(self.sources).index(provider)+1))
                if failures:
                    xbmcgui.Dialog().notification('Busca', 'Consulta indisponível: ' + ', '.join(failures))
                items = group(items)
            items=group(self.enricher.shows(items))
            visible, next_params = self.local_page(items, more=True, q=query,
                                                   page=page, **({'provider': self.args['provider']} if 'provider' in self.args else {}))
            self.listing(visible)
            if next_params:
                self.row('Próxima página', 'search', **next_params)
        if self.store.searches():
            self.row('Buscas recentes', 'search_history')

    def search_history(self):
        for query in self.store.searches():
            self.row(query, 'search', q=query)

    def favorites(self):
        items, next_params = self.local_page(self.store.favorites())
        self.row('Sugestões pelo histórico', 'recommendations')
        for item in items:
            action = 'play' if item.get('mediatype') == 'episode' else 'servers'
            self.row(item['title'], action, folder=action!='play', icon=item.get('icon'), context_menu=[('Remover da minha lista', 'RunPlugin(' + self.url(action='remove', id=item['id']) + ')')] + self.context(item), item=item)

        if next_params:
            self.row('Próxima página', 'favorites', **next_params)

    def open_editions(self):
        item=json.loads(self.args['item'])
        variants=item.get('variants',[item])
        found=self.collect('search',item['title'],1)
        found=self.enricher.shows(group(found))
        for other in found:
            if (item.get('tmdb_id') and other.get('tmdb_id')==item['tmdb_id']) or normalized(other['title'])==normalized(item['title']):
                variants.extend(other.get('variants',[other]))
        unique={v['url']:v for v in variants}
        self.list_editions(dict(item,variants=list(unique.values())))

    def episodes(self):
        parent = json.loads(self.args['item'])
        adapter=self.adapter(parent)
        if parent.get('landing_episode') and hasattr(adapter,'parent'):
            resolved_parent=adapter.parent(parent['url'])
            if resolved_parent:parent=dict(resolved_parent,audio=parent.get('audio',''),season_hint=parent.get('season_hint'))
        try:parent=self.enricher.show(parent)
        except (OSError,ValueError,KeyError):pass
        entries=adapter.episodes(parent)
        requested=parent.get('audio')
        if requested in ('dub','sub'):
            entries=[e for e in entries if edition_audio(e) in (requested,'unknown')]
        if not entries:
            xbmcgui.Dialog().notification('AnimesPlay','Não há episódios disponíveis neste servidor.')
        visible, next_params = self.local_page(entries)
        visible=self.enricher.episodes(parent,visible)
        season = saved_records(self.profile, [parent.get('url')]).get(parent.get('url'))
        self.listing(visible, season=season)
        if next_params:
            self.row('Próxima página', 'episodes', item=parent, **next_params)

    def open_options(self):
        self.show_options(json.loads(self.args['item']))

    def next_episode(self):
        current = json.loads(self.args['item'])
        episode = self.adapter(current).next_episode(current)
        if episode:
            self.show_options(episode)
        else:
            xbmcgui.Dialog().notification('AnimesPlay', 'Próximo episódio ainda sem correspondência segura')

    def continue_watching(self):
        for item, position in History(self.profile).unfinished():
            label = '{} · {:d}:{:02d}'.format(item['title'], int(position) // 60, int(position) % 60)
            self.row(label, 'play', False, item=item, icon=item.get('icon'), context_menu=self.context(item), choice='auto')

    def run(self):
        try:
            if self.args.get('key'):self.args['item']=packed(self.navigation.get(self.args['key']))
            self.main()
        except PlaybackCancelled:
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
        except MediaUnavailable as error:
            xbmcgui.Dialog().ok('Reprodução indisponível', str(error))
            if self.action in ('play', 'autoplay'):
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            else:
                xbmcplugin.endOfDirectory(self.handle, succeeded=False)
        except HTTPError as error:
            messages = {
                401: 'O servidor exige autenticação.',
                403: 'O servidor recusou a consulta.',
                404: 'A página pedida não foi encontrada.',
                429: 'O servidor limitou as consultas. Aguarde e tente novamente.',
            }
            self.show_failure('HTTP {}'.format(error.code),
                              messages.get(error.code, 'O servidor retornou um erro HTTP.'))
        except (URLError, TimeoutError, ssl.SSLError) as error:
            reason = error.reason if isinstance(error, URLError) else error
            if isinstance(reason, socket.gaierror):
                code, message = 'DNS', 'Não foi possível localizar o servidor.'
            elif isinstance(reason, TimeoutError):
                code, message = 'timeout', 'O servidor demorou demais para responder.'
            elif isinstance(reason, ssl.SSLError):
                code, message = 'TLS', 'A conexão HTTPS falhou.'
            else:
                code, message = 'conexão', 'Não foi possível conectar à fonte.'
            self.show_failure(code, message)
        except Exception as error:
            self.show_failure(type(error).__name__, 'O addon encontrou um erro ao processar a etapa.')
        finally:
            self.addon=None

    def show_failure(self, code, message):
        diagnostics.record(self.profile, self.action, code, self.active_source.client.last_request)
        xbmcgui.Dialog().ok('AnimesPlay · ' + code, message + ' Veja o diagnóstico nos ajustes.')
        if self.action in ('play', 'autoplay'):
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
        else:
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)

    def show_trailer(self, item):
        if not xbmc.getCondVisibility('System.HasAddon(plugin.video.youtube)'):
            xbmcgui.Dialog().ok('Trailer', 'Ative o addon YouTube no Kodi para abrir trailers.')
            return
        with closing(db(self.profile)) as conn:
            record = conn.execute('SELECT kind,payload FROM titles WHERE source=?', (item['url'],)).fetchone()
        if not record or record[0] not in ('movie', 'tv'):
            xbmcgui.Dialog().ok('Trailer', 'Associe a obra como filme ou série pelo menu de contexto TMDB.')
            return
        token = self.addon.getSetting('tmdb_token').strip() or DEFAULT_API_KEY
        if not token:
            xbmcgui.Dialog().ok('Trailer', 'Configure seu token TMDB nas configurações do AnimesPlay.')
            return
        route = find_trailer(record[0], json.loads(record[1])['id'], token,
                             api=API(self.profile, token, self.addon.getSetting('metadata_cache_enabled') != 'false',
                                     metadata_ttl(self.addon)))
        if route:
            xbmc.executebuiltin('PlayMedia(' + route + ')')
        else:
            xbmcgui.Dialog().notification('Trailer', 'Trailer do YouTube indisponível')

    def configure_aniskip(self, item):
        if type(item.get('episode')) is not int:
            return
        dialog = xbmcgui.Dialog()
        links = Associations(self.profile)
        current = links.get(item['id'])
        action = dialog.select('AniSkip · ' + item['title'], ['Definir ID MAL e episódio', 'Remover associação'])
        if action == 1:
            links.remove(item['id'])
        elif action == 0:
            example = '{} {}'.format(*current) if current else ''
            parts = dialog.input('ID do MyAnimeList e número do episódio, separados por espaço',
                                 defaultt=example).split()
            if not parts:
                return
            if (len(parts) != 2 or not all(p.isascii() and p.isdigit() and len(p) <= 9 for p in parts)
                    or not all(int(p) > 0 for p in parts)):
                dialog.ok('AniSkip', 'Informe dois inteiros positivos. Exemplo: 12345 2.')
                return
            links.save(item['id'], int(parts[0]), int(parts[1]))

    def play(self, item, interactive=True):
        engine = Engine(self.adapter(item))
        progress = xbmcgui.DialogProgress() if interactive else None
        if progress:
            progress.create('AnimesPlay', 'Preparando reprodução...')
        engine.adapter.progress = (lambda percent, message: progress.update(percent, message)) if progress else None

        def select_quality(labels):
            progress.close()
            selected = xbmcgui.Dialog().select('Qualidade', labels)
            progress.create('AnimesPlay', 'Verificando mídia...')
            return selected
        try:
            stream = engine.play(item, choice=self.args.get('choice', 'auto') if interactive else 'auto', select=select_quality if progress else None, cancelled=progress.iscanceled if progress else None, accept=lambda media: media.get('mime') != 'application/dash+xml' or xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'))
        finally:
            if progress:
                progress.close()
            success=bool(engine.trace and engine.trace[-1].get('stage')=='media_validation' and engine.trace[-1].get('status')=='ok')
            xbmc.log('AnimesPlay: reprodução '+('validada' if success else 'indisponível')+'; {} etapas. Detalhes no diagnóstico.'.format(len(engine.trace)), xbmc.LOGINFO if success else xbmc.LOGWARNING)
            try:
                with open(os.path.join(self.profile, 'last-playback-diagnostic.json'), 'w', encoding='utf-8') as report:
                    json.dump({'version': self.addon.getAddonInfo('version'), 'trace': engine.trace}, report, ensure_ascii=False, indent=2)
            except OSError:
                pass
        offset = 0
        if item.get('id') and hasattr(xbmcgui, 'Window'):
            try:
                offset = History(self.profile).resume(item['id'])
                window = xbmcgui.Window(10000)
                window.setProperty(PENDING, json.dumps({'item': public_episode(item), 'key': media_key(stream['url']), 'expires': time.time() + 60, 'resume': offset,
                                                           'autoplay': self.addon.getSetting('goyabu_autoplay') == 'true',
                                                           'skip': [kind for kind in ('op', 'ed') if
                                                                    self.addon.getSetting('goyabu_skip_' + kind) == 'true']}, ensure_ascii=False))
            except Exception:
                xbmc.log('AnimesPlay: histórico indisponível', xbmc.LOGWARNING)
        headers = urlencode(stream.get('headers', {}))
        li = xbmcgui.ListItem(path=stream['url'] + ('|' + headers if headers else ''))
        li.setMimeType(stream['mime'])
        li.setContentLookup(False)
        apply(li, item, xbmc)
        if item.get('url'):
            self.apply_item_metadata(li, item)
        if stream['mime'] == 'application/dash+xml' or (stream['mime'] == 'application/vnd.apple.mpegurl' and xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)')):
            li.setProperty('inputstream', 'inputstream.adaptive')
            if headers:
                li.setProperty('inputstream.adaptive.stream_headers', headers)
                li.setProperty('inputstream.adaptive.manifest_headers', headers)
        if stream.get('subtitles'):
            li.setSubtitles(stream['subtitles'])
        xbmcplugin.setResolvedUrl(self.handle, True, li)

def run():
    Plugin().run()
