# -*- coding: utf-8 -*-
import six
from fasthttp import req
from bs4 import BeautifulSoup
try:
    from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
    kodi_mode = True
except:
    kodi_mode = False
if six.PY3:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode #python 3
else:
    from urlparse import urlparse, parse_qs #python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode
import sys
import os
import re
import base64






class scrape:
    site_anime = 'https://animesbr.cc'
    user_agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36 Edg/111.0.1661.41'
    itag_map = {'5': '240', '6': '270', '17': '144', '18': '360', '22': '720', '34': '360', '35': '480',
    '36': '240', '37': '1080', '38': '3072', '43': '360', '44': '480', '45': '720', '46': '1080',
    '82': '360 [3D]', '83': '480 [3D]', '84': '720 [3D]', '85': '1080p [3D]', '100': '360 [3D]',
    '101': '480 [3D]', '102': '720 [3D]', '92': '240', '93': '360', '94': '480', '95': '720',
    '96': '1080', '132': '240', '151': '72', '133': '240', '134': '360', '135': '480',
    '136': '720', '137': '1080', '138': '2160', '160': '144', '264': '1440',
    '298': '720', '299': '1080', '266': '2160', '167': '360', '168': '480', '169': '720',
    '170': '1080', '218': '480', '219': '480', '242': '240', '243': '360', '244': '480',
    '245': '480', '246': '480', '247': '720', '248': '1080', '271': '1440', '272': '2160',
    '302': '2160', '303': '1080', '308': '1440', '313': '2160', '315': '2160', '59': '480'}

    @classmethod
    def basic_encode(cls,mensagem):
        mensagem = base64.b64encode(mensagem.encode('utf-8', 'ignore')).decode('utf-8')
        return mensagem
    @classmethod
    def basic_decode(cls,mensagem):
        mensagem = base64.b64decode(mensagem).decode('utf-8')
        return mensagem    

    @classmethod
    def pick_source(cls,sources):
        return sources[0][1]

    @classmethod
    def __key(self, item):
        try:
            return int(re.search(r'(\d+)', item[0]).group(1))
        except:
            return 0
    
    @classmethod
    def _parse_gdocs(cls, html):
        urls = []
        if 'error' in html:
            reason = unquote_plus(re.findall('reason=([^&]+)', html)[0])
            raise ValueError(reason)
        value = unquote(re.findall('fmt_stream_map=([^&]+)', html)[0])
        items = value.split(',')
        for item in items:
            _source_itag, source_url = item.split('|')
            if isinstance(source_url, six.text_type) and six.PY2:  # @big change
                source_url = source_url.decode('unicode_escape').encode('utf-8')
            quality = cls.itag_map.get(_source_itag, 'Unknown Quality [%s]' % _source_itag)
            source_url = unquote(source_url)
            urls.append((quality, source_url))
        return urls
     
    @classmethod
    def resolve_url(cls,link):
        sources = []
        cookies = None
        referer = ''
        if 'drive.google.com' in link:
            referer = 'https://youtube.googleapis.com/'
            link = re.findall('/file/.*?/([^/]+)', link)[0]
            link = 'https://drive.google.com/get_video_info?docid=' + link
            response = req.get(link)
            cookies = response.cookies
            sources = cls._parse_gdocs(response.text)
        elif 'blogger.com/video.g?token=' in link:
            referer =  'https://www.youtube.com/'
            response = req.get(link)
            cookie = response.cookies
            source = re.findall(r'play_url.+?"(.+?)","format_id":(.+?)}', response.text)
            if source:
                sources = [(cls.itag_map.get(quality, 'Unknown Quality [%s]' % quality), stream.decode('unicode-escape') if six.PY2 else stream) for stream, quality in source]
        return sources, cookies, referer
    
    @classmethod
    def select_video(cls,sources):
        if sources:
            sources.sort(key=cls.__key, reverse=True)
            video = cls.pick_source(sources)
        else:
            video = ''
        return video

    # TESTE DE VIDEO
    @classmethod
    def teste_video(cls):
        sources, cookies, referer = cls.resolve_url('https://www.blogger.com/video.g?token=AD6v5dzIeW9tYcilTwBRv_zNGQQl0wBRUppMth1wzBbyaaIYoJXyt-PjCSbLiQ1-2_M6Ada7epQCazvwgBZCfMf6Vb76Eo6BXcvILO-mdXD9oD7eFxe74BpgwlLUCqcShYOJ1shSQcJU')
        video = cls.select_video(sources)


    # prepara os links
    @classmethod
    def find_video(cls,link):
        try:
            sources, cookies, referer = cls.resolve_url(link)
            video = cls.select_video(sources)
        except:
            cookies = None
            referer = None
            video = ''
        if video:
            if cookies:
                cookies_str = ";".join(["%s=%s"%(key,value) for key, value in cookies.items()])
                if referer:
                    video = video + '|User-Agent='+ quote(cls.user_agent) + '&Cookie=' + quote(cookies_str) + '&Referer='+ quote(referer)
                else:
                    video = video + '|User-Agent='+ quote(cls.user_agent) + '&Cookie=' + quote(cookies_str)
            else:
                if referer:
                    video = video + '|User-Agent='+ quote(cls.user_agent) + '&Referer='+ quote(referer)
                else:
                    video = video + '|User-Agent='+ quote(cls.user_agent)
        return video
    
    @classmethod
    def soup(cls,html):
        soup = BeautifulSoup(html, 'html.parser')
        return soup
                    
    @classmethod
    def todos_animes(cls,url=None,genero=None,cache=None):
        if not url:
            if not genero:
                url = cls.site_anime + '/anime/'
        else:
            try:
                url = cls.basic_decode(url)
            except:
                pass
        referer = url
        try:
            referer = cls.basic_encode(referer)
        except:
            pass
        if genero:
            header = {'Referer': cls.site_anime + '/generos/'}
        else:
            header = {'Referer': cls.site_anime + '/'}
        itens = []
        next = False
        page = ''
        if not url:
            return itens, next
        try:
            r = req.get(url,headers=header,cache_time=cache)
            html = r.text
            soup = cls.soup(html)
            div = soup.find("div", {"id": "archive-content"})
            if div:
                articles = div.findAll("article", {"item tvshows"})
                if articles:
                    for i in articles:
                        try:
                            img = i.find("img").get("data-lazy-src", "").split('?resize')[0]
                        except:
                            img = i.find("img").get("data-lazy-src", "")
                        href = i.find("a").get("href")
                        name = i.find("h3").text
                        try:
                            href = cls.basic_encode(href)
                        except:
                            pass                       
                        itens.append((name,href,img,referer))        
            try:
                next = soup.find("div", {"class": "pagination"})
                next = next.find_all("a", {"class": "arrow_pag"})[-1].get("href")
                try:
                    page = next.split('/page/')[1]
                    try:
                        page = page.split('/')[0]
                    except:
                        pass
                except:
                    pass
                try:
                    next = cls.basic_encode(next)
                except:
                    pass
            except:
                next = False
        except:
            pass
        return itens, next, page
    
    #anos
    @classmethod
    def listar_anos(cls):
        anos = []
        try:
            r = req.get(cls.site_anime)
            html = r.text
            soup = cls.soup(html)
            ul = soup.find('ul', {'class': 'releases scrolling'})
            li_list = ul.find_all('li')
            for li in li_list:
                a = li.find('a')
                name = a.text
                href = a.get('href', '')
                try:
                    href = cls.basic_encode(href)
                except:
                    pass
                if href:
                    anos.append((name,href))
        except:
            pass
        return anos
    
    # popular
    # @classmethod
    # def popular(cls):
    #     site = cls.site_anime
    #     referer  = site + '/'
    #     itens = []
    #     try:
    #         r = req.get(site)
    #         html = r.text
    #         soup = cls.soup(html)
    #         aside = soup.find('aside', {'id': 'dtw_content_views-11'})
    #         div = aside.find('div', {'class': lambda x: x and x.startswith('dtw_content')})
    #         articles = div.find_all('article', {'class': 'w_item_b'})
    #         if articles:
    #             for article in articles:

    #     except:
    #         pass

    
    @classmethod
    def generos_lista(cls,cache=None):
        url = cls.site_anime + '/generos/'
        header = {'Referer': cls.site_anime + '/'}
        itens = []
        try:
            r = req.get(url,headers=header,cache_time=cache)
            html = r.text
            soup = cls.soup(html)
            div = soup.find('div', {'class': 'single-page'}).find('div', {'class': 'wp-content'})
            generos = div.find_all('p')
            for genero in generos:
                href = genero.find('a').get('href')
                try:
                    href = cls.basic_encode(href)
                except:
                    pass
                name = genero.find('a').text
                itens.append((name,href))
        except:
            pass
        return itens
    
    @classmethod
    def abrir_genero(cls,url,cache=None):
        itens = []
        next = False
        page = ''
        if not url:
            return itens, next, page
        else:
            try:
                url = cls.basic_decode(url)
            except:
                pass
        referer = url
        try:
            referer = cls.basic_encode(referer)
        except:
            pass
        if 'lancamento' in url:
            header = {'Referer': cls.site_anime + '/'} 
        else:
            header = {'Referer': cls.site_anime + '/generos/'}      
        try:
            r = req.get(url,headers=header,cache_time=cache)
            html = r.text
            soup = cls.soup(html)
            articles = soup.select("article[class^=item]")
            if articles:
                for article in articles:
                    # tipo: movies ou tvshows
                    try:
                        tipo = article.get('class')[-1]
                    except:
                        tipo = False
                    div = article.find('div', {'class': 'poster'})
                    try:
                        img = div.find("img").get("data-lazy-src", "").split('?resize')[0]
                    except:
                        img = div.find("img").get("data-lazy-src", "")
                    try:
                        name = div.find("img").get("alt", "")
                    except:
                        name = ''
                    href = div.find('a').get('href', '')
                    if name and href and tipo:
                        try:
                            href = cls.basic_encode(href)
                        except:
                            pass
                        itens.append((name,href,img,referer,tipo))
            try:
                next = soup.find("div", {"class": "pagination"})
                current = next.find('span', {'class': 'current'}).text
                next = next.find_all("a")
                links = []
                for i in next:
                    link = i.get('href', '')
                    if 'page' in link:
                        links.append(link)
                if links:
                    link = links[0]
                    try:
                        page = link.split('/page/')[1]
                        try:
                            page = page.split('/')[0]
                        except:
                            pass
                    except:
                        page = ''
                    if page > current:
                        next = link
                    else:
                        next = False
                        page = ''
                else:
                    next = False
                    page = '' 
                if next:
                    try:
                        next = cls.basic_encode(next)
                    except:
                        pass                
            except:
                pass
        except:
            pass
        return itens, next, page

    @classmethod
    def pesquisa_anime(cls,url=None,pesquisa=None,cache=None):
        itens = []
        next = False
        page = ''
        if pesquisa:
            url = cls.site_anime + '/?s=' + quote(pesquisa).replace('%20', '+')
        if not url:
            return itens, next, page
        try:
            url = cls.basic_decode(url)
        except:
            pass
        referer = url
        try:
            referer = cls.basic_encode(referer)
        except:
            pass
        header = {'Referer': cls.site_anime + '/'}
        try:
            r = req.get(url,headers=header,cache_time=cache)
            html = r.text
            soup = cls.soup(html)
            divs = soup.find_all('div', {'class': 'result-item'})
            for i in divs:
                href = i.find('a').get('href', '')
                try:
                    img = i.find('img').get('src').split('?resize')[0]
                except:
                    img = i.find('img').get('src')
                name = i.find('img').get('alt', '')
                # tipo: tvshows ou movies
                try:
                    tipo = i.find('span').get('class')[0]
                except:
                    tipo = ''
                if name and href and tipo:
                    try:
                        href = cls.basic_encode(href)
                    except:
                        pass
                    itens.append((name,href,img,referer,tipo))
            try:
                next = soup.find("div", {"class": "pagination"})
                current = next.find('span', {'class': 'current'}).text
                next = next.find_all("a")
                links = []
                for i in next:
                    link = i.get('href', '')
                    if 'page' in link:
                        links.append(link)
                if links:
                    link = links[0]
                    try:
                        page = link.split('/page/')[1]
                        try:
                            page = page.split('/')[0]
                        except:
                            pass
                    except:
                        page = ''
                    if page > current:
                        next = link
                    else:
                        next = False
                        page = ''
                else:
                    next = False
                    page = ''
                if next:
                    try:
                        next = cls.basic_encode(next)
                    except:
                        pass                                     
            except:
                pass            
        except:
            pass
        return itens, next, page
        
    @classmethod
    def exibir_temporada(cls,url,referer,cache=None):
        list_seasons = []
        if url and referer:
            try:
                url2 = cls.basic_decode(url)
            except:
                url2 = url
            try:
                referer2 = cls.basic_decode(referer)
            except:
                referer2 = referer                        
            header = {'Referer': referer2}
            try:
                r = req.get(url2,headers=header)
                html = r.text
                soup = cls.soup(html)
                div = soup.find("div", {"id": "seasons"})
                if div:
                    seasons = div.findAll("div", {"class": "se-c"})
                    if seasons:
                        for count, i in enumerate(seasons):
                            count = count + 1
                            season = count
                            list_seasons.append((season,url,referer))
            except:
                pass
        return list_seasons
    
    @classmethod
    def exibir_episodios(cls,url,referer,temp,cache=None):
        list_episodios = []
        if url and referer:
            try:
                url2 = cls.basic_decode(url)
            except:
                url2 = url
            try:
                referer2 = cls.basic_decode(referer)
            except:
                referer2 = referer            
            header = {'Referer': referer2}           
            try:
                r = req.get(url2,headers=header)
                html = r.text
                soup = cls.soup(html)
                div = soup.find("div", {"id": "seasons"})
                if div and temp:
                    seasons = div.findAll("div", {"class": "se-c"})
                    if seasons:
                        # inverter ordem
                        seasons = seasons[::-1]
                        for count, i in enumerate(seasons):
                            count = count + 1
                            season = count
                            if season == int(temp):
                                episodios = i.find("ul", {"class": "episodios"})
                                if episodios:
                                    li = episodios.findAll("li")
                                    if li:
                                        # inverter episodios
                                        li = li[::-1]
                                        for episodio_numero, episodio in enumerate(li):
                                            try:
                                                img = episodio.find('img').get('data-lazy-src').split('?resize')[0]
                                            except:
                                                img = episodio.find('img').get('data-lazy-src')
                                            episodio_numero = episodio_numero + 1
                                            episodio_numero = str(episodio_numero)                                    
                                            episodio_nome = episodio.find("a").text
                                            episodio_nome = '%s - %s'%(episodio_numero,episodio_nome)
                                            href = episodio.find("a").get("href", "")
                                            try:
                                                href = cls.basic_encode(href)
                                            except:
                                                pass                                              
                                            list_episodios.append((episodio_nome,href,img,url))
                                break
            except:
                pass
        return list_episodios

    @classmethod
    def get_options(cls,url,referer,tipo,cache=None):
        try:
            url = cls.basic_decode(url)
        except:
            pass
        try:
            referer = cls.basic_decode(referer)
        except:
            pass
        opcoes = []
        header = {'Referer': referer}
        if url and referer:
            try:
                r = req.get(url, headers=header,cache_time=cache)
                html = r.text
                soup = cls.soup(html)
                if tipo == 'tvshows':
                    temp_li_options = []
                    li_tags = soup.find_all('li', id=lambda value: value and value.startswith("player-option"))
                    for li_tag in li_tags:
                        #print(li_tag)
                        try:
                            option_number = li_tag.get('id').split('-')[-1]
                        except:
                            option_number = False
                        try:
                            option_name = li_tag.find('span', {'class': 'title'}).text
                        except:
                            option_name = False
                        if option_number and option_name:
                            temp_li_options.append((option_number,option_name))
                    if temp_li_options:
                        for option_number, option_name in temp_li_options:
                            div_tags = soup.find_all('div', id=lambda value: value and value.startswith("source-player"))
                            for div_tag in div_tags:
                                div_id = div_tag.get('id')
                                if div_id == 'source-player-' + str(option_number):
                                    try:
                                        blogger = div_tag.find('a').get('href', '')
                                    except:
                                        blogger = ''
                                    if blogger:
                                        opcoes.append((option_name,blogger))
                        if not opcoes: # CASO NAO TENHA BLOGGER
                            temp_li_options = []
                            li_tags = soup.find_all('li', id=lambda value: value and value.startswith("player-option"))
                            for li_tag in li_tags:
                                try:
                                    option_number = li_tag.get('id').split('-')[-1]
                                except:
                                    option_number = False
                                try:
                                    option_name = li_tag.find('span', {'class': 'title'}).text
                                except:
                                    option_name = False
                                if option_number and option_name:
                                    temp_li_options.append((option_number,option_name))
                            if temp_li_options:
                                for option_number, option_name in temp_li_options:
                                    div_tags = soup.find_all('div', id=lambda value: value and value.startswith("source-player"))
                                    for div_tag in div_tags:
                                        div_id = div_tag.get('id')
                                        if div_id == 'source-player-' + str(option_number):
                                            try:
                                                iframe = div_tag.find('iframe').get('src', '')
                                            except:
                                                iframe = ''
                                            if iframe:
                                                try:
                                                    parsed_url = urlparse(iframe)
                                                    query_params = parse_qs(parsed_url.query)
                                                    source_param = query_params.get('source', '')
                                                except:
                                                    source_param = ''
                                                if source_param:
                                                    stream = source_param[0]
                                                    if '.mp4' in stream:
                                                        stream = stream + '|User-Agent='+ quote(cls.user_agent) + '&Referer='+ quote(url)
                                                    else:
                                                        # try:
                                                        #     r = req.get(iframe,headers={'Referer': url})
                                                        #     html = r.text
                                                        #     print(html)
                                                        # except:
                                                        #     pass
                                                        stream = ''
                                                elif 'drive' in iframe:
                                                    stream = iframe
                                                elif 'blogger' in iframe:
                                                    stream = iframe
                                                elif '.mp4' in iframe:
                                                    stream = iframe + '|User-Agent='+ quote(cls.user_agent) + '&Referer='+ quote(url)
                                                else:
                                                    stream = ''
                                                if stream:
                                                    opcoes.append((option_name,stream))

                elif tipo == 'movies':
                    temp_li_options = []
                    li_tags = soup.find_all('li', id=lambda value: value and value.startswith("player-option"))
                    for li_tag in li_tags:
                        try:
                            option_number = li_tag.get('id').split('-')[-1]
                        except:
                            option_number = False
                        try:
                            option_name = li_tag.find('span', {'class': 'title'}).text
                        except:
                            option_name = False
                        if option_number and option_name:
                            temp_li_options.append((option_number,option_name))
                    if temp_li_options:
                        for option_number, option_name in temp_li_options:
                            div_tags = soup.find_all('div', id=lambda value: value and value.startswith("source-player"))
                            for div_tag in div_tags:
                                div_id = div_tag.get('id')
                                if div_id == 'source-player-' + str(option_number):
                                    try:
                                        iframe = div_tag.find('iframe').get('src', '')
                                    except:
                                        iframe = ''
                                    if iframe:
                                        try:
                                            parsed_url = urlparse(iframe)
                                            query_params = parse_qs(parsed_url.query)
                                            source_param = query_params.get('source', '')
                                        except:
                                            source_param = ''
                                        if source_param:
                                            stream = source_param[0]
                                            if '.mp4' in stream:
                                                stream = stream + '|User-Agent='+ quote(cls.user_agent) + '&Referer='+ quote(url)
                                            else:
                                                # try:
                                                #     r = req.get(iframe,headers={'Referer': url})
                                                #     html = r.text
                                                #     print(html)
                                                # except:
                                                #     pass
                                                stream = ''
                                        elif 'drive' in iframe:
                                            stream = iframe
                                        elif 'blogger' in iframe:
                                            stream = iframe
                                        elif '.mp4' in iframe:
                                            stream = iframe + '|User-Agent='+ quote(cls.user_agent) + '&Referer='+ quote(url)
                                        else:
                                            stream = ''
                                        if stream:
                                            opcoes.append((option_name,stream))
            except:
                pass
        return opcoes

    @classmethod
    def resolve_video_animes(cls,url):
        if 'drive' in url:
            video = cls.find_video(url)
        elif 'blogger' in url:
            video = cls.find_video(url)
        elif '.mp4' in url:
            video = url
        else:
            video = ''
        return video

# scrape.popular()
# scrape.listar_anos()
# print(scrape.teste_video())

#print(scrape.get_options('https://animesbr.cc/filmes/one-piece-filme-13-gold/', 'https://animesbr.cc/', 'movies'))
#print(scrape.get_options('https://animesbr.cc/episodio/kanojo-okarishimasu-2-episodio-12/', 'https://animesbr.cc/', 'tvshows'))
#tipo: tvshows ou movies

          



if kodi_mode:
    plugin = PLUGIN_URL
    handle = int(sys.argv[1])
    addon = xbmcaddon.Addon('plugin.video.animesplay')
    addonname = addon.getAddonInfo('name')
    icon = addon.getAddonInfo('icon')
    translate = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
    profile = translate(addon.getAddonInfo('profile')) if six.PY3 else translate(addon.getAddonInfo('profile')).decode('utf-8')
    home = translate(addon.getAddonInfo('path')) if six.PY3 else translate(addon.getAddonInfo('path')).decode('utf-8')
    next_icon = os.path.join(home, 'icons', 'next_icon.png')
    search_icon = os.path.join(home, 'icons', 'search_icon.png')
    settings_icon = os.path.join(home, 'icons', 'settings_icon.png')
    pix_icon = os.path.join(home, 'icons', 'qrcode-pix.png')
    donate_icon = os.path.join(home, 'icons', 'donate.png')
    if not os.path.exists(profile):
        try:
            os.mkdir(profile)
        except:
            pass
    install_file = os.path.join(profile, 'install_info.txt')
    dialog = xbmcgui.Dialog()
    try:
        cache_time = int(addon.getSetting('cache_time'))
        if cache_time == 0:
            cache = None
        elif cache_time == 1: # 3 dias
            cache = 259200
        elif cache_time == 2: # 5 dias
            cache = 432000
        elif cache_time == 3: # 7 dias
            cache = 604800
        else:
            cache = None
    except:
        cache = None

    class Donate(xbmcgui.WindowDialog):
        def __init__(self):
            self.image = xbmcgui.ControlImage(440, 145, 400, 400, pix_icon)
            self.text = xbmcgui.ControlLabel(x=150,y=570,width=1100,height=25,label='[B]SE ESSE ADD-ON LHE AGRADA, FAÇA UMA DOAÇÃO VIA PIX ACIMA E MANTENHA ESSE SERVIÇO ATIVO[/B]',textColor='white')
            self.text2 = xbmcgui.ControlLabel(x=495,y=600,width=1000,height=25,label='[B]PRESSIONE VOLTAR PARA SAIR[/B]',textColor='white')
            self.addControl(self.image)
            self.addControl(self.text)
            self.addControl(self.text2)        
  

    def route(f):
        action = ROUTE_PARAMS.get('action')
        if action is None and f.__name__ == 'main':
            f()
        elif action == f.__name__:
            f(ROUTE_PARAMS)

    def infoDialog(message, heading=addonname, iconimage='', time=3000, sound=False):
        if iconimage == '':
            iconimage = icon
        elif iconimage == 'INFO':
            iconimage = xbmcgui.NOTIFICATION_INFO
        elif iconimage == 'WARNING':
            iconimage = xbmcgui.NOTIFICATION_WARNING
        elif iconimage == 'ERROR':
            iconimage = xbmcgui.NOTIFICATION_ERROR
        dialog.notification(heading, message, iconimage, time, sound=sound)

    def to_unicode(text, encoding='utf-8', errors='strict'):
        """Force text to unicode"""
        if isinstance(text, bytes):
            return text.decode(encoding, errors=errors)
        return text

    def get_search_string(heading='', message=''):
        """Ask the user for a search string"""
        search_string = None
        keyboard = xbmc.Keyboard(message, heading)
        keyboard.doModal()
        if keyboard.isConfirmed():
            search_string = to_unicode(keyboard.getText())
        return search_string

    def search():
        vq = get_search_string(heading='Digite a pesquisa', message="")        
        if ( not vq ): return False
        return vq                

    def SetView(name):
        if name == 'Wall':
            try:
                xbmc.executebuiltin('Container.SetViewMode(500)')
            except:
                pass
        elif name == 'List':
            try:
                xbmc.executebuiltin('Container.SetViewMode(50)')
            except:
                pass
        elif name == 'Poster':
            try:
                xbmc.executebuiltin('Container.SetViewMode(51)')
            except:
                pass
        elif name == 'Shift':
            try:
                xbmc.executebuiltin('Container.SetViewMode(53)')
            except:
                pass
        elif name == 'InfoWall':
            try:
                xbmc.executebuiltin('Container.SetViewMode(54)')
            except:
                pass
        elif name == 'WideList':
            try:
                xbmc.executebuiltin('Container.SetViewMode(55)')
            except:
                pass
        elif name == 'Fanart':
            try:
                xbmc.executebuiltin('Container.SetViewMode(502)')
            except:
                pass

    def get_kversion():
        full_version_info = xbmc.getInfoLabel('System.BuildVersion')
        baseversion = full_version_info.split(".")
        intbase = int(baseversion[0])
        return intbase              

    def get_url(params):
        if params:
            url = '%s?%s'%(plugin, urlencode(params))
        else:
            url = ''
        return url   
  

    def item(params,folder=True):
        u = get_url(params)
        if not u:
            u = ''
        name = params.get("name")
        if name:
            name = name
        else:
            name = 'Unknow'
        iconimage = params.get("iconimage")
        if not iconimage:
            iconimage = icon
        fanart = params.get("fanart")
        if not fanart:
            fanart = ''
        description = params.get("description")
        if not description:
            description = ''           
        playable = params.get("playable")
        liz = xbmcgui.ListItem(name)
        liz.setArt({'fanart': fanart, 'thumb': iconimage, 'icon': "DefaultFolder.png"})
        if get_kversion() > 19:
            info = liz.getVideoInfoTag()
            info.setTitle(name)
            info.setMediaType('video')
            info.setPlot(description)
        else:
            liz.setInfo(type="Video", infoLabels={"Title": name, 'mediatype': 'video', "Plot": description})                                              
        if playable:
            if playable == 'true':
                liz.setProperty('IsPlayable', 'true')
        ok = xbmcplugin.addDirectoryItem(handle=handle, url=u, listitem=liz, isFolder=folder)
        return ok

    def disclaimer():
        if not os.path.exists(install_file): 
            dialog.textviewer('AVISO', 'O CONTEUDO DESTE ADDON DEPENDE DE SITE DE TERCEIROS, NÃO HOSPEDAMOS CONTEUDOS APENAS PESQUISAMOS NO GOOGLE')
            with open(install_file, 'w') as f:
                f.write('ok')

    @route
    def main(): 
        xbmcplugin.setContent(handle, 'tvshows')
        item({'name': '[B]PESQUISAR[/B]', 'action': 'pesquisar_anime','iconimage': search_icon},folder=True)
        item({'name': '[B]TODOS OS ANIMES[/B]', 'action': 'todos_animes','iconimage': icon},folder=True)
        item({'name': '[B]GÊNEROS[/B]', 'action': 'generos','iconimage': icon},folder=True)
        item({'name': '[B]ANO DE LANÇAMENTO[/B]', 'action': 'lancamento','iconimage': icon},folder=True)
        item({'name': '[B]DOAÇÃO[/B]', 'action': 'doar','iconimage': donate_icon},folder=True)
        item({'name': '[B]AJUSTES[/B]', 'action': 'settings','iconimage': settings_icon},folder=True)
        xbmcplugin.endOfDirectory(handle,cacheToDisc=False)
        SetView('WideList')
        disclaimer()

    @route
    def todos_animes(param):
        next = param.get('next', False)
        itens, next, page = scrape.todos_animes(next, cache=cache)
        if itens:
            xbmcplugin.setContent(handle, 'tvshows')
            for name,href,img,referer in itens:
                try:
                    name = '[B]' + name.encode('utf-8', 'ignore').upper() + '[/B]'
                except:
                    name = '[B]' + name.upper() + '[/B]'
                item({'name': name, 'url': href,'referer': referer,'action': 'exibir_temporada','iconimage': img},folder=True)
            if next and page:
               item({'name': '[B]PAGINA %s[/B]'%page, 'next': next,'action': 'todos_animes','iconimage': next_icon},folder=True)
            xbmcplugin.endOfDirectory(handle)
            SetView('WideList')


    @route
    def generos(param):
        itens = scrape.generos_lista(cache=cache)
        if itens:
            xbmcplugin.setContent(handle, 'tvshows')
            for name,href in itens:
                try:
                    name = '[B]' + name.encode('utf-8', 'ignore').upper() + '[/B]'
                except:
                    name = '[B]' + name.upper() + '[/B]'
                item({'name': name, 'next': href,'action': 'abrir_generos','iconimage': ''},folder=True)
            xbmcplugin.endOfDirectory(handle)
            SetView('WideList')

    @route
    def abrir_generos(param):
        next = param.get('next', False)
        itens, next, page = scrape.abrir_genero(next,cache=cache)
        if itens:
            xbmcplugin.setContent(handle, 'tvshows')
            for name,href,img,referer,tipo in itens:
                try:
                    name = '[B]' + name.encode('utf-8', 'ignore').upper() + '[/B]'
                except:
                    name = '[B]' + name.upper() + '[/B]'
                if tipo == 'tvshows':
                    item({'name': name, 'url': href,'referer': referer,'action': 'exibir_temporada','iconimage': img},folder=True)
                else:
                    item({'name': name, 'url': href,'referer': referer,'action': 'resolver_tocar','iconimage': img, 'tipo': tipo},folder=False)
            if next and page:
               item({'name': '[B]PAGINA %s[/B]'%page, 'next': next,'action': 'abrir_generos','iconimage': next_icon},folder=True)
            xbmcplugin.endOfDirectory(handle)
            SetView('WideList')

    @route
    def lancamento(param):
        anos = scrape.listar_anos()
        if anos:
            xbmcplugin.setContent(handle, 'tvshows')
            for ano, href in anos:
                try:
                    ano = '[B]' + ano.encode('utf-8', 'ignore').upper() + '[/B]'
                except:
                    ano = '[B]' + ano.upper() + '[/B]'
                item({'name': ano, 'next': href,'action': 'abrir_generos','iconimage': icon},folder=True)
            xbmcplugin.endOfDirectory(handle)
            SetView('WideList')

    @route
    def pesquisar_anime(param):
        pesquisa = param.get('pesquisa', '')
        next = param.get('next', False)
        if not pesquisa:
            pesquisa = search()
            if pesquisa:
                itens, next, page = scrape.pesquisa_anime(next,pesquisa=pesquisa,cache=cache)
            else:
                return
        else:
            itens, next, page = scrape.pesquisa_anime(next,pesquisa=False,cache=cache)
        if itens:
            xbmcplugin.setContent(handle, 'tvshows')
            for name,href,img,referer,tipo in itens:
                try:
                    name = '[B]' + name.encode('utf-8', 'ignore').upper() + '[/B]'
                except:
                    name = '[B]' + name.upper() + '[/B]'
                if tipo == 'tvshows':
                    item({'name': name, 'url': href,'referer': referer,'action': 'exibir_temporada','iconimage': img},folder=True)
                else:
                    item({'name': name, 'url': href,'referer': referer,'action': 'resolver_tocar','iconimage': img, 'tipo': tipo},folder=False)
            if next and page:
               item({'name': '[B]PAGINA %s[/B]'%page, 'next': next, 'pesquisa': pesquisa.encode('utf-8', 'ignore'), 'action': 'pesquisar_anime','iconimage': next_icon},folder=True)
            xbmcplugin.endOfDirectory(handle)

    @route
    def exibir_temporada(param):
        url = param.get('url', '')
        referer = param.get('referer', '')
        iconimage = param.get('iconimage', '')
        if url and referer:
            lista_season = scrape.exibir_temporada(url,referer,cache=cache)
            if lista_season:
                xbmcplugin.setContent(handle, 'tvshows')
                for season,url,referer in lista_season:
                    temporada_nome = '[B]TEMPORADA %s[/B]'%str(season)
                    try:
                        temporada_nome = temporada_nome.encode('utf-8', 'ignore')
                    except:
                        pass
                    item({'name': temporada_nome, 'url': url,'referer': referer, 'temp': str(season), 'action': 'exibir_episodios','iconimage': iconimage},folder=True)
                xbmcplugin.endOfDirectory(handle)


    @route
    def exibir_episodios(param):
        url = param.get('url', '')
        referer = param.get('referer', '')
        temp = param.get('temp', '')
        if url and referer and temp:
            lista_episodios = scrape.exibir_episodios(url,referer,temp,cache=cache)
            if lista_episodios:
                xbmcplugin.setContent(handle, 'episodes')
                for episodio_nome,href,img,referer in lista_episodios:
                    try:
                        episodio_nome = '[B]' + episodio_nome.encode('utf-8', 'ignore').upper() + '[/B]'
                    except:
                        episodio_nome = '[B]' + episodio_nome.upper() + '[/B]'
                    item({'name': episodio_nome, 'url': href,'referer': referer, 'action': 'resolver_tocar','iconimage': img, 'tipo': 'tvshows'},folder=False)
                xbmcplugin.endOfDirectory(handle)
            else:
                infoDialog('SEM EPISODIOS', iconimage='INFO')
                

    @route
    def resolver_tocar(param):
        name = param.get('name', '')
        url = param.get('url', '')
        referer = param.get('referer', '')
        tipo = param.get('tipo', '')
        playable = param.get('playable', '')
        iconimage = param.get('iconimage', '')
        if name and url and referer and tipo:
            options = scrape.get_options(url,referer,tipo,cache=cache)
            if options:
                items_options = [name2 for name2,href in options]            
                op = dialog.select('SELECIONE UMA OPÇÃO', items_options)
                if op >= 0:
                    page = options[op][1]
                    stream = scrape.resolve_video_animes(page)
                    if stream:
                        liz = xbmcgui.ListItem(name)
                        liz.setPath(stream)
                        liz.setArt({'thumb': iconimage, 'icon': iconimage})
                        description = ''
                        if get_kversion() > 19:
                            info = liz.getVideoInfoTag()
                            info.setTitle(name)
                            info.setMediaType('video')
                            info.setPlot(description)
                        else:           
                            liz.setInfo(type='video', infoLabels={'Title': name, 'plot': description })
                        if not playable:
                            xbmc.Player().play(item=stream, listitem=liz)
                        else:
                            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
                    else:
                        infoDialog('STREAMING INDISPONIVEL', iconimage='INFO')
            else:
                infoDialog('STREAMING INDISPONIVEL', iconimage='INFO')

    @route
    def settings(param):
        addon.openSettings()

    @route
    def limpar(param):
        try:
            req.clear_cache()
            dialog.ok(addonname, 'CACHE LIMPO COM SUCESSO')
        except:
            dialog.ok(addonname, 'ERRO AO LIMPAR CACHE')

    @route
    def doar(param):
        dialog_donate = Donate()
        dialog_donate.doModal()        
