"""Cache de respostas TMDB, opcionalmente com script.module.cached, isolado por addon."""
import hashlib
import json
import os
import sqlite3
import time
import uuid
from contextlib import closing
from datetime import timedelta


class Cache:
    def __init__(self, profile, enabled=True, ttl=86400, clock=None):
        self.profile = str(profile)
        self.enabled = enabled
        self.ttl = ttl
        self.clock = clock or time.time
        self.path = os.path.join(self.profile, 'response-cache.db')
        self.epoch_file = os.path.join(self.profile, 'cache-generation.txt')
        self.backend = None
        try:
            from cached import Cache as SharedCache
            self.backend = SharedCache.get_instance()
        except (ImportError, AttributeError, RuntimeError):
            pass

    def key(self, key):
        try:
            with open(self.epoch_file, encoding='utf-8') as stream:
                generation = stream.read(64)
        except OSError:
            generation = '0'
        return 'animesplay:' + hashlib.sha256((self.profile + generation + key).encode()).hexdigest()

    def get(self, key):
        if not self.enabled:
            return None
        key = self.key(key)
        if self.backend:
            try:
                value = self.backend.get(key, hashed_key=True)
                if value is not None:
                    return value
            except Exception:
                pass
        try:
            with closing(sqlite3.connect(self.path, timeout=.5)) as conn:
                row = conn.execute('SELECT payload,expires FROM responses WHERE key=?', (key,)).fetchone()
                return json.loads(row[0]) if row and row[1] > self.clock() else None
        except (sqlite3.Error, OSError, ValueError):
            return None

    def set(self, key, value):
        if not self.enabled:
            return
        key = self.key(key)
        if self.backend:
            try:
                self.backend.set(key, value, timedelta(seconds=self.ttl), hashed_key=True)
            except Exception:
                pass
        payload = json.dumps(value, ensure_ascii=False)
        if len(payload.encode()) > 2 * 1024 * 1024:
            return
        try:
            os.makedirs(self.profile, exist_ok=True)
            with closing(sqlite3.connect(self.path, timeout=.5)) as conn, conn:
                conn.execute('CREATE TABLE IF NOT EXISTS responses(key TEXT PRIMARY KEY,payload TEXT,expires REAL)')
                conn.execute('DELETE FROM responses WHERE expires<=?', (self.clock(),))
                conn.execute('INSERT OR REPLACE INTO responses VALUES(?,?,?)', (key, payload, self.clock() + self.ttl))
                conn.execute('DELETE FROM responses WHERE key NOT IN (SELECT key FROM responses ORDER BY expires DESC LIMIT 128)')
                while conn.execute('SELECT coalesce(sum(length(CAST(payload AS BLOB))),0) FROM responses').fetchone()[0] > 16 * 1024 * 1024:
                    conn.execute('DELETE FROM responses WHERE key=(SELECT key FROM responses ORDER BY expires LIMIT 1)')
        except (sqlite3.Error, OSError):
            pass

    def clear(self):
        try:
            os.makedirs(self.profile, exist_ok=True)
            # Invalida somente chaves deste perfil no backend compartilhado.
            with open(self.epoch_file, 'w', encoding='utf-8') as stream:
                stream.write(uuid.uuid4().hex)
            if os.path.exists(self.path):
                with closing(sqlite3.connect(self.path, timeout=.5)) as conn, conn:
                    conn.execute('DELETE FROM responses')
            return True
        except (OSError, sqlite3.Error):
            return False
