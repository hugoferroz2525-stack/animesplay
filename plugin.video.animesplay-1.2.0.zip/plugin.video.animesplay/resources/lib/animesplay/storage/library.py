"""Persistência independente da interface do Kodi."""
import json,os,sqlite3,time
class Store:
 def __init__(self,profile):
  os.makedirs(profile,exist_ok=True);self.path=os.path.join(profile,'anime.db')
  with self.connect() as c:
   c.execute('CREATE TABLE IF NOT EXISTS favorites(id TEXT PRIMARY KEY,payload TEXT,updated REAL)')
   c.execute('CREATE TABLE IF NOT EXISTS searches(query TEXT PRIMARY KEY,updated REAL)')
 def connect(self):return sqlite3.connect(self.path,timeout=5)
 def favorite(self,item):
  with self.connect() as c:c.execute('INSERT OR REPLACE INTO favorites VALUES(?,?,?)',(item['id'],json.dumps(item,ensure_ascii=False),time.time()))
 def remove(self,key):
  with self.connect() as c:c.execute('DELETE FROM favorites WHERE id=?',(key,))
 def favorites(self):
  with self.connect() as c:return [json.loads(row[0]) for row in c.execute('SELECT payload FROM favorites ORDER BY updated DESC')]
 def search(self,query):
  query=query.strip()
  if query:
   with self.connect() as c:
    c.execute('INSERT OR REPLACE INTO searches VALUES(?,?)',(query,time.time()))
    c.execute('DELETE FROM searches WHERE query NOT IN (SELECT query FROM searches ORDER BY updated DESC LIMIT 30)')
 def searches(self):
  with self.connect() as c:return [r[0] for r in c.execute('SELECT query FROM searches ORDER BY updated DESC')]
