"""Campos próprios de cada item; métodos do Piers detectados por capacidade."""
def apply(item,data,xbmc):
 tag=item.getVideoInfoTag()
 fields={'title':'setTitle','plot':'setPlot','year':'setYear','duration':'setDuration','genres':'setGenres','countries':'setCountries','studios':'setStudios','season':'setSeason','episode':'setEpisode','showtitle':'setTvShowTitle','premiered':'setPremiered','originaltitle':'setOriginalTitle','mediatype':'setMediaType','original_language':'setOriginalLanguage'}
 for key,method in fields.items():
  value=data.get(key)
  if value is not None and hasattr(tag,method):getattr(tag,method)(value)
 if data.get('ids'):tag.setUniqueIDs(data['ids'],'tmdb' if 'tmdb' in data['ids'] else '')
 if data.get('cast'):tag.setCast([xbmc.Actor(c['name'],c.get('role',''),i,c.get('thumbnail','')) for i,c in enumerate(data['cast'])])
 if data.get('art'):item.setArt(data['art'])
