"""Track playback prepared by Aurora after Kodi starts audio/video."""
import json
import sqlite3
from pathlib import Path
import time
from threading import RLock
from urllib.parse import urlencode
from animesplay.metadata.aniskip import Associations, lookup

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from animesplay.storage.history import History, PENDING, media_key


class EpisodePlayer(xbmc.Player):
    def __init__(self, history, window):
        super().__init__()
        self.history = history
        self.window = window
        self.active = None
        self.lock = RLock()
        self.autoplay = False
        self.skip = ()
        self.intervals = None
        self.used = set()
        self.up_next = None

    def onAVStarted(self):
        self.finish()
        with self.lock:
            self.up_next = None
        try:
            pending = json.loads(self.window.getProperty(PENDING) or '{}')
            key = media_key(self.getPlayingFile())
            if pending.get('key') != key or pending.get('expires', 0) < time.time():
                return
            self.window.clearProperty(PENDING)
            with self.lock:
                self.active = (key, pending['item'], 0, 0)
                self.autoplay = pending.get('autoplay') is True
                self.skip = pending.get('skip', ())
                self.intervals = None
                self.used.clear()
            offset = pending.get('resume', 0)
            duration = self.getTotalTime()
            if offset and duration > offset + 5:
                self.seekTime(offset)
        except (ValueError, TypeError, KeyError, RuntimeError):
            pass

    def sample(self):
        active = self.active
        if not active:
            return
        try:
            key, item, _, _ = active
            if not self.isPlayingVideo() or media_key(self.getPlayingFile()) != key:
                return
            sample = (key, item, self.getTime(), self.getTotalTime())
            with self.lock:
                if self.active is active:
                    self.active = sample
            self.skip_interval(sample)
        except RuntimeError:
            pass

    def skip_interval(self, sample):
        if not self.skip or sample[3] <= 0:
            return
        if self.intervals is None:
            with self.lock:
                if self.active is not sample:
                    return
                self.intervals = []
            try:
                link = Associations(self.history.path.parent).get(sample[1]['id'])
                intervals = lookup(*link, sample[3]) if link else []
            except (OSError, ValueError, TypeError, sqlite3.Error):
                return
            with self.lock:
                if self.active is not sample:
                    return
                self.intervals = intervals
        with self.lock:
            if self.active is not sample:
                return
            for kind, start, end in self.intervals:
                if kind in self.skip and kind not in self.used and start <= sample[2] < end - 1:
                    self.used.add(kind)
                    self.seekTime(min(end, sample[3] - 0.2))
                    return

    def advance_if_idle(self):
        with self.lock:
            if not self.up_next or self.up_next[0] > time.monotonic():
                return
            _, item = self.up_next
            self.up_next = None
        if self.isPlaying() or self.window.getProperty(PENDING):
            return
        query = urlencode({'section': 'goyabu', 'action': 'autoplay',
                           'item': json.dumps(item, ensure_ascii=False)})
        xbmc.executebuiltin('PlayMedia(plugin://plugin.video.animesplay/?' + query + ')')

    def save(self, ended=False):
        with self.lock:
            if self.active:
                _, item, position, duration = self.active
                try:
                    self.history.save(item, position, duration, ended)
                except Exception:
                    xbmc.log('AnimesPlay: falha ao gravar progresso', xbmc.LOGWARNING)

    def finish(self, ended=False):
        with self.lock:
            self.save(ended)
            self.active = None

    def onPlayBackEnded(self):
        with self.lock:
            if self.active and self.autoplay:
                _, item, position, duration = self.active
                if duration > 0 and position >= duration * 0.85 and item.get('show_url'):
                    self.up_next = (time.monotonic() + 1, item)
            self.finish(ended=True)

    def onPlayBackStopped(self):
        with self.lock:
            self.up_next = None
            self.finish()

    def onPlayBackError(self):
        self.onPlayBackStopped()


def run():
    addon = xbmcaddon.Addon('plugin.video.animesplay')
    profile = Path(xbmcvfs.translatePath(addon.getAddonInfo('profile'))) / 'painel-goyabu'
    player = EpisodePlayer(History(profile), xbmcgui.Window(10000))
    monitor = xbmc.Monitor()
    last_save = time.monotonic()
    while not monitor.waitForAbort(2):
        player.sample()
        player.advance_if_idle()
        if time.monotonic() - last_save >= 10:
            player.save()
            last_save = time.monotonic()
    player.finish()


if __name__ == '__main__':
    run()
