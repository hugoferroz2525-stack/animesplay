"""Rotas declaradas, com script.module.routing opcional e URLs antigas preservadas."""
DIRECTORIES = {
    'home': 'home', 'recommendations': 'recommendations', 'catalog': 'catalog_page',
    'explore': 'explore', 'latest_sources': 'latest_sources', 'settings_menu': 'settings_menu',
    'sources': 'open_sources', 'latest': 'catalog_page', 'search': 'search',
    'search_history': 'search_history', 'favorites': 'favorites', 'servers': 'open_editions',
    'editions': 'open_editions', 'episodes': 'episodes', 'episode_servers': 'open_options',
    'options': 'open_options', 'next_episode': 'next_episode', 'continue': 'continue_watching',
    'genres': 'genres', 'by_genre': 'genre_catalog',
    'discover': 'discover',
}


def dispatch(query):
    from animesplay.kodi.plugin import Plugin
    try:
        from routing import Plugin as Routing
    except ImportError:
        Plugin(query).run()
        return
    router = Routing()

    @router.route('/')
    def home():
        Plugin(query).run()

    @router.route('/<action>')
    def action_route(action):
        Plugin(dict(query, action=action)).run()

    router.run()
