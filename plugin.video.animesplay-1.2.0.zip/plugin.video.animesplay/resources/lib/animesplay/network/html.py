"""Parse the visible DooPlay seasons structure used by AskFlix; no JS execution."""
import re
from html.parser import HTMLParser
from urllib.parse import urljoin,urlsplit


class Node:
    def __init__(self,tag='',attrs=()):self.tag=tag;self.attrs=dict(attrs);self.children=[];self.parts=[]
    def text(self):return ''.join(part.text() if isinstance(part,Node) else part for part in self.parts).strip()
    def find(self,predicate):
        result=[]
        for child in self.children:
            if predicate(child):result.append(child)
            result.extend(child.find(predicate))
        return result
    def has(self,name):return name in self.attrs.get('class','').split()


class Tree(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.root=Node();self.stack=[self.root]
    def handle_starttag(self,tag,attrs):
        node=Node(tag,attrs);self.stack[-1].children.append(node);self.stack[-1].parts.append(node)
        if tag not in ('img','br','input','meta','link','hr','source','wbr'):self.stack.append(node)
    def handle_endtag(self,tag):
        for index in range(len(self.stack)-1,0,-1):
            if self.stack[index].tag==tag:self.stack=self.stack[:index];break
    def handle_data(self,data):self.stack[-1].parts.append(data)


def seasons_from_html(text,base_url):
    if not isinstance(text,str) or len(text)>4*1024*1024:return []
    tree=Tree();tree.feed(text)
    roots=tree.root.find(lambda n:n.attrs.get('id')=='seasons')
    if not roots:return []
    seasons=[]
    for section in roots[0].find(lambda n:n.has('se-c')):
        numbers=section.find(lambda n:n.has('se-t'))
        if not numbers or not numbers[0].text().isdigit():continue
        number=int(numbers[0].text());episodes=[];seen=set()
        for row in section.find(lambda n:n.tag=='li'):
            title_nodes=row.find(lambda n:n.has('episodiotitle'))
            if not title_nodes:continue
            anchors=title_nodes[0].find(lambda n:n.tag=='a' and n.attrs.get('href'))
            if not anchors:continue
            anchor=anchors[0];url=urljoin(base_url,anchor.attrs['href'])
            if urlsplit(url).scheme not in ('http','https') or url in seen:continue
            numerals=row.find(lambda n:n.has('numerando'));match=re.fullmatch(r'\s*(\d+)\s*-\s*(\d+)\s*',numerals[0].text()) if numerals else None
            images=row.find(lambda n:n.tag=='img')
            episodes.append({'url':url,'title':anchor.text(),'season':number,'episode':int(match.group(2)) if match and int(match.group(1))==number else None,'thumb':urljoin(base_url,images[0].attrs.get('src','')) if images else ''});seen.add(url)
        if episodes:seasons.append({'number':number,'episodes':episodes})
    return sorted(seasons,key=lambda value:value['number'])
