"""Rank catalog entries associated with TMDB by genres in the viewing history."""
import json
from collections import Counter
from contextlib import closing

from animesplay.metadata.tmdb import db


def suggest(profile, recent, catalog, limit=20):
    watched = {item.get('show_url') for item in recent if item.get('show_url')}
    if not watched:
        return []
    with closing(db(profile)) as conn:
        rows = conn.execute("SELECT source,payload FROM titles WHERE kind='tv'")
        genres = {}
        for source, payload in rows:
            try:
                genres[source] = {row['id'] for row in json.loads(payload).get('genres', [])
                                  if type(row.get('id')) is int}
            except (ValueError, TypeError, KeyError, AttributeError):
                continue
    preference = Counter()
    for source in watched:
        preference.update(genres.get(source, ()))
    scored = []
    for item in catalog:
        source = item.get('url')
        if source in watched:
            continue
        score = sum(preference[key] for key in genres.get(source, ()))
        if score:
            scored.append((score, item))
    return [item for _, item in sorted(scored, key=lambda match: -match[0])[:limit]]
