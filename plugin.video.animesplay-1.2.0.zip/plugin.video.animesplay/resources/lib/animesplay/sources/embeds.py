"""Extrai mídia declarada sem executar JS nem modificar assinaturas."""
import html
import math
import re
import time
from urllib.parse import parse_qs, urljoin, urlsplit
from animesplay.network.html import Tree


def valid_url(url):
    try:
        if not isinstance(url, str) or any(c in url for c in ('\r', '\n', '|')):
            return False
        parsed = urlsplit(url)
        return parsed.scheme in ('https', 'http') and bool(parsed.hostname) and not (parsed.username or parsed.password)
    except ValueError:
        return False


def direct(url):
    if not valid_url(url):
        return False
    parsed = urlsplit(url)
    return bool(re.search(r'\.(mp4|m3u8|mpd|webm|mkv)$', parsed.path, re.I)
                or ((parsed.hostname == 'googlevideo.com' or parsed.hostname.endswith('.googlevideo.com'))
                    and parsed.path == '/videoplayback'))


def candidate(url, label, referer):
    if not valid_url(url):
        raise ValueError('Endereço de mídia inválido')
    params = parse_qs(urlsplit(url).query)
    expiry = (params.get('expire') or params.get('expires') or [''])[0]
    if expiry:
        try:
            value = float(expiry)
            if not math.isfinite(value) or value <= time.time() + 10:
                raise ValueError('Mídia expirada')
        except (ValueError, OverflowError):
            raise ValueError('Validade de mídia inválida') from None
    return {'url': url, 'label': str(label or 'Automático'),
            'headers': {'User-Agent': 'Mozilla/5.0', 'Referer': referer}}


def extract(markup, base):
    tree = Tree()
    tree.feed(markup)
    raw = []
    for node in tree.root.find(lambda n: n.tag in ('source', 'video') and n.attrs.get('src')):
        raw.append((node.attrs['src'], node.attrs.get('label') or node.attrs.get('data-res') or 'Automático'))
    for match in re.finditer(r'''["'](?:file|src|play_url|playUrl|stream_url|streamUrl)["']\s*[:=]\s*["'](https?:\\?/\\?/[^"'<>]+)["']''', markup, re.I):
        raw.append((match.group(1), 'Automático'))
    result, seen = [], set()
    for value, label in raw:
        value = html.unescape(value).replace('\\/', '/').replace('\\u0026', '&').replace('\\u003d', '=').replace('\\u003f', '?')
        url = urljoin(base, value)
        if not direct(url) or url in seen:
            continue
        try:
            result.append(candidate(url, label, base))
            seen.add(url)
        except ValueError:
            continue
    return result


def payload_streams(payload, referer):
    if not isinstance(payload, dict) or payload.get('success') is not True:
        return []
    data = payload.get('data')
    play = data.get('play') if isinstance(data, dict) else None
    if isinstance(play, dict):
        play = [play] if any(k in play for k in ('src', 'file', 'url')) else list(play.values())
    if not isinstance(play, list):
        return []
    result, seen = [], set()
    for row in play:
        if not isinstance(row, dict):
            continue
        url = row.get('src') or row.get('file') or row.get('url')
        if not valid_url(url) or url in seen:
            continue
        label = row.get('sizeText') or row.get('label') or row.get('size') or row.get('height') or 'Automático'
        try:
            result.append(candidate(url, label, referer))
            seen.add(url)
        except ValueError:
            continue
    return result


def unpack_strings(markup):
    """Descompacta somente a tabela de palavras do formato P.A.C.K.E.R., sem executar JS."""
    import ast
    if len(markup)>1024*1024:return ''
    match=re.search(r"\}\('((?:\\.|[^'])*)',\s*(\d+),\s*(\d+),\s*'((?:\\.|[^'])*)'\.split\('\|'\)",markup)
    if not match:return ''
    try:
        payload=ast.literal_eval("'"+match[1]+"'")
        words=ast.literal_eval("'"+match[4]+"'").split('|')
        base=int(match[2]);count=int(match[3])
        if not 2<=base<=62 or count>10000:return ''
        digits='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
        def encoded(number):return encoded(number//base)+digits[number%base] if number>=base else digits[number]
        table={encoded(i):word for i,word in enumerate(words) if word}
        return re.sub(r'\b\w+\b',lambda m:table.get(m[0],m[0]),payload).replace('\\/','/')
    except (ValueError,SyntaxError,TypeError,RecursionError):return ''
