"""Adaptadores das páginas públicas inspecionadas; cada fonte conserva seus seletores."""
import re,json,gzip
from urllib.error import HTTPError
from animesplay.playback.validation import MediaUnavailable
from urllib.parse import urljoin,urlsplit,urlencode
from animesplay.sources.public_sites import parse
from animesplay.sources.players import resolve
from animesplay.network.html import seasons_from_html


class Website:
    show_prefix='/anime/'
    ep_prefix='/episodio/'
    catalog_path='/'
    latest_path='/'
    def __init__(self,client):self.client=client
    def safe(self,href,prefix):
        u=urljoin(self.base,href or '');p=urlsplit(u)
        return u if p.hostname==urlsplit(self.base).hostname and p.path.startswith(prefix) and p.path!=prefix else ''
    def request(self,url,ttl=300):return self.client.get(url,ttl=ttl)
    def card(self,node):
        url=self.safe(node.attrs.get('href'),self.show_prefix)
        if not url or '-episode' in url:return None
        images=node.find(lambda n:n.tag=='img');heads=node.find(lambda n:n.has('title_anime')) or node.find(lambda n:n.tag in ('h2','h3'))
        title=(heads[0].text() if heads else images[0].attrs.get('alt','') if images else node.text())
        title=' '.join(title.split());title=re.sub(r'(?i)^Assistir\s+|\s+Online(?: em HD)?$','',title);title=re.sub(r'(?i)\s*(?:todos os epis[oó]dios.*|assistir online.*)$','',title).strip()
        if not title:return None
        art=next((n.attrs.get('data-src') or n.attrs.get('src') for n in node.find(lambda n:n.tag=='img' or n.attrs.get('data-src'))), '')
        audio='dub' if 'dublad' in (title+' '+url).casefold() else 'sub'
        return {'id':url,'url':url,'title':title,'provider':self.id,'icon':urljoin(self.base,art) if art else '', 'mediatype':'tvshow','audio':audio}
    def cards(self,html):
        seen={}
        for n in parse(html).find(lambda n:n.tag=='a' and n.attrs.get('href')):
            item=self.card(n)
            if item:seen.setdefault(item['url'],item)
        return list(seen.values())
    def catalog(self,page=1):
        return self.cards(self.request(self.base+self.catalog_path.lstrip('/')+('' if page==1 else '?'+urlencode({'page':page}))))
    def search(self,q,page=1):return self.cards(self.request(self.base+'?'+urlencode({'s':q,'paged':page}),180))
    def episode(self,node,parent=None):
        href=node.attrs.get('href','');url=self.safe(href,self.ep_prefix)
        if not url:return None
        text=' '.join(node.text().split())
        match=re.search(r'(?i)(?:epis[oó]dio|\bep)\s*0*(\d+)',text)
        pair=re.search(r'(\d+)[xX](\d+)',url)
        sushi=re.search(r'-(\d+)-season-(\d+)-episode',url)
        slug=re.search(r'episodio-(\d+)',url)
        number=int(match[1]) if match else int(pair[2]) if pair else int(sushi[2]) if sushi else int(slug[1]) if slug else None
        if number is None:return None
        images=node.find(lambda n:n.tag=='img');icon=images[0].attrs.get('data-src') or images[0].attrs.get('src','') if images else ''
        headings=node.find(lambda n:n.tag in ('h2','h3') or n.has('title_anime') or n.has('title'))
        showtitle=headings[0].text() if headings else re.sub(r'(?i)\s*(?:epis[oó]dio|EP)\s*\d+.*','',text).strip()
        item={'showtitle':showtitle,'id':url,'url':url,'title':text or 'Episódio '+str(number),'episode':number,'season':int(pair[1]) if pair else int(sushi[1]) if sushi else 1,'provider':self.id,'mediatype':'episode','icon':urljoin(self.base,icon) if icon else ''}
        if parent:item.update(show_url=parent['url'],showtitle=parent['title'],audio=parent.get('audio',''),icon=parent.get('icon',''))
        return item
    def episode_rows(self,html,parent=None):
        rows={}
        for n in parse(html).find(lambda n:n.tag=='a' and n.attrs.get('href')):
            item=self.episode(n,parent)
            if item:
                previous=rows.get(item['url'])
                if previous and previous['title'].startswith('Episódio ') and len(item['title'])>len(previous['title']):
                    item['icon']=item.get('icon') or previous.get('icon','');rows[item['url']]=item
                else:rows.setdefault(item['url'],item)
        return list(rows.values())
    def latest(self,page=1):return self.episode_rows(self.request(self.base+self.latest_path.lstrip('/')+('' if page==1 else '?'+urlencode({'page':page})),60))
    def episodes(self,item):
        url=item['url']
        if item.get('landing_episode'):
            parent=self.parent(url)
            if not parent:return []
            item=parent;url=item['url']
        return self.episode_rows(self.request(url,600),item)
    def parent(self,url):
        cards=self.cards(self.request(url,600));return cards[0] if cards else None
    def options(self,item):
        html=self.client.get(item['url']);tree=parse(html);choices=[]
        for frame in tree.find(lambda n:n.tag=='iframe' and (n.attrs.get('src') or n.attrs.get('data-src'))):
            target=urljoin(item['url'],frame.attrs.get('src') or frame.attrs.get('data-src'))
            if any(s in target for s in ['youtube.com','facebook.com','doubleclick','googlesyndication']):continue
            if not any(o.get('url')==target for o in choices):choices.append({'kind':'iframe','label':'Opção '+str(len(choices)+1),'url':target})
        return choices
    def resolve(self,item,option):return resolve(option['url'],self.client,item['url'])
    def next_episode(self,item):
        if not item.get('show_url'):return None
        entries=self.episodes({'url':item['show_url'],'title':item.get('showtitle',''),'audio':item.get('audio','')})
        matches=[e for e in entries if e.get('episode')==item.get('episode',-1)+1 and e.get('season',1)==item.get('season',1)]
        return matches[0] if len(matches)==1 else None

class Digital(Website):
    id='digital';base='https://animesdigital.org/';show_prefix='/anime/a/';ep_prefix='/video/a/';catalog_path='animes-legendados-online001'
    def catalog(self,page=1):
        html=self.request(self.base+self.catalog_path)
        box=parse(html).find(lambda n:n.has('menu_filter_box'))
        if not box:return self.cards(html)
        token=box[0].attrs.get('data-secury','');result=[]
        for audio in ('legendado','dublado'):
            filters={'filter_data':urlencode({'filter_letter':'0','type_url':'animes','filter_audio':audio,'filter_order':'name'}),'filter_genre_add':[],'filter_genre_del':[]}
            payload=json.loads(self.client.get(self.base+'func/listanime',post={'token':token,'pagina':page,'search':'0','limit':30,'type':'lista','filters':json.dumps(filters)},referer=self.base+self.catalog_path,headers={'X-Requested-With':'XMLHttpRequest'}))
            result.extend(dict(item,audio='dub' if audio=='dublado' else 'sub') for item in self.cards(''.join(payload.get('results',[])) if isinstance(payload.get('results'),list) else payload.get('results','')))
        return result
    def search(self,q,page=1):return self.cards(self.request(self.base+'pesquisa/?'+urlencode({'s':q,'page':page}),180))

class Sushi(Website):
    id='sushi';base='https://sushianimes.com.br/';show_prefix='/anime/';ep_prefix='/anime/';catalog_path='animes';latest_path='episodios'
    def episode(self,node,parent=None):
        if '-episode' not in node.attrs.get('href',''):return None
        return super().episode(node,parent)
    def search(self,q,page=1):
        html=self.client.get(self.base);tree=parse(html)
        token=next((n.attrs.get('value') for n in tree.find(lambda n:n.tag=='input' and n.attrs.get('name')=='_TOKEN')), '')
        return self.cards(self.client.get(self.base+'search',post={'_ACTION':'search','_TOKEN':token,'q':q},referer=self.base))
    def options(self,item):
        html=self.client.get(item['url']);tree=parse(html)
        self.token=next((n.attrs.get('value') for n in tree.find(lambda n:n.tag=='input' and n.attrs.get('name')=='_TOKEN')), '')
        ids=list(dict.fromkeys(n.attrs['data-embed'] for n in tree.find(lambda n:n.tag=='button' and n.attrs.get('data-embed','').isdigit())))
        return [{'kind':'sushi','id':i,'label':'Opção '+str(k+1)} for k,i in enumerate(ids)]
    def resolve(self,item,option):
        try:
            html=self.client.get(self.base+'ajax/embed',post={'id':option['id'],'_TOKEN':self.token},referer=item['url'],headers={'X-Requested-With':'XMLHttpRequest','X-CSRF-TOKEN':self.token,'Origin':self.base.rstrip('/')})
        except HTTPError as error:
            if error.code==403:
                body=error.read(16384)
                try:
                    if body[:2]==b'\x1f\x8b':body=gzip.decompress(body)
                    if json.loads(body).get('code')=='age_verification_required':
                        required=True
                    else:required=False
                except (ValueError,OSError):required=False
                if required:raise MediaUnavailable('Este servidor exige confirmação de idade no próprio site; escolha outro servidor.','age_verification_required')
            raise
        from animesplay.sources.embeds import extract
        candidates=extract(html,item['url'])
        if candidates:return candidates
        result=[]
        for f in parse(html).find(lambda n:n.tag=='iframe' and n.attrs.get('src')):
            result.extend(resolve(urljoin(self.base,f.attrs['src']),self.client,item['url']))
        return result

class Aniture(Website):
    id='aniture';base='https://aniture-pt.com.br/';show_prefix='/animes-e-desenhos/';ep_prefix='/episodios/';catalog_path='animes-e-desenhos/';latest_path='episodios/'
    def episodes(self,item):
        html=self.request(item['url'],600);result=[]
        for season in seasons_from_html(html,item['url']):
            for e in season['episodes']:result.append(dict(e,id=e['url'],provider=self.id,mediatype='episode',show_url=item['url'],showtitle=item['title'],audio=item.get('audio',''),icon=e.get('thumb','')))
        return result or self.episode_rows(html,item)

class Onlines(Website):
    id='onlines';base='https://animesonlines.cc/';catalog_path='lista-de-animes/';latest_path='ultimos-episodios/'
