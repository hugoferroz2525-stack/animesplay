"""Goyabu: leitura declarativa das páginas e resolução isolada por player."""
import base64
import binascii
import hashlib
import json
import re
import time
from urllib.parse import urlencode, urljoin, urlsplit
from animesplay.network.html import Tree
from animesplay.network.client import Client

BASE = 'https://goyabu.io/'


def embedded(markup, name):
    # JSON only: never eval JavaScript received from a site.
    for match in re.finditer(r'\b(?:var|let|const)\s+' + re.escape(name) + r'\s*=\s*', markup):
        try:
            value, _ = json.JSONDecoder().raw_decode(markup[match.end():])
            if isinstance(value, list):
                return value
        except (TypeError, ValueError):
            continue
    return []


def tree(markup):
    parser = Tree()
    parser.feed(markup)
    return parser.root


def address(path):
    url = urljoin(BASE, path)
    parsed = urlsplit(url)
    if (parsed.scheme != 'https' or parsed.hostname != 'goyabu.io'
            or parsed.username or parsed.password or parsed.port not in (None, 443)):
        raise ValueError('Endereço de catálogo inválido')
    return url


def decode_player(value):
    if not isinstance(value, str) or not value or len(value) > 4096:
        return ''
    try:
        value = base64.b64decode(value + '=' * (-len(value) % 4), validate=True).decode('utf-8')[::-1]
        parsed = urlsplit(value)
        if parsed.scheme in ('http', 'https') and parsed.hostname and not (parsed.username or parsed.password):
            return value
    except (ValueError, UnicodeError, binascii.Error):
        pass
    return ''


class Adapter:
    id = 'goyabu'

    def __init__(self, client=None):
        self.client = client or Client()
        self.last_trace = []
        self._options = None  # Only current invocation, never persisted.

    @staticmethod
    def listing_url(path, page):
        page = max(1, int(page))
        url = BASE + path
        return url if page == 1 else url + '?' + urlencode({'paged': page})

    def catalog(self, page=1):
        url = self.listing_url('lista-de-animes', page)
        return self.cards(self.client.get(url, ttl=600))

    def search(self, query, page=1):
        query = ' '.join(str(query).split())[:120]
        if not query:
            return []
        params = {'s': query}
        if int(page) > 1:
            params['paged'] = int(page)
        return self.cards(self.client.get(BASE + '?' + urlencode(params), ttl=180))

    def cards(self, markup):
        root = tree(markup)
        items, seen = [], set()
        for article in root.find(lambda n: n.tag == 'article' and n.has('boxAN')):
            anchors = article.find(lambda n: n.tag == 'a' and '/anime/' in n.attrs.get('href', ''))
            images = article.find(lambda n: n.tag == 'img')
            if not anchors or not images:
                continue
            try:
                url = address(anchors[0].attrs['href'])
            except ValueError:
                continue
            title = images[0].attrs.get('alt', '').strip() or anchors[0].text()
            if not title or url in seen:
                continue
            image = images[0].attrs.get('data-src') or images[0].attrs.get('src', '')
            items.append({'id': url, 'url': url, 'provider': self.id, 'title': title,
                          'icon': urljoin(BASE, image), 'mediatype': 'tvshow'})
            seen.add(url)
        return items

    def latest(self, page=1):
        root = tree(self.client.get(self.listing_url('lancamentos', page), ttl=60))
        items, seen = [], set()
        for article in root.find(lambda n: n.tag == 'article' and n.has('boxEP')):
            links = article.find(lambda n: n.tag == 'a' and n.attrs.get('href'))
            if not links:
                continue
            try:
                url = address(links[0].attrs['href'])
            except ValueError:
                continue
            if url not in seen:
                titles = article.find(lambda n: n.has('title'))
                numbers = article.find(lambda n: n.has('ep-type'))
                title = titles[0].text() if titles else ''
                number = numbers[0].text() if numbers else ''
                label = ' — '.join(part for part in (title, number) if part) or article.text()
                items.append({'id': url, 'url': url, 'provider': self.id,
                              'title': label, 'showtitle': title, 'mediatype': 'episode'})
                seen.add(url)
        return items

    def parent(self,url):
        markup=self.client.get(url)
        for node in tree(markup).find(lambda n:n.tag=='a' and '/anime/' in n.attrs.get('href','')):
            target=address(node.attrs['href'])
            if node.text():return {'id':target,'url':target,'title':node.text(),'provider':self.id,'mediatype':'tvshow'}
        return None

    def episodes(self, anime):
        markup = self.client.get(address(anime['url']), ttl=180)
        items, seen = [], set()
        for entry in embedded(markup, 'allEpisodes'):
            if not isinstance(entry, dict) or not entry.get('link'):
                continue
            try:
                url = address(entry['link'])
            except (ValueError, TypeError):
                continue
            if url in seen:
                continue
            number = str(entry.get('episodio', '')).strip()
            items.append({'id': url, 'url': url, 'provider': self.id,
                          'title': 'Episódio ' + number + (' — ' + str(entry['episode_name']) if entry.get('episode_name') else ''),
                          'showtitle': anime.get('title', ''), 'show_url': anime['url'],
                          'episode': int(number) if number.isascii() and number.isdigit() else None,
                          'audio': entry.get('audio', ''),
                          'icon': urljoin(BASE, entry.get('imagem') or ''), 'mediatype': 'episode'})
            seen.add(url)
        return items

    def next_episode(self, current):
        number = current.get('episode')
        parent = current.get('show_url')
        if type(number) is not int or not parent:
            return None
        episodes = self.episodes({'url': parent, 'title': current.get('showtitle', '')})
        previous = next((item for item in episodes if item['id'] == current.get('id')
                         and item.get('episode') == number), None)
        if not previous:
            return None
        matches = [item for item in episodes if item.get('episode') == number + 1
                   and item.get('audio', '') == previous.get('audio', '')]
        return matches[0] if len(matches) == 1 else None

    def options(self, episode):
        url = address(episode['url'])
        if self._options and self._options[0] == url and time.monotonic() - self._options[1] < 20:
            return [dict(item) for item in self._options[2]]
        markup = self.client.get(url)
        root, data = tree(markup), embedded(markup, 'playersData')
        options, seen = [], set()
        for button in root.find(lambda n: n.tag == 'button' and n.has('player-tab')):
            attrs = button.attrs
            option = None
            index = attrs.get('data-original-index', '')
            if attrs.get('data-player-type') == 'iframe':
                embed = decode_player(attrs.get('data-blogger-url-encrypted', ''))
                if embed:
                    option = {'kind': 'iframe', 'url': embed}
            elif len(index) <= 8 and index.isascii() and index.isdigit() and int(index) < len(data):
                row = data[int(index)]
                if isinstance(row, dict) and all(isinstance(row.get(key, ''), str) for key in ('select', 'blogger_token', 'url')):
                    option = {'kind': row.get('select') or '', 'token': row.get('blogger_token') or '',
                              'url': row.get('url') or ''}
            if not option:
                continue
            key = (option.get('kind'), option.get('url'), option.get('token'))
            if key in seen:
                continue
            option['label'] = button.text() or 'Automático'
            option['id'] = hashlib.sha256(json.dumps(key, ensure_ascii=False).encode()).hexdigest()[:16]
            options.append(option)
            seen.add(key)
        self._options = (url, time.monotonic(), options)
        return [dict(item) for item in options]

    def resolve(self, episode, option=None):
        from animesplay.sources.blogger.resolver import resolve, is_embed
        from animesplay.sources.embeds import extract, direct, candidate
        self.last_trace = []
        if option is None:
            return self.options(episode)

        def step(name, call):
            started = time.monotonic()
            try:
                result = call()
                self.last_trace.append({'stage': name, 'status': 'ok' if result else 'empty',
                                        'count': len(result), 'elapsed_ms': int((time.monotonic() - started) * 1000)})
                return result
            except Exception as error:
                self.last_trace.append({'stage': name, 'status': 'failed', 'reason': type(error).__name__,
                                        'elapsed_ms': int((time.monotonic() - started) * 1000)})
                return []
        embed = option.get('url', '')
        token = option.get('token', '')
        if token and not is_embed(embed):
            decoded = decode_player(token)
            if is_embed(decoded):
                embed = decoded
            elif re.fullmatch(r'[A-Za-z0-9_-]{16,2048}', token):
                embed = 'https://www.blogger.com/video.g?' + urlencode({'token': token})
        if is_embed(embed):
            result = step('blogger_rpc_or_embed', lambda: resolve(embed, self.client))
            if result:
                return result
        elif direct(embed):
            return step('direct_media', lambda: [candidate(embed, option.get('label', 'Automático'), address(episode['url']))])
        if option.get('kind') == 'blogger' and token:
            result = step('source_decoder', lambda: self.resolve_source(episode, option))
            if result:
                return result
        if embed and not is_embed(embed) and not direct(embed):
            return step('embed_media', lambda: extract(self.client.get(embed, referer=address(episode['url'])), embed))
        return []

    def resolve_source(self, episode, option):
        from animesplay.sources.embeds import payload_streams
        if option.get('kind') != 'blogger' or not option.get('token'):
            return []
        text = self.client.get(BASE + 'wp-admin/admin-ajax.php',
                               post={'action': 'decode_blogger_video', 'token': option['token']},
                               referer=address(episode['url']), headers={'Origin': BASE.rstrip('/'),
                               'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json, text/plain, */*'})
        return payload_streams(json.loads(text), address(episode['url']))
