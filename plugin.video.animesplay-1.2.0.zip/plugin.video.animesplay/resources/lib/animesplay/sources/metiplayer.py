"""Resolvedor HTTP do fluxo público Meti → bridge → temporizador → JW Player.

Sem Chromium, eval de JavaScript ou armazenamento de tokens de reprodução.
"""
import json
import base64
import binascii
import re
import time
from urllib.parse import parse_qsl, parse_qs, urlencode, urljoin, urlsplit, urlunsplit

from animesplay.network.client import USER_AGENT
from animesplay.network.html import Tree
from animesplay.playback.validation import MediaUnavailable

GATES = {'metilinksemvoce.site', 'www.metilinksemvoce.site'}
WRAPPERS = GATES | {'subsbr.net', 'www.subsbr.net', 'metianimesonline.org', 'www.metianimesonline.org'}


def string_value(markup, pattern):
    match = re.search(pattern + r'\s*("(?:[^"\\]|\\.)*")', markup)
    if not match:
        return ''
    try:
        return json.loads(match[1])
    except ValueError:
        return ''


def sources(markup, base):
    seen = set()
    for match in re.finditer(r'\bsources\s*:\s*(\[)', markup):
        try:
            entries, _ = json.JSONDecoder().raw_decode(markup[match.start(1):])
        except ValueError:
            continue
        if not isinstance(entries, list):
            continue
        for entry in entries:
            if not isinstance(entry, dict) or entry.get('drm'):
                continue
            url = urljoin(base, entry.get('file') or '')
            if (urlsplit(url).scheme == 'https' and url not in seen and entry.get('file')):
                seen.add(url)
                yield {'url': url, 'label': entry.get('label') or 'MP4 / HLS',
                       'headers': {'Referer': base, 'User-Agent': USER_AGENT}}


class Resolver:
    def __init__(self, client, cancelled=None, progress=None, sleeper=None, clock=None, audio=''):
        self.client = client
        self.audio = audio
        self.cancelled = cancelled or (lambda: False)
        self.progress = progress or (lambda percent, message: None)
        self.sleep = sleeper or time.sleep
        self.clock = clock or time.monotonic

    def check(self):
        if self.cancelled():
            from animesplay.playback.engine import PlaybackCancelled
            raise PlaybackCancelled()

    def wait(self, seconds):
        if seconds > 90:
            raise MediaUnavailable('O serviço pediu uma espera maior que o limite. Tente mais tarde.')
        until = self.clock() + max(0, seconds)
        while self.clock() < until:
            self.check()
            left = until - self.clock()
            self.progress(30, 'Liberando player: aguarde {} s...'.format(int(left) + 1))
            self.sleep(min(.25, left))

    def playerflix(self, url):
        match = re.fullmatch(r'/(serie)/(\d+)/(\d+)/(\d+)/?', urlsplit(url).path)
        if not match:
            raise MediaUnavailable('Identificação do episódio PlayerFlix não reconhecida.')
        params = {'type': 'tv', 'id': match[2], 'season': match[3], 'episode': match[4]}
        endpoint = urljoin(url, '/inc/Ajax.php') + '?' + urlencode(params)
        data = json.loads(self.client.get(endpoint, referer=url, headers={'X-Requested-With': 'XMLHttpRequest'}))
        if data.get('status') is not True:
            raise MediaUnavailable('O player alternativo não disponibilizou este episódio.')
        # Somente options pertence ao episódio solicitado; prev/next não são fontes dele.
        options = data.get('data', {}).get('options', [])
        if self.audio in ('dub','sub') and isinstance(options,list):
            options=[o for o in options if isinstance(o,dict) and ((str(o.get('lang','')).lower() in ('pt-br','pt','por')) == (self.audio=='dub'))]
            if not options:raise MediaUnavailable('Este servidor não oferece o áudio selecionado neste episódio.')
        result = []
        for option in options if isinstance(options, list) else []:
            if not isinstance(option, dict):
                continue
            embed = option.get('embed', '')
            parsed = urlsplit(embed)
            if parsed.hostname != 'playerflix.ink' or parsed.path != '/players/native/index.php':
                continue
            encoded = parse_qs(parsed.query).get('video_url', [''])[0]
            try:
                media = base64.b64decode(encoded + '=' * (-len(encoded) % 4), validate=True).decode('utf-8')
            except (ValueError, UnicodeError, binascii.Error):
                continue
            if urlsplit(media).scheme != 'https' or not re.search(r'\.(?:mp4|m3u8|mpd|webm)$', urlsplit(media).path, re.I):
                continue
            result.append({'url': media, 'label': option.get('label') or 'Nativo',
                           'headers': {'Referer': embed, 'User-Agent': USER_AGENT}})
        if result:
            return result
        from animesplay.sources.players import resolve
        for option in options if isinstance(options, list) else []:
            if isinstance(option, dict) and option.get('embed') and option.get('id') != 'superflixapi':
                try:
                    result = resolve(option['embed'], self.client, url)
                    if result:
                        return result
                except (OSError, ValueError):
                    continue
        raise MediaUnavailable('Nenhuma fonte nativa foi fornecida pelo player alternativo.')

    def resolve(self, episode, provider):
        if provider not in ('proplayer_leg', 'myembed', 'proplayer_dub'):
            raise MediaUnavailable('Provedor não reconhecido.')
        parts = urlsplit(episode)
        if parts.hostname not in {'metianimesonline.org', 'www.metianimesonline.org'} or not parts.path.startswith('/episodio/'):
            raise MediaUnavailable('Página do episódio inválida.')
        query = dict(parse_qsl(parts.query)); query['xp_player'] = provider
        url = urlunsplit(parts._replace(query=urlencode(query), fragment=''))
        self.progress(5, 'Abrindo player MetiAnimes...')
        html = self.client.get(url)
        url = self.client.final_url or url
        for step in range(10):
            self.check()
            host = urlsplit(url).hostname
            if host == 'playerflix.ink':
                return self.playerflix(url)
            if host in GATES:
                base = string_value(html, r'const\s+base\s*=')
                destination = string_value(html, r'(?:var|const|let)\s+destination\s*=')
                if base:
                    delay = re.search(r'const\s+delay\s*=\s*(\d+)', html)
                    self.wait(int(delay[1]) / 1000 if delay else 2)
                    target = urlsplit(urljoin(url, base))
                    params = dict(parse_qsl(target.query));params.update(__mpc_evt='1', __mpc_wd='0')
                    target = urlunsplit(target._replace(query=urlencode(params)))
                elif destination:
                    self.wait(.65)
                    target = urljoin(url, destination)
                else:
                    raise MediaUnavailable('A verificação do intermediário mudou. Atualize o addon.')
                if urlsplit(target).hostname not in WRAPPERS:
                    raise MediaUnavailable('Redirecionamento inesperado no intermediário.')
                html = self.client.get(target)
                url = self.client.final_url or target
                continue
            if host in {'subsbr.net', 'www.subsbr.net'}:
                token = string_value(html, r"searchParams\.set\(['\"]token['\"],")
                if not token:
                    raise MediaUnavailable('O intermediário não liberou o token do player.')
                delay = re.search(r"parseInt\(['\"](\d+)['\"],\s*10\)", html)
                self.wait(int(delay[1]) if delay else 30)
                unlock = urljoin(url, '/topanimeshd.php') + '?' + urlencode({'token': token, 'unlock': '1'})
                for retry in range(3):
                    try:
                        data = json.loads(self.client.get(unlock, referer=url))
                    except Exception as error:
                        from urllib.error import HTTPError
                        if isinstance(error, HTTPError) and error.code == 425:
                            self.wait(3)
                            continue
                        raise
                    if data.get('wait'):
                        self.wait(min(90, max(1, int(data['wait']))))
                        continue
                    target = data.get('proplayer', '')
                    if not data.get('ok') or urlsplit(target).hostname not in {'metianimesonline.org', 'www.metianimesonline.org'}:
                        raise MediaUnavailable('A liberação do player não foi confirmada.')
                    break
                else:
                    raise MediaUnavailable('O temporizador não liberou o player. Tente novamente.')
                self.progress(70, 'Player liberado. Localizando vídeo...')
                html = self.client.get(target)
                url = self.client.final_url or target
                continue
            parser = Tree();parser.feed(html)
            frames = parser.root.find(lambda n: n.tag == 'iframe' and n.attrs.get('id') in ('ppFrame', 'video-player'))
            if frames:
                target = urljoin(url, frames[0].attrs.get('src') or frames[0].attrs.get('data-src') or '')
                if urlsplit(target).scheme != 'https' or target == url:
                    raise MediaUnavailable('Endereço do player inválido.')
                referer = urlunsplit(urlsplit(url)._replace(path='/', query='', fragment=''))
                html = self.client.get(target, referer=referer)
                url = self.client.final_url or target
                continue
            if host not in WRAPPERS:
                result = list(sources(html, url))
                if result:
                    self.progress(90, 'Validando a mídia do episódio...')
                    return result
            raise MediaUnavailable('O player não disponibilizou uma fonte de vídeo reconhecida.')
        raise MediaUnavailable('O serviço repetiu redirecionamentos demais.')
