"""RPC público Blogger adaptado ao transporte do AnimeSoul.
Base: trecho AnimeSoul enviado pelo usuário; licença e créditos no pacote.
"""
import json,re
from urllib.error import URLError
from http.client import HTTPException
from urllib.parse import urlsplit,parse_qs,urlencode
from animesplay.sources.blogger.rpc import streams

HOSTS=('www.blogger.com','blogger.com')
def is_embed(url):
 try:
  parsed=urlsplit(url)
  return parsed.scheme=='https' and parsed.hostname in HOSTS and parsed.path=='/video.g' and not parsed.username and not parsed.password
 except (TypeError,ValueError):return False

def resolve(url,client):
 if not is_embed(url):return []
 token=parse_qs(urlsplit(url).query).get('token',[''])[0]
 if not re.fullmatch(r'[A-Za-z0-9_-]{16,2048}',token):return []
 markup=client.get(url)
 if 'Video is unavailable' in markup or 'class="errorMessage"' in markup:return []
 bootstrap={}
 match=re.search(r'(?:window\.)?WIZ_global_data\s*=\s*',markup)
 if match:
  try:
   data,_=json.JSONDecoder().raw_decode(markup[match.end():])
   if isinstance(data,dict):bootstrap=data
  except ValueError:pass
 for key in ('FdrFJe','cfb2h','SNlM0e'):
  if key not in bootstrap:
   found=re.search('"'+key+r'"\s*:\s*("(?:[^"\\]|\\.)*")',markup)
   if found:
    try:bootstrap[key]=json.loads(found.group(1))
    except ValueError:pass
 sid=bootstrap.get('FdrFJe');result=[]
 if isinstance(sid,str) and 0<len(sid)<=1000:
  inner=json.dumps([token,'',0],separators=(',',':'))
  payload=json.dumps([[['WcwnYd',inner,None,'generic']]],separators=(',',':'))
  params={'rpcids':'WcwnYd','source-path':'/video.g','f.sid':sid,'hl':'pt-BR','rt':'c','_reqid':'100001'}
  build=bootstrap.get('cfb2h')
  if isinstance(build,str) and len(build)<=1000:params['bl']=build
  form={'f.req':payload};at=bootstrap.get('SNlM0e')
  if isinstance(at,str) and len(at)<=4096:form['at']=at
  try:
   text=client.get('https://www.blogger.com/_/BloggerVideoPlayerUi/data/batchexecute?'+urlencode(params),post=form,referer=url)
   result=streams(text,'https://www.blogger.com/')
  except (ValueError,TypeError,OSError,URLError,HTTPException):result=[]
 if result:return result
 from animesplay.sources.embeds import extract
 return extract(markup,url)
