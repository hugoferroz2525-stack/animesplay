"""Leitura limitada de respostas RPC Blogger; não altera URLs assinadas."""
import json,re,time,math
from urllib.parse import urlsplit,parse_qs

def streams(body,referer,now=None):
 now=time.time() if now is None else now;urls=[]
 def walk(value,depth=0):
  if depth>10:return
  if isinstance(value,(list,dict)):
   for child in (value.values() if isinstance(value,dict) else value):walk(child,depth+1)
  elif isinstance(value,str):
   if value.startswith('https://'):
    p=urlsplit(value);host=(p.hostname or '').lower()
    if host=='googlevideo.com' or host.endswith('.googlevideo.com'):urls.append(value)
   elif value[:1] in ('[','{') and len(value)<=1048576:
    try:walk(json.loads(value),depth+1)
    except ValueError:pass
 for line in body.splitlines():
  if 'wrb.fr' not in line:continue
  for pos in re.finditer(r'[\[{]',line):
   try:obj,_=json.JSONDecoder().raw_decode(line[pos.start():]);walk(obj);break
   except ValueError:continue
 result=[];seen=set();heights={'18':360,'22':720,'37':1080,'38':3072,'59':480,'78':480}
 for url in urls:
  if url in seen:continue
  seen.add(url);p=urlsplit(url)
  if p.username or p.password:continue
  query=parse_qs(p.query);itag=query.get('itag',[''])[0];height=heights.get(itag)
  if not height:continue
  expiry=query.get('expire',query.get('expires',['']))[0]
  if expiry:
   try:
    if not math.isfinite(float(expiry)) or float(expiry)<=now+10:continue
   except ValueError:continue
  result.append({'url':url,'label':str(height)+'p','headers':{'User-Agent':'Mozilla/5.0','Referer':referer}})
 return sorted(result,key=lambda v:int(v['label'][:-1]),reverse=True)
