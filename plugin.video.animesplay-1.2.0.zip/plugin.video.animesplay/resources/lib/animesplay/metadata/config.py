"""Configuração de cliente TMDB do Flix fornecido pelo usuário.
Pode ser substituída por chave/token pessoal nos ajustes do addon.
"""
DEFAULT_API_KEY = 'eee9ac1822295afd8dadb555a0cc4ea8'
