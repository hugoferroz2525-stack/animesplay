"""Identidades automáticas conservadoras; associação manual sempre prevalece."""
import re,unicodedata
from concurrent.futures import ThreadPoolExecutor
from animesplay.metadata.tmdb import API,saved_records,store_identity,season_episode_records
from animesplay.catalog.grouping import AUDIO_MARKERS


def normalized(title):
    title=AUDIO_MARKERS.sub('',title or '')
    return ''.join(c for c in unicodedata.normalize('NFKD',title.casefold()) if c.isalnum() and not unicodedata.combining(c))


class Enricher:
    def __init__(self,profile,token,enabled=True):
        self.profile=profile;self.api=API(profile,token,enabled=enabled)
    def show(self,item):
        if item.get('mediatype')=='episode':return item
        variants=item.get('variants',[item]);urls=[v.get('url') for v in variants]
        saved=saved_records(self.profile,urls)
        record=next((saved[u] for u in urls if u in saved),None)
        if record is None:
            results=self.api.get('search/tv',{'query':AUDIO_MARKERS.sub('',item['title']).strip()}).get('results',[])
            target=normalized(item['title'])
            matches=[r for r in results if target in (normalized(r.get('name')),normalized(r.get('original_name'))) and 16 in r.get('genre_ids',[]) and (not item.get('year') or str(item['year'])==(r.get('first_air_date') or '')[:4])]
            if len(matches)!=1:return item
            data=self.api.get('tv/'+str(matches[0]['id']),{'append_to_response':'credits,external_ids,images,videos,content_ratings','include_image_language':'pt,en,null'})
            record=('tv',data)
        kind,data=record
        if kind not in ('tv','movie'):return item
        for v in variants:
            if v.get('url') and not v.get('landing_episode') and v['url'] not in saved:store_identity(self.profile,v['url'],kind,data)
        art={}
        if data.get('poster_path'):
            art.update(poster='https://image.tmdb.org/t/p/w500'+data['poster_path'],thumb='https://image.tmdb.org/t/p/w500'+data['poster_path'])
        if data.get('backdrop_path'):art['fanart']='https://image.tmdb.org/t/p/w1280'+data['backdrop_path']
        return dict(item,art=art,plot=data.get('overview',''),tmdb_id=data['id'],_tmdb_title=data.get('name') or data.get('title'),year=int((data.get('first_air_date') or data.get('release_date') or '0')[:4] or 0))
    def shows(self,items):
        def safe(item):
            try:return self.show(item)
            except (OSError,ValueError,KeyError):return item
        with ThreadPoolExecutor(max_workers=3) as pool:return list(pool.map(safe,items))
    def episodes(self,parent,items):
        try:
            record=saved_records(self.profile,[parent['url']]).get(parent['url'])
            if not record or record[0] not in ('tv','season'):return items
            kind,show=record
            show_id=show['id'] if kind=='tv' else show.get('_series_id')
            if not show_id:return items
            existing=saved_records(self.profile,[i['url'] for i in items])
            for season in sorted({i.get('season',1) for i in items}):
                season_data=self.api.get('tv/{}/season/{}'.format(show_id,season),{'append_to_response':'credits,images,videos','include_image_language':'pt,en,null'})
                season_data.update(_series_id=show_id,_series_name=show.get('name') or show.get('_series_name',''),_match_episode_numbers=True,backdrop_path=show.get('backdrop_path'),genres=show.get('genres',[]))
                records=season_episode_records(('season',season_data),[i for i in items if i.get('season',1)==season])
                def detail(pair):
                    source,rec=pair
                    if source in existing:return pair
                    kind,data=rec
                    try:
                        extra=self.api.get('tv/{}/season/{}/episode/{}'.format(show_id,season,data['episode_number']),{'append_to_response':'credits,external_ids,images,videos','include_image_language':'pt,en,null'})
                        return source,(kind,dict(data,**extra))
                    except (OSError,ValueError,KeyError):return pair
                with ThreadPoolExecutor(max_workers=3) as pool:
                    records=dict(pool.map(detail,records.items()))
                for item in items:
                    rec=existing.get(item['url']) or records.get(item['url'])
                    if not rec:continue
                    _,data=rec
                    item['episode_title']=data.get('name','');item['plot']=data.get('overview','');item['premiered']=data.get('air_date','')
                    if data.get('still_path'):item['icon']='https://image.tmdb.org/t/p/w780'+data['still_path']
                    item['art']={'fanart':'https://image.tmdb.org/t/p/w1280'+show['backdrop_path']} if show.get('backdrop_path') else {}
                    if item['url'] not in existing:store_identity(self.profile,item['url'],'episode',data)
        except (OSError,ValueError,KeyError):pass
        return items
