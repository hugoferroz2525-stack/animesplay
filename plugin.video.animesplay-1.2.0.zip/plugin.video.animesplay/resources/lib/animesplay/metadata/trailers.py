"""Select a trailer using an explicitly chosen TMDB identity."""
import re
from urllib.parse import urlencode

from animesplay.metadata.tmdb import fetch

VIDEO_ID = re.compile(r'[A-Za-z0-9_-]{11}')


def youtube_route(results):
    for row in results:
        key = row.get('key')
        if (row.get('type') == 'Trailer' and row.get('site') == 'YouTube'
                and isinstance(key, str) and VIDEO_ID.fullmatch(key)):
            return 'plugin://plugin.video.youtube/play/?' + urlencode({'video_id': key})
    return ''


def find_trailer(kind, identifier, token, api=None):
    if kind not in ('movie', 'tv') or not re.fullmatch(r'[1-9][0-9]{0,14}', str(identifier)):
        raise ValueError('Identidade TMDB inválida')
    for language in ('pt-BR', 'ja-JP', 'en-US'):
        path = '{}/{}/videos'.format(kind, identifier)
        result = api.get(path, {'language': language}) if api else fetch(path, token, {'language': language}, timeout=6)
        route = youtube_route(result.get('results', []))
        if route:
            return route
    return ''
