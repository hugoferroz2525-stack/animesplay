"""User-selected TMDB identity; cached locally, no network during directory display."""
import json
import os
import re
import sqlite3
import time
from contextlib import closing
from animesplay.metadata.config import DEFAULT_API_KEY
from animesplay.storage.cache import Cache
import hashlib
from urllib.parse import urlencode
from urllib.request import Request, urlopen


def db(profile):
    os.makedirs(profile, exist_ok=True)
    c = sqlite3.connect(os.path.join(profile, 'metadata.db'), timeout=3)
    c.execute('CREATE TABLE IF NOT EXISTS titles(source TEXT PRIMARY KEY, kind TEXT, payload TEXT, updated REAL)')
    return c


def fetch(path, token, params=None, timeout=10):
    query = {'language': 'pt-BR'}
    query.update(params or {})
    headers = {'Accept': 'application/json'}
    if re.fullmatch(r'[a-fA-F0-9]{32}', token.strip()):
        query['api_key'] = token.strip()
    else:
        headers['Authorization'] = 'Bearer ' + token.strip()
    req = Request('https://api.themoviedb.org/3/' + path + '?' + urlencode(query), headers=headers)
    with urlopen(req, timeout=timeout) as response:
        return json.load(response)


class API:
    """Consultas reaproveitadas, com idioma e credencial isolados na chave."""
    def __init__(self, profile, token, enabled=True, ttl=86400):
        self.token = token
        self.cache = Cache(profile, enabled=enabled, ttl=ttl)

    def get(self, path, params=None):
        key = json.dumps([path, params or {}, hashlib.sha256(self.token.encode()).hexdigest()], sort_keys=True)
        value = self.cache.get(key)
        if value is not None:
            return value
        value = fetch(path, self.token, params)
        if isinstance(value, dict) and not value.get('success') is False:
            self.cache.set(key, value)
        return value

    def discover(self, page=1):
        return self.get('discover/tv', {'with_genres': '16', 'with_origin_country': 'JP',
                        'sort_by': 'popularity.desc', 'include_adult': 'false', 'page': max(1, int(page))})


def identify(profile, source, label, addon, xbmc, gui):
    token = addon.getSetting('tmdb_token').strip() or DEFAULT_API_KEY
    if not token:
        gui.Dialog().ok('TMDB', 'Configure seu token de leitura TMDB nas configurações do AnimesPlay.')
        addon.openSettings()
        return
    kind_index = gui.Dialog().select('Tipo de título', ['Filme', 'Série / anime / dorama', 'Temporada', 'Episódio'])
    if kind_index < 0:
        return
    kind = ['movie', 'tv', 'season', 'episode'][kind_index]
    search_kind = 'movie' if kind == 'movie' else 'tv'
    query = gui.Dialog().input('Título para identificar', defaultt=re.sub(r'\[/?(?:B|I|COLOR[^\]]*)\]', '', label or '', flags=re.I))
    if not query.strip():
        return
    try:
        api = API(profile, token, enabled=addon.getSetting('metadata_cache_enabled') != 'false',
                  ttl=metadata_ttl(addon))
        results = api.get('search/' + search_kind, {'query': query}).get('results', [])
        if not results:
            gui.Dialog().ok('TMDB', 'Nenhum resultado. Tente o título original.')
            return
        labels = ['%s (%s)' % (r.get('title') or r.get('name'), (r.get('release_date') or r.get('first_air_date') or 'sem data')[:4]) for r in results]
        choice = gui.Dialog().select('Confirme o título e o ano', labels)
        if choice < 0:
            return
        selected = results[choice]
        path = '%s/%d' % (search_kind, selected['id'])
        season_number = episode_number = None
        if kind in ('season', 'episode'):
            value = gui.Dialog().numeric(0, 'Número da temporada (0 = especiais)')
            if not value or not value.isdigit():
                return
            season_number = int(value)
            path += '/season/%d' % season_number
        if kind == 'episode':
            value = gui.Dialog().numeric(0, 'Número do episódio no TMDB')
            if not value or not value.isdigit() or int(value) < 1:
                return
            episode_number = int(value)
            path += '/episode/%d' % episode_number
        data = api.get(path, {'append_to_response': 'credits,external_ids,images,videos' + (',release_dates' if kind == 'movie' else ',content_ratings' if kind == 'tv' else '')})
        if kind in ('season', 'episode'):
            data['_series_name'] = selected.get('name', '')
            data['_series_id'] = selected['id']
            data['season_number'] = season_number
            if episode_number is not None:
                data['episode_number'] = episode_number
            confirmation = '%s • T%d%s • %s' % (data['_series_name'], season_number, (' E%d' % episode_number) if episode_number is not None else '', data.get('name', ''))
            if not gui.Dialog().yesno('Confirmar associação TMDB', confirmation):
                return
        if kind == 'season':
            data['_match_episode_numbers'] = gui.Dialog().yesno(
                'Numeração dos episódios', 'Os números desta edição coincidem com esta temporada no TMDB?')
        store_identity(profile, source, kind, data)
        xbmc.executebuiltin('Container.Refresh()')
        gui.Dialog().notification('AnimesPlay', 'Metadados associados ao título')
    except Exception:
        # Never log token, request headers or credential-bearing errors.
        gui.Dialog().ok('TMDB', 'Não foi possível consultar o TMDB. Confira o token e a conexão.')


def saved_records(profile, sources):
    urls = list(dict.fromkeys(url for url in sources if url))
    if not urls:
        return {}
    placeholders = ','.join('?' for _ in urls)
    records = {}
    try:
        with closing(db(profile)) as conn:
            rows = conn.execute('SELECT source,kind,payload FROM titles WHERE source IN (' + placeholders + ')',
                                urls)
            for source, kind, payload in rows:
                try:
                    records[source] = (kind, json.loads(payload))
                except ValueError:
                    continue
    except (OSError, sqlite3.Error):
        pass
    return records


def season_episode_records(season, items):
    if not season or season[0] != 'season' or not season[1].get('_match_episode_numbers'):
        return {}
    data = season[1]
    episodes = {}
    for entry in data.get('episodes', []):
        number = entry.get('episode_number')
        if type(number) is int and entry.get('season_number') == data.get('season_number'):
            episodes[number] = entry if number not in episodes else None
    records = {}
    for item in items:
        episode = episodes.get(item.get('episode'))
        if episode:
            enriched = dict(episode,
                            _series_name=data.get('_series_name', ''),
                            backdrop_path=data.get('backdrop_path'),
                            genres=data.get('genres', []),
                            credits={'cast': episode.get('guest_stars', []), 'crew': episode.get('crew', [])})
            records[item['url']] = ('episode', enriched)
    return records


def apply_saved(item, profile, source, xbmc, record=None):
    try:
        if record is None:
            record = saved_records(profile, [source]).get(source)
        if not record:
            return
        kind, d = record
        tag = item.getVideoInfoTag()
        tag.setMediaType({'movie': 'movie', 'tv': 'tvshow', 'season': 'season', 'episode': 'episode'}[kind])
        if kind in ('season', 'episode'):
            tag.setSeason(int(d['season_number']))
            tag.setTvShowTitle(d.get('_series_name', ''))
        if kind == 'episode':
            tag.setEpisode(int(d['episode_number']))
        tag.setTitle(d.get('title') or d.get('name') or '')
        tag.setOriginalTitle(d.get('original_title') or d.get('original_name') or '')
        tag.setPlot(d.get('overview') or '')
        tag.setGenres([v['name'] for v in d.get('genres', []) if v.get('name')])
        date = d.get('release_date') or d.get('first_air_date') or d.get('air_date')
        if date:
            tag.setPremiered(date)
            tag.setYear(int(date[:4]))
        if d.get('tagline'):
            tag.setTagLine(d['tagline'])
        studios = [v['name'] for v in d.get('production_companies', []) if v.get('name')]
        if studios:
            tag.setStudios(studios)
        countries = [v['name'] for v in d.get('production_countries', []) if v.get('name')]
        if countries:
            tag.setCountries(countries)
        crew = d.get('credits', {}).get('crew', [])
        directors = list(dict.fromkeys(v['name'] for v in crew if v.get('job') == 'Director' and v.get('name')))
        writers = list(dict.fromkeys(v['name'] for v in crew if v.get('department') == 'Writing' and v.get('name')))
        if directors:
            tag.setDirectors(directors)
        if writers:
            tag.setWriters(writers)
        certification = ''
        for entry in d.get('release_dates', {}).get('results', []):
            if entry.get('iso_3166_1') == 'BR':
                certification = next((r.get('certification') for r in entry.get('release_dates', []) if r.get('certification')), '')
        for entry in d.get('content_ratings', {}).get('results', []):
            if entry.get('iso_3166_1') == 'BR':
                certification = entry.get('rating', '')
        if certification:
            tag.setMpaa('BR: ' + certification)
        if d.get('runtime'):
            tag.setDuration(int(d['runtime']) * 60)
        ids = {'tmdb': str(d['id'])}
        imdb = (d.get('external_ids') or {}).get('imdb_id') or d.get('imdb_id')
        if imdb:
            ids['imdb'] = imdb
        tag.setUniqueIDs(ids, 'tmdb')
        if d.get('vote_count'):
            tag.setRating(float(d.get('vote_average', 0)), int(d['vote_count']), 'tmdb', True)
        cast = [xbmc.Actor(v['name'], v.get('character', ''), int(v.get('order', 0)), 'https://image.tmdb.org/t/p/w185' + v['profile_path'] if v.get('profile_path') else '') for v in d.get('credits', {}).get('cast', [])[:30] if v.get('name')]
        if cast:
            tag.setCast(cast)
        art = {}
        for field, target in [('poster_path','poster'), ('backdrop_path','fanart'), ('still_path','thumb')]:
            if d.get(field):
                art[target] = 'https://image.tmdb.org/t/p/w780' + d[field]
        if kind == 'season' and d.get('_show_poster'):
            art['tvshow.poster'] = 'https://image.tmdb.org/t/p/w780' + d['_show_poster']
        if kind in ('season','episode') and d.get('backdrop_path'):
            art['tvshow.fanart'] = 'https://image.tmdb.org/t/p/w780' + d['backdrop_path']
        if kind in ('tv','movie') and art.get('poster'):art['thumb']=art['poster']
        if art:
            item.setArt(art)
    except Exception:
        pass  # Optional metadata must never prevent the original list item from appearing.



def store_identity(profile, source, kind, data):
    aliases = [source]
    if kind == 'tv' and source.startswith('animes2='):
        aliases.append('resolver3_tvshows='+source.split('=',1)[1])
    if kind == 'tv' and source.startswith(('#series_list=','#animes_list=','#doramas_list=')):
        aliases += [part for part in source.split('=',1)[1].split('|') if re.match(r'^resolver[1-5]_tvshows=',part)]
        aliases += ['resolver3_tvshows='+part.split('=',1)[1] for part in source.split('=',1)[1].split('|') if part.startswith('animes2=')]
    with closing(db(profile)) as c, c:
        for alias in aliases:
            c.execute('INSERT OR REPLACE INTO titles VALUES(?,?,?,?)',(alias,kind,json.dumps(data),time.time()))


def metadata_ttl(addon):
    try:
        return (86400, 3 * 86400, 7 * 86400)[int(addon.getSetting('metadata_cache_days') or 0)]
    except (TypeError, ValueError, IndexError):
        return 86400
