"""Orquestra reprodução dentro do Kodi, sem navegador ou API auxiliar."""
import time
from urllib.error import HTTPError
from animesplay.playback.validation import probe,MediaUnavailable
class PlaybackCancelled(Exception):pass

def option_key(option):return option.get('kind','')+'|'+option.get('label','')+('|' + option['id'] if option.get('id') is not None else '')
def candidate_key(candidate):
 headers=tuple(sorted((name.lower(),value) for name,value in (candidate.get('headers') or {}).items()))
 return candidate['url'],headers
def height(candidate):
 import re
 match=re.search(r'(\d{3,4})',str(candidate.get('label','')))
 return int(match.group(1)) if match else 0

class Engine:
 def __init__(self,adapter,validator=None):
  self.adapter=adapter;self.validator=validator or (lambda stream:probe(stream,adapter.client.opener));self.trace=[];self.checked=set()
 def event(self,stage,status,start,count=0,reason=''):
  item={'stage':stage,'status':status,'elapsed_ms':int((time.monotonic()-start)*1000),'count':count}
  if reason:item['reason']=reason
  self.trace.append(item)
 def play(self,episode,choice='auto',select=None,cancelled=None,accept=None):
  self.trace=[];self.checked=set();cancelled=cancelled or (lambda:False)
  self.adapter.cancelled=cancelled
  if cancelled():raise PlaybackCancelled()
  start=time.monotonic();options=self.adapter.options(episode);self.event('episode_options','ok',start,len(options))
  if choice!='auto':
   options=[option for option in options if option_key(option)==choice]
   if not options:raise MediaUnavailable('A opção escolhida mudou ou não está mais disponível. Abra novamente o episódio.')
  options=options[:4];resolved_embeds=set();last_reason='Nenhuma opção entregou mídia válida.'
  for option in options:
   if cancelled():raise PlaybackCancelled()
   # Embed repetido: não repetir RPC; a API própria ainda pode entregar outra mídia.
   embed=option.get('url');attempts=[];source_attempted=False
   if not embed or embed not in resolved_embeds:
    attempts.append(('player_resolution',lambda option=option:self.adapter.resolve(episode,option)))
    if embed:resolved_embeds.add(embed)
   if option.get('kind')=='blogger':attempts.append(('secondary_decoder',lambda option=option:self.adapter.resolve_source(episode,option)))
   for stage,resolve in attempts:
    if stage=='secondary_decoder' and source_attempted:continue
    if cancelled():raise PlaybackCancelled()
    start=time.monotonic()
    try:
     candidates=resolve() or []
     if stage=='player_resolution':
      for event in getattr(self.adapter,'last_trace',[]):
       self.trace.append({key:event[key] for key in ('stage','status','reason','count','elapsed_ms') if key in event})
     self.event(stage,'ok' if candidates else 'empty',start,len(candidates))
    except PlaybackCancelled:raise
    except MediaUnavailable as error:last_reason=str(error);self.event(stage,'failed',start,reason=error.code);continue
    except HTTPError as error:last_reason='O servidor recusou o player (HTTP {}). Tente outro servidor.'.format(error.code);self.event(stage,'failed',start,reason='http_'+str(error.code));continue
    except Exception as error:self.event(stage,'failed',start,reason=type(error).__name__);continue
    if stage=='player_resolution':source_attempted=any(event.get('stage')=='source_decoder' for event in getattr(self.adapter,'last_trace',[]))
    ordered=sorted(candidates,key=height,reverse=True)
    ordered=[c for c in ordered if c.get('url') and candidate_key(c) not in self.checked][:8]
    if choice!='auto' and select and len(ordered)>1:
     index=select([candidate['label'] for candidate in ordered])
     if not 0<=index<len(ordered):raise PlaybackCancelled()
     ordered=[ordered[index]]+ordered[:index]+ordered[index+1:]
    for candidate in ordered:
     if cancelled():raise PlaybackCancelled()
     key=candidate_key(candidate)
     if key in self.checked:continue
     self.checked.add(key);start=time.monotonic()
     try:
      if hasattr(getattr(self.adapter,'client',None),'media_headers'):
       headers=self.adapter.client.media_headers(candidate['url'],candidate.get('headers',{}))
       if isinstance(headers,dict):candidate=dict(candidate,headers=headers)
      media=self.validator(candidate)
      if accept and not accept(media):
       raise MediaUnavailable('O formato exige um componente de reprodução adicional.','unsupported_format')
      self.event('media_validation','ok',start,1);return media
     except MediaUnavailable as error:last_reason=str(error);self.event('media_validation','failed',start,reason=getattr(error,'code',type(error).__name__))
     except Exception as error:self.event('media_validation','failed',start,reason=type(error).__name__)
  raise MediaUnavailable(last_reason)
