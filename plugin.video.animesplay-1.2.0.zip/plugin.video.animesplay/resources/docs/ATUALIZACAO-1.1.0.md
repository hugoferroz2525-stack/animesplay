# AnimesPlay 1.1.0 — revisão e validação

Atualização do pacote `plugin.video.animesplay-1.0.13.zip` enviado pelo usuário. Os quatro outros addons foram consultados como referência; seus ZIPs originais não foram alterados.

## Mudanças concretas

- `sources/metiplayer.py`: segue o fluxo público Meti → intermediário → liberação → iframe → fontes JSON do JW Player, preservando parâmetros assinados e cookies somente durante a chamada. Respeita o tempo remoto e permite cancelar. No alternativo MyEmbed, segue o iframe PlayerFlix e lê a API AJAX com os IDs do episódio; usa a fonte nativa HLS e preserva o resolvedor Blogger como alternativa quando não há fonte nativa. Não confunde os dados `prev_episode`/`next_episode` da API com o episódio atual. Não executa JavaScript remoto. A validação lê somente o início da mídia antes de entregá-la ao Kodi.
- `network/client.py`: cache das rotas públicas de catálogo das três fontes, com limite de 64 páginas / 8 MiB; players, episódios, POSTs, tokens e URLs de mídia ficam fora. HTTP 429 é controlado por domínio, para uma fonte não bloquear as outras.
- `storage/cache.py`: consultas TMDB em cache por caminho, parâmetros e credencial; backend `script.module.cached` quando disponível e SQLite local como alternativa. Até 128 respostas e 16 MiB no armazenamento local. Limpar cache não apaga favoritos, progresso ou associações manuais.
- `kodi/routes.py`: registro único de rotas; integração opcional com `script.module.routing`, com funcionamento pela rota antiga caso o módulo não esteja instalado. URLs `?section=goyabu&action=...` continuam válidas.
- `metadata/tmdb.py`: cache de busca, detalhes e destaques; configuração padrão antiga retornava HTTP 401. A configuração do Flix fornecido foi testada e passou a ser o padrão. O ajuste de chave/token pessoal continua substituindo essa configuração.
- Menus: Continuar assistindo, Últimos episódios, Explorar animes, Buscar em todas as fontes, Minha lista, Destaques TMDB e Ajustes. Ícones/fundo locais, decoração opcional, gêneros Meti e manutenção de cache.
- Corrigido o menu “Ver outros episódios”, que perdia o identificador da fonte ao montar o item pai. Mensagens de erro agora usam AnimesPlay, inclusive quando a fonte não é Goyabu. Cancelamento do resolvedor não é engolido pelo motor de reprodução.

## Referências revisadas

| Addon | O que foi examinado / aplicado |
| --- | --- |
| Brazuca Matrix | Menu decorado, categorias, cor branca/dourada, persistência SQLite e separação de opções de player; usado como referência visual/estrutural. O conteúdo ofuscado foi lido estaticamente, sem execução. |
| Flix | `lib/tmdb.py`, `lib/navigation.py`, ajustes de cache e dependências. Cache opcional com `cached`, rotas com `routing`, idioma, detalhes TMDB e configuração de cliente. A cópia integral exigiria a API interna e várias dependências do Flix; a integração usa os módulos do AnimesPlay. |
| YouTube 7.4.0.1 | Manifesto, armazenamento SQL e rota pública de reprodução por `video_id`. Trailers continuam delegados ao addon YouTube instalado/configurado no Kodi. |
| Spartan 0.0.7 | Entrada e configuração: o ZIP contém um carregador de scripts remotos. O código remoto não foi executado nem importado no AnimesPlay. Recursos visuais/navegação foram usados somente como referência. |

## Consultas reais nesta revisão

| Consulta | Resultado | Itens |
| --- | --- | --- |
| metianimes:catalog | ok | 24 |
| metianimes:search | ok | 1 |
| metianimes:latest | ok | 20 |
| animesonlinecc:latest | ok | 20 |
| animesonlinecc:catalog | ok | 20 |
| animesonlinecc:search | ok | 1 |
| goyabu:catalog | ok | 30 |
| goyabu:latest | ok | 30 |
| metianimes:genres | ok | 13 |
| goyabu:search | ok | 6 |
| tmdb:discover | ok | 20 |

O motor `Engine` resolveu um episódio Meti real em MP4, fonte anunciada como 1080p. Foram confirmados o HTTP da mídia e o contêiner; o episódio completo não foi baixado. Registros sem URLs assinadas ou credenciais estão em `validacao-meti.json` e `validacao-fontes.json`.

## Limites e instalação

Kodi não está instalado neste ambiente. Não houve teste de reprodução audiovisual, instalação, controle remoto ou renderização de skin em Kodi real. Os testes automatizados simulam a API Kodi; eles não substituem conferir um episódio no seu aparelho. Os módulos opcionais `cached` e `routing` foram testados por seus contratos simulados; as alternativas locais também são testadas.
Todas as fontes podem mudar ou negar acesso por IP/aparelho. O resultado ao vivo de catálogo/busca não confirma todos os episódios do Goyabu ou do AnimesOnlineCC. Credenciais de YouTube e serviços de legendas, quando exigidas por esses addons, continuam sendo configuradas neles.
Se a fonte alterar a verificação para CAPTCHA visual, autenticação ou outro fluxo, será necessária manutenção do adaptador. O resolvedor lê fontes publicadas pelo player e não implementa descriptografia de DRM.

Instale o ZIP como atualização, abra o addon e teste **Últimos episódios → MetiAnimesOnline → episódio → Reproduzir automaticamente**. Ajustes de aparência/cache e chave TMDB estão em **Ajustes e manutenção → Configurações**. Em caso de falha, o motor salva `last-playback-diagnostic.json` no perfil, sem gravar os links de vídeo.

## Verificações automatizadas

76 testes locais passaram, incluindo API do provedor alternativo, rotas com módulo opcional, manutenção do provedor no item pai, espera cancelável, TTL, limpeza sem perda de associações, cache entre invocações, compactação, histórico, próxima reprodução, AniSkip e empacotamento. O ZIP final é novamente extraído e testado.

Validação final ao vivo: Pro Player → MP4 1080p; MyEmbed/PlayerFlix → HLS nativo em outro episódio. Ambos retornaram mídia reconhecida pelo validador do motor. A segunda abertura dos catálogos MetiAnimes, AnimesOnlineCC e Goyabu registrou `cache: hit`. Consultas TMDB retornaram 20 destaques e reutilizaram o cache. Evidências em `validacao-meti-alternativo.json` e `validacao-fontes.json`.
