import sys,json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock,patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'lib'))
from animesplay.sources.players import resolve
from animesplay.sources.websites import Digital,Sushi,Aniture,Onlines
from animesplay.catalog.grouping import group
from animesplay.metadata.enrichment import Enricher
from animesplay.metadata.tmdb import store_identity,saved_records
from animesplay.playback.engine import Engine
from animesplay.playback.validation import MediaUnavailable

class RevisionTests(unittest.TestCase):
    def test_vip_keeps_secured_signature_and_uses_published_api(self):
        c=Mock();c.get.side_effect=['<html>Embedplayer</html>',json.dumps({'securedLink':'https://embedplayer2.xyz/cdn/hls/a/master.m3u8?md5=signed&expires=9999999999','videoSource':'https://embedplayer2.xyz/internal.txt'})]
        media=resolve('https://embedplayer2.xyz/video/'+'a'*32,c,'https://playerflix.ink/')
        self.assertEqual(media[0]['url'],'https://embedplayer2.xyz/cdn/hls/a/master.m3u8?md5=signed&expires=9999999999')
        self.assertEqual(c.get.call_args.kwargs['post']['hash'],'a'*32)
    def test_anivideo_wrapper_decodes_only_public_parameter(self):
        media=resolve('https://api.anivideo.net/videohls.php?d=https%3A%2F%2Fcdn.example%2Fep.m3u8',Mock())
        self.assertEqual(media[0]['url'],'https://cdn.example/ep.m3u8')
    def test_digital_ajax_catalog_handles_list_of_html_cards(self):
        c=Mock();card='<a href="https://animesdigital.org/anime/a/test"><span class="title_anime">Test</span></a>'
        c.get.side_effect=['<div class="menu_filter_box" data-secury="nonce"></div>',json.dumps({'results':[card]}),json.dumps({'results':[card.replace('/test','/test-dublado')]})]
        rows=Digital(c).catalog()
        self.assertEqual([r['audio'] for r in rows],['sub','dub']);self.assertEqual(rows[0]['title'],'Test')
    def test_nested_groups_keep_every_server(self):
        items=[{'id':'a','url':'a','title':'One Piece','provider':'goyabu'},{'id':'b','url':'b','title':'One-Piece Dublado','provider':'digital'}]
        rows=group(group(items));self.assertEqual(len(rows),1);self.assertEqual(len(rows[0]['variants']),2)
    def test_quality_failure_tries_other_quality(self):
        adapter=SimpleNamespace(options=lambda _: [{'kind':'test','label':'test'}],resolve=lambda *_:[{'url':'https://cdn.example/a','label':'1080p'},{'url':'https://cdn.example/b','label':'720p'}])
        def validate(s):
            if s['url'].endswith('/a'):raise MediaUnavailable('Recusada')
            return s
        result=Engine(adapter,validate).play({},choice='test|test',select=lambda _:0)
        self.assertTrue(result['url'].endswith('/b'))
    def test_each_episode_receives_its_own_tmdb_data(self):
        with tempfile.TemporaryDirectory() as profile:
            store_identity(profile,'show','tv',{'id':12,'name':'Anime','backdrop_path':'/backdrop.jpg'})
            e=Enricher(profile,'example');e.api=Mock()
            e.api.get.side_effect=[{'id':20,'season_number':1,'episodes':[{'id':21,'season_number':1,'episode_number':1,'name':'Primeiro','overview':'Sinopse 1','still_path':'/one.jpg'},{'id':22,'season_number':1,'episode_number':2,'name':'Segundo','overview':'Sinopse 2','still_path':'/two.jpg'}]}, {'id':21,'episode_number':1,'season_number':1,'name':'Primeiro','overview':'Sinopse 1','still_path':'/one.jpg'}, {'id':22,'episode_number':2,'season_number':1,'name':'Segundo','overview':'Sinopse 2','still_path':'/two.jpg'}]
            rows=e.episodes({'url':'show'},[{'url':'ep1','episode':1},{'url':'ep2','episode':2}])
            self.assertEqual([r['episode_title'] for r in rows],['Primeiro','Segundo'])
            self.assertNotEqual(rows[0]['icon'],rows[1]['icon']);self.assertEqual(len(saved_records(profile,['ep1','ep2'])),2)
    def test_episode_opens_playback_with_requested_label_and_context(self):
        with patch.dict(sys.modules,{name:Mock() for name in ('xbmc','xbmcgui','xbmcplugin','xbmcaddon','xbmcvfs')}):
            from animesplay.kodi.plugin import Plugin
            p=Plugin.__new__(Plugin);p.profile='unused';p.row=Mock();p.context=Mock(return_value=[('Escolher player','RunPlugin(test)')])
            with patch('animesplay.kodi.plugin.saved_records',return_value={}):p.listing([{'url':'ep','id':'ep','title':'Old','episode_title':'Nome','episode':3,'mediatype':'episode'}])
            self.assertEqual(p.row.call_args.args,('[B] EPISÓDIO 03:[/B] [COLOR yellow]Nome[/COLOR]','play'))
            self.assertFalse(p.row.call_args.kwargs['folder']);self.assertEqual(p.row.call_args.kwargs['choice'],'auto')

    def test_latest_show_art_does_not_overwrite_episode_identity(self):
        with tempfile.TemporaryDirectory() as profile:
            e=Enricher(profile,'example');e.api=Mock()
            e.api.get.side_effect=[{'results':[{'id':1,'name':'Anime','genre_ids':[16]}]}, {'id':1,'name':'Anime','first_air_date':'2000-01-01','poster_path':'/poster.jpg','backdrop_path':'/back.jpg'}]
            item=e.show({'id':'ep','url':'ep','title':'Anime','mediatype':'tvshow','landing_episode':True})
            self.assertIn('poster',item['art'])
            self.assertEqual(saved_records(profile,['ep']),{})
