import json
import base64
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
from urllib.parse import parse_qs, urlsplit

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'lib'))

from animesplay.network.client import Client, catalog_page
from animesplay.playback.engine import Engine, PlaybackCancelled
from animesplay.playback.validation import MediaUnavailable
from animesplay.sources.metiplayer import Resolver, sources
from animesplay.storage.cache import Cache
from animesplay.metadata.tmdb import API, saved_records, store_identity


class FlowClient:
    """Contrato independente: respostas do servidor e relógio do temporizador."""
    def __init__(self, extra_wait=False):
        self.final_url = ''
        self.urls = []
        self.now = 0
        self.extra_wait = extra_wait

    def get(self, url, **kwargs):
        self.urls.append(url)
        if '/episodio/' in url:
            self.final_url = 'https://www.metilinksemvoce.site/topanimes.php?go=fixture'
            return 'var destination="/bridge.php?go=fixture";'
        if '/bridge.php' in url:
            self.final_url = 'https://subsbr.net/topanimeshd.php?token=fixture'
            return '''const total=Math.max(0,parseInt('30',10)||0);
            u.searchParams.set('token',"fixture");'''
        if 'unlock=1' in url:
            if self.now < 30:
                raise AssertionError('Não deve ignorar a espera do servidor')
            self.final_url = url
            if self.extra_wait:
                self.extra_wait = False
                return json.dumps({'wait': 2})
            return json.dumps({'ok': True, 'proplayer': 'https://metianimesonline.org/player.php?id=fixture'})
        if '/player.php' in url:
            self.final_url = url
            return '<video src="https://ad.invalid/ad.mp4"></video><iframe id="ppFrame" data-src="https://player.example/embed"></iframe>'
        if url == 'https://player.example/embed':
            self.final_url = url
            return 'jwplayer("p").setup({sources: [{"file":"https://cdn.example/episode.mp4?sig=temporary","label":"1080p"}]})'
        raise AssertionError('Endereço inesperado')

    def sleep(self, duration):
        self.now += duration


class ResolverTests(unittest.TestCase):
    def resolve(self, client, **kw):
        return Resolver(client, sleeper=client.sleep, clock=lambda: client.now, **kw).resolve(
            'https://metianimesonline.org/episodio/test', 'proplayer_leg')

    def test_complete_http_flow_and_wait(self):
        client = FlowClient()
        result = self.resolve(client)
        self.assertGreaterEqual(client.now, 30)
        self.assertEqual(result[0]['label'], '1080p')
        self.assertEqual(result[0]['headers']['Referer'], 'https://player.example/embed')
        self.assertNotIn('ad.invalid', result[0]['url'])
        self.assertEqual(len(client.urls), 5)

    def test_server_can_extend_wait(self):
        client = FlowClient(extra_wait=True)
        self.resolve(client)
        self.assertGreaterEqual(client.now, 32)

    def test_signed_challenge_keeps_signature_and_nonce(self):
        client = FlowClient()
        get = client.get
        def response(url, **kwargs):
            if '/episodio/' in url:
                client.final_url = 'https://www.metilinksemvoce.site/topanimes.php'
                return 'const base="/bridge.php?__mpc_sig=original%26sig&__mpc_nonce=abc";const delay=1500;'
            return get(url, **kwargs)
        client.get = response
        self.resolve(client)
        params = parse_qs(urlsplit(client.urls[0]).query)
        self.assertEqual(params['__mpc_sig'], ['original&sig'])
        self.assertEqual(params['__mpc_nonce'], ['abc'])
        self.assertEqual(params['__mpc_evt'], ['1'])

    def test_cancel_is_not_swallowed_by_playback_engine(self):
        adapter = SimpleNamespace(options=lambda _: [{'kind': 'metiplayer'}],
                                  resolve=Mock(side_effect=PlaybackCancelled()))
        with self.assertRaises(PlaybackCancelled):
            Engine(adapter).play({})

    def test_wait_can_be_cancelled_without_finishing(self):
        client = FlowClient()
        with self.assertRaises(PlaybackCancelled):
            self.resolve(client, cancelled=lambda: client.now >= 2)
        self.assertLess(client.now, 3)
        self.assertEqual(len(client.urls), 2)

    def test_json_only_source_parser(self):
        html = 'sources: [not_json]; sources: [{"file":"javascript:alert(1)"},{"file":"https://cdn.example/a.mp4","drm":{"widevine":{}}}]'
        self.assertEqual(list(sources(html, 'https://provider.example/')), [])

    def test_unexpected_gate_destination_stops(self):
        client = FlowClient()
        client.get = Mock(return_value='var destination="https://unexpected.example/";')
        client.final_url = 'https://www.metilinksemvoce.site/topanimes.php'
        with self.assertRaisesRegex(MediaUnavailable, 'inesperado'):
            self.resolve(client)
        self.assertEqual(client.get.call_count, 1)

    def test_alternate_native_stream_belongs_to_current_episode(self):
        client = Mock()
        encoded = base64.b64encode(b'https://cdn.example/06.mp4/index.m3u8').decode()
        client.get.return_value = json.dumps({'status': True, 'data': {
            'prev_episode': {'embed': 'https://cdn.example/05.mp4'},
            'options': [{'embed': 'https://playerflix.ink/players/native/index.php?video_url=' + encoded,
                         'label': 'Nativo Principal'}],
            'next_episode': {'embed': 'https://cdn.example/07.mp4'}}})
        result = Resolver(client).playerflix('https://playerflix.ink/serie/312359/1/6')
        self.assertEqual([item['url'] for item in result], ['https://cdn.example/06.mp4/index.m3u8'])
        self.assertEqual(client.get.call_args.kwargs['headers']['X-Requested-With'], 'XMLHttpRequest')

    def test_alternate_does_not_accept_server_failure_as_media(self):
        client = Mock()
        client.get.return_value = '{"status":false}'
        with self.assertRaises(MediaUnavailable):
            Resolver(client).playerflix('https://playerflix.ink/serie/312359/1/6')


class CacheTests(unittest.TestCase):
    def test_ttl_clear_and_identities_are_independent(self):
        with tempfile.TemporaryDirectory() as profile, patch.dict(sys.modules, {'cached': None}):
            cache = Cache(profile, ttl=10, clock=lambda: 100)
            cache.set('path', {'value': 1})
            self.assertEqual(Cache(profile, clock=lambda: 105).get('path'), {'value': 1})
            self.assertIsNone(Cache(profile, clock=lambda: 111).get('path'))
            store_identity(profile, 'https://source.example/show', 'tv', {'id': 1})
            cache.clear()
            self.assertIsNone(cache.get('path'))
            self.assertIn('https://source.example/show', saved_records(profile, ['https://source.example/show']))

    def test_disabled_cache_does_not_write(self):
        with tempfile.TemporaryDirectory() as profile:
            cache = Cache(profile, enabled=False)
            cache.set('x', {})
            self.assertIsNone(cache.get('x'))
            self.assertFalse(Path(cache.path).exists())

    def test_optional_cached_backend_is_namespaced_and_clear_is_local(self):
        backend = Mock()
        backend.get.return_value = {'ok': 1}
        with tempfile.TemporaryDirectory() as profile, patch.dict(sys.modules, {'cached': SimpleNamespace(Cache=SimpleNamespace(get_instance=lambda: backend))}):
            cache = Cache(profile)
            self.assertEqual(cache.get('x'), {'ok': 1})
            key = backend.get.call_args.args[0]
            cache.set('x', {'ok': 2})
            cache.clear()
            self.assertNotEqual(cache.key('x'), key)
            backend.clear.assert_not_called()

    def test_catalog_cache_accepts_only_public_routes(self):
        for url in ('https://metianimesonline.org/animes/?pagina=2', 'https://animesonlinecc.to/anime/page/2/'):
            self.assertTrue(catalog_page(urlsplit(url)))
        for url in ('https://metianimesonline.org/episodio/test', 'https://metianimesonline.org/animes/?xp_player=myembed',
                    'https://subsbr.net/topanimeshd.php?token=private', 'https://metianimesonline.org/player.php?id=private'):
            self.assertFalse(catalog_page(urlsplit(url)))

    def test_rate_limit_is_per_host(self):
        with tempfile.TemporaryDirectory() as profile:
            client = Client(profile, clock=lambda: 100)
            client._remember_catalog_delay('30', 'goyabu.io')
            self.assertEqual(client._catalog_delay('metianimesonline.org'), 0)
            self.assertEqual(Client(profile, clock=lambda: 105)._catalog_delay('goyabu.io'), 25)

    def test_tmdb_reuses_cached_responses_and_isolates_credentials(self):
        with tempfile.TemporaryDirectory() as profile, patch.dict(sys.modules, {'cached': None}), patch(
                'animesplay.metadata.tmdb.fetch', return_value={'results': [{'id': 1}]}) as request:
            api = API(profile, 'token-one')
            self.assertEqual(api.discover(), api.discover())
            request.assert_called_once()
            API(profile, 'token-two').discover()
            self.assertEqual(request.call_count, 2)


class NavigationTests(unittest.TestCase):
    def test_optional_routing_runs_existing_query(self):
        from animesplay.kodi.routes import dispatch
        factory = Mock()
        class Routing:
            def __init__(self):
                self.handlers = {}
            def route(self, path):
                def register(fn):
                    self.handlers[path] = fn
                    return fn
                return register
            def run(self):
                self.handlers['/']()
        with patch.dict(sys.modules, {'routing': SimpleNamespace(Plugin=Routing),
                                     'animesplay.kodi.plugin': SimpleNamespace(Plugin=factory)}):
            dispatch({'action': 'catalog', 'provider': 'metianimes'})
        factory.assert_called_once_with({'action': 'catalog', 'provider': 'metianimes'})
        factory.return_value.run.assert_called_once()

    def test_parent_context_keeps_episode_source(self):
        modules = {name: Mock() for name in ('xbmc', 'xbmcaddon', 'xbmcgui', 'xbmcplugin', 'xbmcvfs')}
        with patch.dict(sys.modules, modules):
            from animesplay.kodi.plugin import Plugin
            plugin = Plugin.__new__(Plugin)
            plugin.base = 'plugin://plugin.video.animesplay/'
            plugin.addon = Mock()
            plugin.addon.getAddonInfo.return_value = 'plugin.video.animesplay'
            context = plugin.context({'url': 'https://metianimesonline.org/episodio/test',
                                      'show_url': 'https://metianimesonline.org/anime/test',
                                      'title': 'Test', 'provider': 'metianimes'})
        command = next(value for name, value in context if name == 'Ver outros episódios')
        query = parse_qs(urlsplit(command[len('Container.Update('):-1]).query)
        self.assertEqual(json.loads(query['item'][0])['provider'], 'metianimes')

    def test_home_is_seven_local_shortcuts(self):
        with patch.dict(sys.modules, {name: Mock() for name in ('xbmc', 'xbmcaddon', 'xbmcgui', 'xbmcplugin', 'xbmcvfs')}):
            from animesplay.kodi.plugin import Plugin
            plugin = Plugin.__new__(Plugin)
            plugin.menu = Mock()
            plugin.home()
            self.assertEqual(plugin.menu.call_count, 7)
            self.assertIn('discover', [call.args[1] for call in plugin.menu.call_args_list])


if __name__ == '__main__':
    unittest.main()
