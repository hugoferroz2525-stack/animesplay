import importlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'lib'))

from animesplay.catalog.recommendations import suggest
from animesplay.metadata.aniskip import Associations, markers
from animesplay.metadata.tmdb import store_identity
from animesplay.storage.history import History


class CompletionTests(unittest.TestCase):
    def test_markers_match_duration_and_reject_ambiguity(self):
        def row(kind, start, end, length=1440):
            return {'skipType': kind, 'episodeLength': length,
                    'interval': {'startTime': start, 'endTime': end}}
        payload = {'results': [row('op', 8, 95), row('ed', 1340, 1425),
                               row('op', 18, 120, 1430), row('op', 1, float('inf'))]}
        self.assertEqual(markers(payload, 1440), [('op', 8, 95), ('ed', 1340, 1425)])
        payload['results'].append(row('op', 18, 120))
        self.assertEqual(markers(payload, 1440), [('ed', 1340, 1425)])

    def test_mal_link_is_episode_specific(self):
        with tempfile.TemporaryDirectory() as profile:
            links = Associations(profile)
            links.save('episode-a', 42, 2)
            self.assertEqual(links.get('episode-a'), (42, 2))
            self.assertIsNone(links.get('episode-b'))
            links.remove('episode-a')
            self.assertIsNone(links.get('episode-a'))

    def test_recommendations_use_watched_genres_and_current_catalog(self):
        with tempfile.TemporaryDirectory() as profile:
            history = History(profile)
            history.save({'id': 'ep', 'show_url': 'seen'}, 95, 100)
            history.save({'id': 'partial', 'show_url': 'part'}, 20, 100)
            for source, ids in [('seen', [1, 2]), ('good', [1, 2]), ('okay', [2]),
                                ('part', [3]), ('unrelated', [3]), ('not-listing', [1, 2])]:
                store_identity(profile, source, 'tv', {'genres': [{'id': value} for value in ids]})
            catalog = [{'url': value} for value in ['seen', 'okay', 'good', 'unrelated']]
            self.assertEqual(suggest(profile, history.recently_watched(), catalog),
                             [{'url': 'good'}, {'url': 'okay'}])

    def test_auto_advance_runs_only_after_natural_end_and_only_once(self):
        stub = SimpleNamespace(Player=object, executebuiltin=Mock())
        name = 'animesplay.kodi.progress'
        with patch.dict(sys.modules, {'xbmc': stub, 'xbmcaddon': Mock(), 'xbmcgui': Mock(),
                                      'xbmcvfs': Mock()}):
            sys.modules.pop(name, None)
            module = importlib.import_module(name)
        player = module.EpisodePlayer(Mock(), Mock(getProperty=Mock(return_value='')))
        player.isPlaying = lambda: False
        player.autoplay = True
        item = {'id': 'ep', 'show_url': 'https://goyabu.io/anime/a'}
        player.active = ('key', item, 95, 100)
        player.onPlayBackStopped()
        player.advance_if_idle()
        stub.executebuiltin.assert_not_called()
        with patch.object(module.time, 'monotonic', side_effect=[50, 52]):
            player.active = ('key', item, 95, 100)
            player.onPlayBackEnded()
            player.advance_if_idle()
        self.assertIn('action=autoplay', stub.executebuiltin.call_args.args[0])
        player.advance_if_idle()
        stub.executebuiltin.assert_called_once()

    def test_opening_is_skipped_once_within_its_interval(self):
        stub = SimpleNamespace(Player=object)
        name = 'animesplay.kodi.progress'
        with patch.dict(sys.modules, {'xbmc': stub, 'xbmcaddon': Mock(), 'xbmcgui': Mock(),
                                      'xbmcvfs': Mock()}):
            sys.modules.pop(name, None)
            module = importlib.import_module(name)
        player = module.EpisodePlayer(Mock(), Mock())
        player.seekTime = Mock()
        player.skip = ('op',)
        player.intervals = [('op', 5, 90), ('ed', 1300, 1390)]
        player.active = ('key', {'id': 'ep'}, 10, 1440)
        player.skip_interval(player.active)
        player.skip_interval(player.active)
        player.seekTime.assert_called_once_with(90)
