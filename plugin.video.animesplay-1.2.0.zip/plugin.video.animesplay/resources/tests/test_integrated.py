import importlib
import json
import sys
import tempfile
import time
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
from urllib.error import HTTPError

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'lib'))

from animesplay.playback.validation import MediaUnavailable
from animesplay.network.client import Client
from animesplay.playback.engine import Engine
from animesplay.metadata.trailers import find_trailer
from animesplay.storage.history import History, PENDING, media_key


class IntegratedTests(unittest.TestCase):
    def test_resume_position_belongs_to_episode_after_media_changes(self):
        modules = {
            'xbmc': SimpleNamespace(Player=object),
            'xbmcaddon': Mock(), 'xbmcgui': Mock(), 'xbmcvfs': Mock(),
        }
        with patch.dict(sys.modules, modules):
            player_class = importlib.import_module('animesplay.kodi.progress').EpisodePlayer
        with tempfile.TemporaryDirectory() as profile:
            history = History(profile)
            episode = {'id': 'episode-2', 'title': 'Ep. 2', 'url': 'https://example.com/ep2'}
            window = Mock()
            player = player_class(history, window)
            player.getTotalTime = lambda: 240
            player.getTime = lambda: 52
            player.isPlayingVideo = lambda: True
            player.seekTime = Mock()
            for host in ('one', 'two'):
                file = 'https://{}.invalid/ep.mp4'.format(host)
                player.getPlayingFile = lambda: file
                window.getProperty.return_value = json.dumps({
                    'item': episode, 'key': media_key(file),
                    'resume': history.resume(episode['id']), 'expires': time.time() + 60,
                })
                player.onAVStarted()
                player.sample()
                player.onPlayBackStopped()
            player.seekTime.assert_called_once_with(52)
            self.assertEqual(window.clearProperty.call_args.args, (PENDING,))
            self.assertEqual(history.unfinished(), [(episode, 52)])
            history.save(episode, 220, 240)
            self.assertEqual(history.unfinished(), [])

    def test_history_omits_player_data(self):
        with tempfile.TemporaryDirectory() as profile:
            history = History(profile)
            history.save({'id': 'ep', 'url': 'page', 'headers': {'token': 'secret'}}, 20, 100)
            self.assertEqual(history.unfinished(), [({'id': 'ep', 'url': 'page'}, 20)])

    def test_same_media_url_with_different_headers(self):
        frames = [{'url': 'https://media.invalid/example', 'headers': {'Referer': host}}
                  for host in ('wrong', 'right')]
        adapter = SimpleNamespace(options=lambda _: [{'kind': 'iframe'}], resolve=lambda *_: frames)

        def validate(candidate):
            if candidate['headers']['Referer'] == 'wrong':
                raise MediaUnavailable('Sem mídia')
            return dict(candidate, mime='video/mp4')

        self.assertEqual(Engine(adapter, validate).play({})['headers']['Referer'], 'right')

    def test_dash_unsupported_falls_back_to_mp4(self):
        frames = [{'url': 'https://media.invalid/' + format, 'mime': mime}
                  for format, mime in [('dash', 'application/dash+xml'), ('mp4', 'video/mp4')]]
        adapter = SimpleNamespace(options=lambda _: [{'kind': 'iframe'}], resolve=lambda *_: frames)
        result = Engine(adapter, lambda media: media).play({}, accept=lambda item: item['mime'] == 'video/mp4')
        self.assertEqual(result['mime'], 'video/mp4')

    @patch('animesplay.metadata.trailers.fetch')
    def test_trailer_fallback_validates_youtube_id_and_language(self, fetch):
        fetch.side_effect = [
            {'results': [{'type': 'Trailer', 'site': 'YouTube', 'key': 'x&foo=y'}]},
            {'results': [{'type': 'Trailer', 'site': 'YouTube', 'key': '01234abcDEF'}]},
        ]
        self.assertEqual(find_trailer('tv', 42, 'example'),
                         'plugin://plugin.video.youtube/play/?video_id=01234abcDEF')
        self.assertEqual([call.args[2]['language'] for call in fetch.call_args_list], ['pt-BR', 'ja-JP'])

    def test_429_delay_survives_new_client_and_leaves_media_alone(self):
        with tempfile.TemporaryDirectory() as profile:
            page = 'https://goyabu.io/lista-de-animes'
            opener = Mock()
            opener.open.side_effect = HTTPError(page, 429, 'rate', {'Retry-After': '20'}, None)
            with self.assertRaises(HTTPError):
                Client(profile, opener=opener, clock=lambda: 100).get(page, ttl=60)
            opener.reset_mock()
            next_client = Client(profile, opener=opener, clock=lambda: 110)
            with self.assertRaises(HTTPError):
                next_client.get(page, ttl=60)
            opener.open.assert_not_called()
            with self.assertRaises(HTTPError):
                next_client.get('https://media.invalid/player')
            opener.open.assert_called_once()
            with self.assertRaises(HTTPError):
                Client(profile, opener=opener, clock=lambda: 121).get(page, ttl=60)
            self.assertEqual(opener.open.call_count, 2)

    def test_kodi_episode_listing_and_resolved_playback_are_connected(self):
        import runpy
        from urllib.parse import parse_qs, urlencode, urlsplit

        episode = {'id': 'episode-2', 'url': 'https://goyabu.io/75765', 'title': 'Ep. 2',
                   'mediatype': 'episode'}
        markup = ('var playersData=[{"select":"direct","url":"https://cdn.invalid/video.mp4"}];'
                  '<button class="player-tab" data-original-index="0">HD</button>')
        modules = {name: Mock() for name in ('xbmc', 'xbmcgui', 'xbmcplugin', 'xbmcaddon', 'xbmcvfs')}
        gui, plugin = modules['xbmcgui'], modules['xbmcplugin']
        gui.DialogProgress.return_value.iscanceled.return_value = False
        client = Mock()
        client.get.return_value = markup
        base = 'plugin://plugin.video.animesplay/'
        entry = str(Path(__file__).resolve().parents[2] / 'default.py')

        def invoke(query):
            with patch.object(sys, 'argv', [base, '1', query]):
                runpy.run_path(entry, run_name='__main__')

        with tempfile.TemporaryDirectory() as profile:
            info = {'profile': profile, 'id': 'plugin.video.animesplay', 'version': '1.0.13'}
            modules['xbmcaddon'].Addon.return_value.getAddonInfo.side_effect = info.get
            modules['xbmcvfs'].translatePath.side_effect = lambda path: path
            with patch.dict(sys.modules, modules), patch('animesplay.network.client.Client', return_value=client), patch(
                    'animesplay.playback.engine.probe', side_effect=lambda stream, _: dict(stream, mime='video/mp4')):
                invoke('?' + urlencode({'section': 'goyabu', 'action': 'episode_servers', 'item': json.dumps(episode)}))
                auto, manual = [call.args[1] for call in plugin.addDirectoryItem.call_args_list]
                self.assertTrue(auto.startswith(base))
                self.assertEqual(parse_qs(urlsplit(auto).query)['section'], ['goyabu'])
                self.assertEqual(parse_qs(urlsplit(auto).query)['choice'], ['auto'])
                self.assertNotEqual(parse_qs(urlsplit(manual).query)['choice'], ['auto'])
                self.assertNotIn('cdn.invalid', manual)
                invoke('?' + urlsplit(manual).query)
                self.assertIs(plugin.setResolvedUrl.call_args.args[1], True)
                slot, payload = gui.Window.return_value.setProperty.call_args.args
                self.assertEqual(slot, PENDING)
                self.assertEqual(json.loads(payload)['item']['id'], episode['id'])
                self.assertNotIn('cdn.invalid', payload)

    def test_next_episode_requires_same_listing_number_and_audio(self):
        from animesplay.sources.goyabu import Adapter
        source = Adapter(Mock())
        current = {'id': 'two', 'episode': 2, 'show_url': 'https://goyabu.io/anime/test'}
        previous = {'id': 'two', 'episode': 2, 'audio': 'Leg'}
        correct = {'id': 'three', 'episode': 3, 'audio': 'Leg'}
        wrong_audio = {'id': 'dub', 'episode': 3, 'audio': 'Dub'}
        source.episodes = Mock(return_value=[previous, wrong_audio, correct])
        self.assertEqual(source.next_episode(current), correct)
        source.episodes.return_value = [previous, wrong_audio, {'id': 'four', 'episode': 4, 'audio': 'Leg'}]
        self.assertIsNone(source.next_episode(current))
        source.episodes.return_value = [previous, correct, dict(correct, id='ambiguous')]
        self.assertIsNone(source.next_episode(current))

    def test_original_menu_keeps_legacy_routes_and_exposes_goyabu(self):
        import runpy
        from urllib.parse import parse_qs, urlsplit
        modules = {name: Mock() for name in ('xbmc', 'xbmcgui', 'xbmcplugin', 'xbmcaddon', 'xbmcvfs')}
        modules['xbmcgui'].WindowDialog = object
        modules['xbmc'].getInfoLabel.return_value = '21.3'
        legacy = {
            'kodi_six': SimpleNamespace(**modules),
            'six': SimpleNamespace(PY3=True),
            'fasthttp': SimpleNamespace(req=Mock()),
            'bs4': SimpleNamespace(BeautifulSoup=Mock()),
        }
        with tempfile.TemporaryDirectory() as profile, patch.dict(sys.modules, legacy):
            modules['xbmcaddon'].Addon.return_value.getAddonInfo.return_value = profile
            modules['xbmcvfs'].translatePath.side_effect = lambda value: value
            entry = Path(__file__).resolve().parents[2] / 'default.py'
            with patch.object(sys, 'argv', ['plugin://plugin.video.animesplay/', '1', '?section=animesbr']):
                runpy.run_path(str(entry), run_name='__main__')
            modules['xbmcaddon'].Addon.assert_called_once_with('plugin.video.animesplay')
            calls = modules['xbmcplugin'].addDirectoryItem.call_args_list
            routes = [parse_qs(urlsplit(call.kwargs['url']).query) for call in calls]
            self.assertTrue(any(route.get('action') == ['pesquisar_anime'] for route in routes))
            modules['xbmcplugin'].endOfDirectory.assert_called_once()

    def test_root_opens_goyabu_when_fasthttp_is_missing(self):
        import runpy
        from urllib.parse import urlsplit, parse_qs
        modules = {name: Mock() for name in ('xbmc', 'xbmcgui', 'xbmcplugin', 'xbmcaddon', 'xbmcvfs')}
        with tempfile.TemporaryDirectory() as profile, patch.dict(sys.modules, {**modules, 'fasthttp': None, 'six': SimpleNamespace(PY3=True)}):
            modules['xbmcaddon'].Addon.return_value.getAddonInfo.return_value = profile
            modules['xbmcvfs'].translatePath.side_effect = lambda value: value
            entry = Path(__file__).resolve().parents[2] / 'default.py'
            with patch.object(sys, 'argv', ['plugin://plugin.video.animesplay/', '1', '']):
                runpy.run_path(str(entry), run_name='__main__')
            calls = modules['xbmcplugin'].addDirectoryItem.call_args_list
            self.assertTrue(calls)
            for call in calls:
                self.assertEqual(parse_qs(urlsplit(call.args[1]).query)['section'], ['goyabu'])
            modules['xbmcplugin'].endOfDirectory.assert_called_once()

    def test_clear_catalog_keeps_rate_limit(self):
        with tempfile.TemporaryDirectory() as profile:
            client = Client(profile, clock=lambda: 100)
            page = 'https://goyabu.io/lista-de-animes'
            client._save(page, 'catalog', 60)
            client._remember_catalog_delay('20')
            self.assertEqual(client._cached(page), 'catalog')
            self.assertTrue(client.clear_catalog())
            self.assertIsNone(client._cached(page))
            self.assertEqual(Client(profile, clock=lambda: 105)._catalog_delay(), 15)

    def test_catalog_http_error_records_status_without_request_details(self):
        import runpy
        modules = {name: Mock() for name in ('xbmc', 'xbmcgui', 'xbmcplugin', 'xbmcaddon', 'xbmcvfs')}
        with tempfile.TemporaryDirectory() as profile, patch.dict(sys.modules, modules):
            modules['xbmcaddon'].Addon.return_value.getAddonInfo.return_value = profile
            modules['xbmcvfs'].translatePath.side_effect = lambda value: value
            client = Mock(last_request={'cache': 'miss'})
            client.get.side_effect = HTTPError('https://goyabu.io/?private=secret', 403, 'blocked', {}, None)
            entry = Path(__file__).resolve().parents[2] / 'default.py'
            with patch.object(sys, 'argv', ['plugin://plugin.video.animesplay/', '1', '?action=catalog&section=goyabu']), patch(
                    'animesplay.kodi.plugin.Client', return_value=client):
                runpy.run_path(str(entry), run_name='__main__')
            report = (Path(profile) / 'painel-goyabu/last-goyabu-navigation.txt').read_text(encoding='utf-8')
            self.assertIn('Etapa: catalog', report)
            self.assertIn('Resultado: HTTP 403', report)
            self.assertNotIn('secret', report)
            self.assertIn('[AnimesPlay/Goyabu]', modules['xbmc'].log.call_args.args[0])
            modules['xbmcplugin'].endOfDirectory.assert_called_once_with(1, succeeded=False)

    def test_http_error_trace_reports_challenge_without_upstream_identifiers(self):
        from email.message import Message
        headers = Message()
        headers['CF-Mitigated'] = 'challenge'
        headers['CF-Ray'] = 'private-ray-id'
        opener = Mock()
        opener.open.side_effect = HTTPError('https://goyabu.io/lancamentos', 403, 'Forbidden', headers, None)
        client = Client(opener=opener)
        with self.assertRaises(HTTPError):
            client.get('https://goyabu.io/lancamentos?paged=1')
        self.assertEqual(client.last_request['desafio Cloudflare'], 'confirmado')
        self.assertEqual(client.last_request['redirecionamento'], 'sim')
        self.assertNotIn('private-ray-id', str(client.last_request))

    def test_audio_choices_lead_to_the_right_source_edition(self):
        import importlib
        from animesplay.catalog.grouping import group
        modules = {name: Mock() for name in ('xbmc', 'xbmcgui', 'xbmcplugin', 'xbmcaddon', 'xbmcvfs')}
        with patch.dict(sys.modules, modules):
            module = importlib.import_module('animesplay.kodi.plugin')
            plugin = object.__new__(module.Plugin)
            plugin.row = Mock()
            plugin.context = Mock()
            dub = {'id': 'dub', 'title': 'Exemplo [Dublado]', 'provider': 'goyabu'}
            sub = {'id': 'sub', 'title': 'Exemplo Legendado', 'provider': 'goyabu'}
            grouped, = group([dub, sub])
            plugin.list_editions(grouped)
            self.assertEqual([call.args[:2] for call in plugin.row.call_args_list],
                             [('Dublado', 'sources'), ('Legendado', 'sources')])
            selection = plugin.row.call_args_list[0].kwargs['item']
            plugin.row.reset_mock()
            plugin.list_sources(selection['variants'])
            self.assertEqual(plugin.row.call_args.args[:2], ('Servidor 1', 'episodes'))
            self.assertEqual(plugin.row.call_args.kwargs['item'], dub)

    def test_page_limit_keeps_remaining_items_before_next_remote_page(self):
        import importlib
        modules = {name: Mock() for name in ('xbmc', 'xbmcgui', 'xbmcplugin', 'xbmcaddon', 'xbmcvfs')}
        with patch.dict(sys.modules, modules):
            module = importlib.import_module('animesplay.kodi.plugin')
            plugin = object.__new__(module.Plugin)
            plugin.args = {}
            rows = list(range(30))
            self.assertEqual(plugin.local_page(rows, more=True, page=1), (rows[:24], {'page': 1, 'offset': 24}))
            plugin.args = {'offset': '24'}
            self.assertEqual(plugin.local_page(rows, more=True, page=1), (rows[24:], {'page': 2}))

    def test_saved_season_enrichment_requires_confirmed_numbering(self):
        from animesplay.metadata.tmdb import season_episode_records
        item = {'url': 'episode-address', 'episode': 1}
        season = {'season_number': 2, 'episodes': [{'season_number': 2, 'episode_number': 1,
                                                  'id': 521, 'name': 'Capítulo'}]}
        self.assertEqual(season_episode_records(('season', season), [item]), {})
        season['_match_episode_numbers'] = True
        self.assertEqual(season_episode_records(('season', season), [item])['episode-address'][1]['name'],
                         'Capítulo')
        season['episodes'].append({'season_number': 2, 'episode_number': 1, 'id': 522})
        self.assertEqual(season_episode_records(('season', season), [item]), {})
