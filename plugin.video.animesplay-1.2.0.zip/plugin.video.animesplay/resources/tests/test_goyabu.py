"""Regressões do contrato de catálogo, tokens, cache e fallback (sem rede)."""
import base64
import gzip
import io
import json
import sqlite3
import sys
import tempfile
import unittest
from email.message import Message
from pathlib import Path
from unittest.mock import Mock
from urllib.error import URLError

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'lib'))
from animesplay.sources.goyabu import Adapter, address, embedded, decode_player
from animesplay.network.client import Client, MAX_BODY
from animesplay.sources.embeds import extract, payload_streams, candidate
from animesplay.sources.blogger.resolver import resolve
from animesplay.playback.validation import classify, MediaUnavailable

EP = {'url': 'https://goyabu.io/episodio/exemplo-1'}
EMBED = 'https://www.blogger.com/video.g?token=abcdefghijklmnop'
MEDIA = 'https://cdn.example/video.mp4?sig=A%2FB%2BC%3D&extra=1'


def encrypted(url):
    return base64.b64encode(url[::-1].encode()).decode().rstrip('=')


def button(index, kind='', token=''):
    return '<button class="player-tab" data-player-type="%s" data-original-index="%s" data-blogger-url-encrypted="%s">HD</button>' % (kind, index, token)


class ParsingTests(unittest.TestCase):
    def test_invalid_json_does_not_hide_later_declaration(self):
        self.assertEqual(embedded('var allEpisodes=undefined; const allEpisodes=[{"link":"/ep/1"}];', 'allEpisodes'), [{'link': '/ep/1'}])

    def test_latest_title_separates_episode_and_work(self):
        c = Mock()
        c.get.return_value = '<article class="boxEP"><a href="/75765"><div class="ep-type"><b>Episódio 5</b></div><div class="title hidden-text">Aoki Denshou Welsh &amp; Shedar</div></a></article>'
        self.assertEqual(Adapter(c).latest()[0]['title'], 'Aoki Denshou Welsh & Shedar — Episódio 5')

    def test_wrong_json_type_is_empty(self):
        self.assertEqual(embedded('var playersData={"x":1};', 'playersData'), [])

    def test_corrupt_button_does_not_hide_working_player(self):
        c = Mock()
        c.get.return_value = button('0', 'iframe', '!!!') + button('1', 'iframe', encrypted(EMBED))
        self.assertEqual(Adapter(c).options(EP)[0]['url'], EMBED)

    def test_malformed_player_fields_and_large_index_do_not_abort(self):
        c = Mock()
        c.get.return_value = 'var playersData=[{"select":"blogger","blogger_token":{}}, {"select":"direct","url":"' + MEDIA + '"}];' + button('9' * 5000) + button('0') + button('1')
        self.assertEqual(Adapter(c).options(EP)[0]['url'], MEDIA)

    def test_same_label_keeps_distinct_players_and_stable_ids(self):
        c = Mock()
        first = button('0', 'iframe', encrypted(EMBED))
        second = button('1', 'iframe', encrypted(EMBED + 'other'))
        c.get.side_effect = [first + second, second + first]
        a = Adapter(c).options(EP)
        b = Adapter(c).options(EP)
        self.assertEqual(len(a), 2)
        self.assertNotEqual(a[0]['id'], a[1]['id'])
        self.assertEqual(a[0]['id'], b[1]['id'])

    def test_indexed_buttons_and_duplicates(self):
        c = Mock()
        c.get.return_value = 'var playersData=[null,{"select":"blogger","blogger_token":"abc"}];' + button('999') + button('0') + button('1') + button('1')
        self.assertEqual(len(Adapter(c).options(EP)), 1)

    def test_player_cache_only_in_invocation(self):
        c = Mock()
        c.get.return_value = button('0', 'iframe', encrypted(EMBED))
        a = Adapter(c)
        a.options(EP); a.options(EP)
        c.get.assert_called_once()
        Adapter(c).options(EP)
        self.assertEqual(c.get.call_count, 2)

    def test_bad_episode_row_is_skipped_and_duplicates_removed(self):
        c = Mock()
        c.get.return_value = 'var allEpisodes=[null,{}, {"link":"https://elsewhere.example/ep"}, {"link":"/ep/1","episodio":1},{"link":"/ep/1","episodio":1}];'
        items = Adapter(c).episodes({'url': 'https://goyabu.io/anime/a'})
        self.assertEqual(len(items), 1)
        self.assertEqual(items[0]['episode'], 1)

    def test_first_page_uses_canonical_url(self):
        c = Mock()
        c.get.return_value = '<html></html>'
        adapter = Adapter(c)
        adapter.catalog(1)
        c.get.assert_called_with('https://goyabu.io/lista-de-animes', ttl=600)
        adapter.latest(1)
        c.get.assert_called_with('https://goyabu.io/lancamentos', ttl=60)
        adapter.latest(2)
        c.get.assert_called_with('https://goyabu.io/lancamentos?paged=2', ttl=60)

    def test_catalog_address_contract(self):
        for value in ('http://goyabu.io/a', 'https://goyabu.io:444/a', 'https://x@goyabu.io/a', 'https://goyabu.io.evil/a'):
            with self.subTest(value=value), self.assertRaises(ValueError):
                address(value)

    def test_decode_missing_padding(self):
        self.assertEqual(decode_player(encrypted(EMBED)), EMBED)
        self.assertEqual(decode_player('!!!'), '')

    def test_signed_url_preserved(self):
        self.assertEqual(extract('<video src="' + MEDIA.replace('&', '&amp;') + '"></video>', EMBED)[0]['url'], MEDIA)

    def test_expired_and_bad_urls_skipped(self):
        data = {'success': True, 'data': {'play': [{'src': 'https://cdn.example/a.mp4?expire=1'}, {'src': MEDIA}, {'src': MEDIA}, {'src': 'javascript:alert(1)'}]}}
        self.assertEqual([v['url'] for v in payload_streams(data, EMBED)], [MEDIA])

    def test_failure_string_is_not_success(self):
        self.assertEqual(payload_streams({'success': 'false', 'data': {'play': [{'src': MEDIA}]}}, EMBED), [])

    def test_rpc_network_failure_uses_html_fallback(self):
        client = Mock()
        client.get.side_effect = ['var WIZ_global_data={"FdrFJe":"sid"};<video src="' + MEDIA.replace('&', '&amp;') + '"></video>', URLError('offline')]
        self.assertEqual(resolve(EMBED, client)[0]['url'], MEDIA)

    def test_rpc_failure_uses_source_decoder(self):
        c = Mock(); c.get.side_effect = URLError('offline')
        a = Adapter(c); a.resolve_source = Mock(return_value=[{'url': MEDIA, 'label': '720p'}])
        result = a.resolve(EP, {'kind': 'blogger', 'token': encrypted(EMBED)})
        self.assertEqual(result[0]['url'], MEDIA)
        self.assertEqual(a.last_trace[0]['status'], 'failed')
        self.assertEqual(a.last_trace[1]['stage'], 'source_decoder')

    def test_direct_option_does_not_download_entire_media(self):
        c = Mock()
        result = Adapter(c).resolve(EP, {'kind': 'direct', 'url': MEDIA})
        self.assertEqual(result[0]['url'], MEDIA)
        c.get.assert_not_called()

    def test_html_cannot_pass_media_probe(self):
        with self.assertRaises(MediaUnavailable):
            classify(b'<html><body>unavailable</body></html>', 'video/mp4')


class Response(io.BytesIO):
    status = 200
    def __init__(self, body, encoding=''):
        super().__init__(body)
        self.headers = Message()
        self.headers['Content-Type'] = 'text/html; charset=utf-8'
        if encoding:
            self.headers['Content-Encoding'] = encoding


class CacheTests(unittest.TestCase):
    def test_cache_survives_client_recreation_and_expires(self):
        with tempfile.TemporaryDirectory() as profile:
            clock = [100]
            op = Mock(); op.open.side_effect = lambda *a, **kw: Response(b'catalog')
            url = 'https://goyabu.io/lista-de-animes?paged=1'
            c = Client(profile, opener=op, clock=lambda: clock[0])
            self.assertEqual(c.get(url, ttl=10), 'catalog')
            d = Client(profile, opener=op, clock=lambda: clock[0])
            self.assertEqual(d.get(url, ttl=10), 'catalog')
            self.assertEqual(d.last_request['cache'], 'hit')
            self.assertEqual(op.open.call_count, 1)
            clock[0] = 111
            d.get(url, ttl=10)
            self.assertEqual(op.open.call_count, 2)

    def test_posts_players_and_tokens_never_cached(self):
        with tempfile.TemporaryDirectory() as profile:
            op = Mock(); op.open.side_effect = lambda *a, **kw: Response(b'ok')
            c = Client(profile, opener=op)
            for url, kw in [('https://goyabu.io/ep/a', {}), ('https://www.blogger.com/video.g?token=abc', {}), ('https://goyabu.io/?token=secret', {}), ('https://goyabu.io/', {'post': {}})]:
                c.get(url, ttl=10, **kw); c.get(url, ttl=10, **kw)
            self.assertEqual(op.open.call_count, 8)
            self.assertFalse(Path(c.cache_path).exists())

    def test_corrupt_cache_does_not_block_network(self):
        with tempfile.TemporaryDirectory() as profile:
            Path(profile, 'catalog-cache.db').write_bytes(b'broken')
            op = Mock(); op.open.return_value = Response(b'live')
            self.assertEqual(Client(profile, opener=op).get('https://goyabu.io/', ttl=10), 'live')

    def test_gzip_and_size_limit(self):
        op = Mock(); op.open.return_value = Response(gzip.compress('animação'.encode()), 'gzip')
        self.assertEqual(Client(opener=op).get('https://goyabu.io/'), 'animação')
        op.open.return_value = Response(gzip.compress(b'x' * (MAX_BODY + 1)), 'gzip')
        with self.assertRaises(ValueError):
            Client(opener=op).get('https://goyabu.io/')


if __name__ == '__main__':
    unittest.main(verbosity=2)
