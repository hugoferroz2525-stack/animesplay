import sys,unittest,json
from types import SimpleNamespace
from unittest.mock import Mock
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'lib'))
from animesplay.playback.engine import Engine,PlaybackCancelled,option_key
from animesplay.playback.validation import MediaUnavailable
HD={'kind':'iframe','label':'HD','url':'https://www.blogger.com/video.g?token=test'}
FHD={'kind':'blogger','label':'FHD','url':HD['url'],'token':'secret'}
def stream(key,label='720p'):return {'url':'https://media.invalid/'+key,'label':label}
def adapter(options):return SimpleNamespace(options=Mock(return_value=options),resolve=Mock(return_value=[]),resolve_source=Mock(return_value=[]),last_trace=[])
class EngineTests(unittest.TestCase):
 def test_primary_valid(self):
  a=adapter([HD]);a.resolve.return_value=[stream('ok')];v=Mock(side_effect=lambda c:dict(c,mime='video/mp4'));self.assertEqual(Engine(a,v).play({'id':'ep'})['mime'],'video/mp4')
 def test_bad_high_quality_tries_lower(self):
  a=adapter([HD]);a.resolve.return_value=[stream('bad','720p'),stream('ok','360p')]
  def validate(c):
   if c['label']=='720p':raise MediaUnavailable('HTML')
   return dict(c,mime='video/mp4')
  self.assertEqual(Engine(a,validate).play({'id':'ep'})['label'],'360p')
 def test_duplicate_embed_not_resolved_twice_and_secondary_works(self):
  a=adapter([HD,FHD]);a.resolve.return_value=[stream('bad')];a.resolve_source.return_value=[stream('ok')]
  def validate(c):
   if c['url'].endswith('bad'):raise MediaUnavailable('HTML')
   return dict(c,mime='video/mp4')
  ep={'id':'exact-ep'};result=Engine(a,validate).play(ep);self.assertTrue(result['url'].endswith('ok'));a.resolve.assert_called_once_with(ep,HD);a.resolve_source.assert_called_once_with(ep,FHD)
 def test_cancel_no_network(self):
  a=adapter([HD])
  with self.assertRaises(PlaybackCancelled):Engine(a).play({},cancelled=lambda:True)
  a.options.assert_not_called()
 def test_stale_choice_not_another_player(self):
  a=adapter([HD])
  with self.assertRaises(MediaUnavailable):Engine(a).play({},choice='unknown')
  a.resolve.assert_not_called()
 def test_manual_selection_cancelled(self):
  a=adapter([HD]);a.resolve.return_value=[stream('a'),stream('b')]
  with self.assertRaises(PlaybackCancelled):Engine(a).play({},choice=option_key(HD),select=lambda _: -1)
 def test_invalid_media_never_returned_and_no_tokens_in_trace(self):
  a=adapter([HD,FHD]);a.resolve.return_value=[stream('bad')];e=Engine(a,Mock(side_effect=MediaUnavailable('HTML')))
  with self.assertRaises(MediaUnavailable):e.play({})
  self.assertNotIn('secret',json.dumps(e.trace));self.assertNotIn('media.invalid',json.dumps(e.trace))
 def test_secondary_not_called_twice(self):
  a=adapter([FHD]);a.last_trace=[{'stage':'source_decoder','status':'empty'}]
  with self.assertRaises(MediaUnavailable):Engine(a).play({})
  a.resolve_source.assert_not_called()
if __name__=='__main__':unittest.main(verbosity=2)
