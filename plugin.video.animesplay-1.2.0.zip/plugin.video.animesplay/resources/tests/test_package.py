import runpy
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch
from xml.etree import ElementTree


ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "resources/lib"))
MANIFEST = ElementTree.parse(ROOT / 'addon.xml').getroot()


class PackageTests(unittest.TestCase):
    def test_manifest_paths_and_root(self):
        self.assertEqual(MANIFEST.get('version'), '1.2.0')
        self.assertEqual(MANIFEST.get('id'), ROOT.name)
        self.assertEqual({file.name for file in ROOT.iterdir()}, {'addon.xml', 'default.py', 'fanart.jpg', 'icon.png', 'icons', 'resources'})
        for path in MANIFEST.findall('extension[@library]'):
            self.assertTrue((ROOT / path.get('library')).is_file())
        for asset in MANIFEST.findall('extension/assets/*'):
            self.assertTrue((ROOT / asset.text).is_file())
        settings = ElementTree.parse(ROOT / 'resources/settings.xml')
        self.assertTrue(any(node.get('id') == 'tmdb_token' for node in settings.iter('setting')))

    def test_service_entry_starts_monitor_using_existing_profile(self):
        from animesplay.storage.history import History
        service = MANIFEST.find("extension[@point='xbmc.service']")
        addon = Mock()
        monitor = Mock()
        monitor.waitForAbort.return_value = True
        modules = {
            'xbmc': SimpleNamespace(Player=object, Monitor=Mock(return_value=monitor)),
            'xbmcaddon': SimpleNamespace(Addon=Mock(return_value=addon)),
            'xbmcgui': SimpleNamespace(Window=Mock()),
            'xbmcvfs': SimpleNamespace(translatePath=lambda path: path),
        }
        key = 'animesplay.kodi.progress'
        with tempfile.TemporaryDirectory() as profile, patch.dict(sys.modules, modules):
            addon.getAddonInfo.return_value = profile
            sys.modules.pop(key, None)
            try:
                runpy.run_path(str(ROOT / service.get('library')), run_name='__main__')
            finally:
                sys.modules.pop(key, None)
            addon.getAddonInfo.assert_called_once_with('profile')
            monitor.waitForAbort.assert_called_once_with(2)
            self.assertTrue(History(Path(profile) / 'painel-goyabu').path.is_file())
