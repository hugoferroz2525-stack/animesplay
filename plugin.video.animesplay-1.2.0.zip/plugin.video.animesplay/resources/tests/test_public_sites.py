import sys
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'lib'))

from animesplay.playback.engine import Engine
from animesplay.playback.validation import MediaUnavailable
from animesplay.sources.public_sites import AnimesOnlineCC, MetiAnimes


class PublicSitesTests(unittest.TestCase):
    def test_animesonlinecc_catalog_and_episode_number_from_public_markup(self):
        client = Mock()
        client.get.side_effect = [
            '<article><a href="/anime/exemplo/"><img alt="Exemplo Dublado Todos os Episodios Online">'
            '</a><h3><a href="/anime/exemplo/">Duplicado</a></h3></article>',
            '<div id="seasons"><div class="se-c"><span class="se-t">2</span><ul><li>'
            '<span class="numerando">2 - 4</span><div class="episodiotitle">'
            '<a href="/episodio/exemplo-4/">Episodio 4</a></div></li></ul></div></div>',
        ]
        source = AnimesOnlineCC(client)
        show, = source.catalog()
        self.assertEqual(show['title'], 'Exemplo Dublado')
        episode, = source.episodes(show)
        self.assertEqual((episode['season'], episode['episode']), (2, 4))
        self.assertEqual(episode['provider'], source.id)

    def test_animesonlinecc_passes_only_blogger_player_to_resolver(self):
        client = Mock()
        client.get.return_value = (
            '<div class="play-box-iframe"><iframe src="https://www.blogger.com/video.g?token=fixture"></iframe>'
            '<iframe src="https://advert.example/ad"></iframe></div>'
            '<iframe src="https://www.blogger.com/video.g?token=unrelated"></iframe>')
        source = AnimesOnlineCC(client)
        episode = {'url': source.base + 'episodio/exemplo-1/'}
        candidate = {'url': 'https://media.invalid/example.mp4', 'mime': 'video/mp4'}
        with patch('animesplay.sources.public_sites.resolve_blogger', return_value=[candidate]) as resolver:
            self.assertEqual(Engine(source, validator=lambda stream: stream).play(episode), candidate)
        resolver.assert_called_once_with('https://www.blogger.com/video.g?token=fixture', client)

    def test_meti_ignores_hero_link_and_exposes_protected_players(self):
        client = Mock()
        client.get.side_effect = [
            '<a class="anime-card" href="/anime/exemplo"><h3>Exemplo</h3></a>',
            '<div class="hero-actions"><a href="/episodio/exemplo-1">Assistir agora</a></div>'
            '<div class="episodes"><a href="/episodio/exemplo-1">EP 1</a>'
            '<a href="https://unrelated.invalid/episodio/exemplo-1">EP 1</a></div>',
            '<main><span>PLAYER PROTEGIDO</span><button>ASSISTIR EPISÓDIO</button></main>',
        ]
        source = MetiAnimes(client)
        show, = source.catalog()
        episode, = source.episodes(show)
        self.assertEqual(episode['episode'], 1)
        options = source.options(episode)
        self.assertEqual([option['id'] for option in options], ['proplayer_leg', 'myembed'])
        self.assertTrue(all(option['kind'] == 'metiplayer' for option in options))
        self.assertEqual(client.get.call_count, 3)

    def test_meti_catalog_uses_public_page_parameter_and_plain_title_links(self):
        client = Mock()
        client.get.return_value = (
            '<main><article><h2><a href="/anime/exemplo">Exemplo</a></h2></article></main>')
        source = MetiAnimes(client)
        show, = source.catalog(2)
        self.assertEqual(show['title'], 'Exemplo')
        client.get.assert_called_once_with('https://metianimesonline.org/animes/?pagina=2', ttl=900)
