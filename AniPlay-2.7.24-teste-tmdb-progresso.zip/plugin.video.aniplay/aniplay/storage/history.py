"""Keep progress by episode page, independent of the current media URL."""
import hashlib
import json
import math
import re
from urllib.parse import urlsplit
import sqlite3
import time
from contextlib import closing
from pathlib import Path

PENDING = 'AniPlay.PendingPlayback'
FIELDS = ('id', 'url', 'title', 'showtitle', 'episode_title', '_tmdb_title', 'show_url', 'icon', 'episode',
          'showid', 'local', 'raw', 'season', 'movie_id', 'show_title', 'provider', 'mediatype', 'audio', '_alternate_parents', 'tmdb_id', '_display_season', '_tmdb_season', '_tmdb_episode', '_season_mapped')


def media_key(path):
    url = path.split('|', 1)[0]
    return hashlib.sha256(url.encode('utf-8')).hexdigest()


def public_episode(item):
    result={key: item[key] for key in FIELDS if key in item and key!='_alternate_parents'}
    return result


class History:
    def __init__(self, profile):
        profile = Path(profile)
        profile.mkdir(parents=True, exist_ok=True)
        self.path = profile / 'watch-history-v1.db'
        with closing(self.connect()) as conn, conn:
            conn.execute('''CREATE TABLE IF NOT EXISTS episodes(
                id TEXT PRIMARY KEY, item TEXT NOT NULL, position REAL NOT NULL,
                duration REAL NOT NULL, watched INTEGER NOT NULL, updated REAL NOT NULL
            )''')

    def connect(self):
        return sqlite3.connect(str(self.path), timeout=1)

    def save(self, item, position, duration, ended=False):
        if not all(math.isfinite(value) for value in (position, duration)):
            return
        if duration < 1 or position < 0:
            return
        position = min(position, duration)
        watched = position >= duration * 0.90 or (ended and position >= duration * 0.85)
        if not watched and position < 10:
            return
        with closing(self.connect()) as conn, conn:
            conn.execute('INSERT OR REPLACE INTO episodes VALUES(?,?,?,?,?,?)',
                         (item['id'], json.dumps(public_episode(item), ensure_ascii=False),
                          position, duration, int(watched), time.time()))

    def watched_for_show(self, show_url):
        from aniplay.tmdb_match import slug

        key = slug(show_url)
        watched = set()
        with closing(self.connect()) as conn:
            for episode_id, body in conn.execute('SELECT id,item FROM episodes WHERE watched=1'):
                try:
                    item = json.loads(body)
                except ValueError:
                    continue
                source = item.get('url') or episode_id
                known_show = item.get('show_url')
                if (known_show and slug(known_show) == key) or (
                    re.fullmatch(re.escape(key) + r'-\d+-episodio-[\d.,]+',
                                 urlsplit(source).path.rstrip('/').rsplit('/', 1)[-1])
                ):
                    watched.add(source)
        return watched

    def resume(self, episode_id):
        with closing(self.connect()) as conn:
            result = conn.execute('SELECT position FROM episodes WHERE id=? AND watched=0',
                                  (episode_id,)).fetchone()
        return result[0] if result else 0

    def unfinished(self):
        with closing(self.connect()) as conn:
            return [(json.loads(item), position) for item, position in conn.execute(
                'SELECT item,position FROM episodes WHERE watched=0 ORDER BY updated DESC LIMIT 100')]

    def recently_watched(self):
        with closing(self.connect()) as conn:
            return [json.loads(row[0]) for row in conn.execute(
                'SELECT item FROM episodes WHERE watched=1 ORDER BY updated DESC LIMIT 100')]
