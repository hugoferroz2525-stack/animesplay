# AnimesPlay 1.1.0

Instale `plugin.video.animesplay-1.1.0.zip` por **Kodi → Add-ons → Instalar a partir de um arquivo ZIP**. O ID é o mesmo da versão 1.0.13, preservando favoritos, histórico, progresso e associações TMDB. Reinicie o Kodi após atualizar para carregar o serviço da versão nova.

- Resolvedor MetiAnimes em HTTP puro: não precisa de Chromium, Playwright ou servidor auxiliar.
- Menus organizados em sete atalhos, títulos brancos/dourados, ícones locais e fundo próprio. A skin do Kodi controla a disposição final; é possível desligar a decoração nos ajustes.
- Catálogos em cache nas três fontes, consultas TMDB com validade configurável e limpeza independente. Nunca salva URLs assinadas de vídeo em cache.
- TMDB: destaques de animação japonesa, associação de filme/série/temporada/episódio, pôster, fanart, elenco, sinopse, classificação e trailers pelo addon YouTube. A chave de cliente padrão foi atualizada com a configuração presente no Flix fornecido; chave/token pessoal continua tendo prioridade.
- Gêneros do MetiAnimes, busca paralela, retomada, minha lista e navegação antiga preservados.

A resolução Meti normalmente leva cerca de 30–40 segundos porque respeita o temporizador remoto. Use Cancelar durante a espera se necessário. Respostas e endereços temporários são obtidos novamente ao reproduzir.

Veja [ATUALIZACAO-1.1.0.md](ATUALIZACAO-1.1.0.md) para mudanças, referências e limites da validação. A reprodução final e a aparência dentro de Kodi/Android/TV box precisam ser conferidas no aparelho; os testes deste pacote usam o motor real de resolução e a API Kodi simulada.

## Histórico das versões anteriores

O texto abaixo registra a evolução da base até 1.0.13. As limitações antigas do player Meti foram tratadas na versão 1.1.0.

# AnimesPlay 1.0.9 experimental

Instale o ZIP no Kodi e abra **AnimesPlay → Goyabu** ou **Continuar assistindo · Goyabu** no menu inicial. Reinicie o Kodi após instalar para carregar o serviço de retomada. O mesmo identificador atualiza as versões anteriores. Favoritos, buscas, TMDB e progresso do painel experimental anterior usam o mesmo subdiretório do perfil.

O `default.py` encaminha as rotas do Goyabu para `resources/lib/animesplay/kodi/plugin.py` e as originais de AnimesPlay para `resources/legacy/animesbr.py`. O manifesto registra `resources/entrypoints/service.py`. Os nomes e a disposição dos arquivos da raiz continuam iguais. O ícone, a fanart e a pasta `icons` são originais da base AnimesPlay 1.0.5.

| Referência | Aplicação |
| --- | --- |
| Brazuca | Cabeçalhos por servidor, alternativas do mesmo episódio e referência do fluxo Blogger. |
| AnimeSoul auditado | Adaptações licenciadas de embeds e Blogger. O adaptador Goyabu mantém sua identidade de obra e episódio. |
| Flix | Navegação por obra e edição, associação manual TMDB e histórico de busca. |
| OnePlay | Cache do catálogo e tratamento de HTTP 429. |
| TheThunder | Serviço de retomada e atalho **Próximo episódio** no menu de contexto quando a sequência puder ser identificada na mesma lista e edição de áudio. |
| YouTube | Abertura de trailers no addon YouTube e alternativa de reprodução quando necessário para DASH. |
| Spartan | Rotas e adaptador local separados. |

## Recursos da versão 1.0.7

- **Avanço automático.** Ative em **Ajustes → Reprodução Goyabu**. Roda após o fim natural do vídeo e só abre o próximo episódio quando a página da obra oferece um número consecutivo e uma única correspondência na mesma edição de áudio.
- **AniSkip.** Use o menu de contexto **Configurar AniSkip neste episódio** e informe o ID do MyAnimeList e o número correspondente naquela entrada do MAL, separados por espaço. Ative os saltos de abertura e/ou encerramento em **Reprodução Goyabu**. Os marcadores precisam corresponder à duração da mídia, com tolerância de dois segundos. O serviço ignora intervalos ambíguos e continua normalmente quando a consulta falha.
- **Sugestões pelo histórico.** Usa gêneros das obras assistidas e da primeira página do catálogo Goyabu. Associe obras ao TMDB pelo menu de contexto para o algoritmo ter dados para comparar. O histórico fica no perfil local.
- **Legendas.** O player continua recebendo as faixas fornecidas pela fonte. A busca externa usa o serviço de legendas configurado no Kodi, como OpenSubtitles, pelo menu de legendas do vídeo. O addon não inclui credenciais nem um cliente independente de OpenSubtitles.

O AnimesBR continua acessível nas rotas originais do AnimesPlay. O Goyabu continua com as rotas integradas. Novos adaptadores para AnimesDigital, AnimesUP, HinataSoul e AnimesOnlineCC não foram habilitados. As consultas diretas aos domínios e ao Goyabu expiraram no ambiente da revisão.

Foram executados 46 testes a partir do ZIP extraído. Eles verificam a estrutura, a navegação simulada, o próximo episódio, o avanço após fim natural, a validação dos marcadores e a classificação das sugestões. A reprodução em Kodi real, Android e TV box continua pendente.

## Correção 1.0.8

A rota original usa o ID explícito do AnimesPlay ao carregar o addon. O despacho interpreta a consulta uma vez. Se o FastHTTP estiver ausente, o menu principal abre o Goyabu diretamente. O FastHTTP segue necessário às rotas originais do AnimesBR.

A opção **Limpar cache do catálogo Goyabu** nos ajustes apaga as páginas armazenadas. O prazo de espera após HTTP 429 e os dados do perfil são preservados. O atalho de abertura do Goyabu pelos ajustes foi removido porque a janela customizada do FlixBox manteve o diálogo modal ativo. Abra o Goyabu pelo menu principal.

## Diagnóstico 1.0.9

Depois de abrir o catálogo ou os lançamentos, use **Ajustes → Goyabu → Ver diagnóstico do Goyabu**. O relatório mostra a etapa, o código HTTP ou a classe de erro, o estado do cache e, quando disponíveis, o tempo da consulta e a contagem de itens reconhecidos. O marcador `[AnimesPlay/Goyabu]` também é gravado no log do Kodi. O diagnóstico omite URLs, cookies, cabeçalhos e o conteúdo da resposta.

## Investigação do HTTP 403 — 1.0.10

Catálogo e lançamentos usam as URLs sem `?paged=1` na primeira página. A paginação subsequente e as demais rotas continuam disponíveis. O diagnóstico de falha HTTP indica se a URL final mudou e se os cabeçalhos sinalizaram a passagem pela Cloudflare ou um desafio, sem gravar o valor dos cabeçalhos.

## Organização interna — 1.0.11

- `resources/entrypoints/` contém a entrada do serviço Kodi.
- `resources/legacy/animesbr.py` contém as rotas antigas do AnimesBR.
- `resources/lib/animesplay/kodi/` reúne rotas, apresentação de itens, diagnóstico e serviço de progresso.
- `resources/lib/animesplay/sources/` reúne os adaptadores de origem. `catalog/`, `network/`, `playback/`, `metadata/` e `storage/` mantêm suas responsabilidades separadas.
- `resources/docs/`, `resources/licenses/` e `resources/tests/` guardam documentação, licenças e testes.

O identificador do addon, os links do Kodi e os caminhos dos dados no perfil permanecem iguais. O Goyabu segue com a integração direta existente e pode continuar recusando a consulta com HTTP 403.

## Navegação 1.0.12

O início do addon reúne Continuar assistindo, Últimos episódios, Explorar animes, Buscar, Minha lista e Ajustes. O atalho para a navegação original do AnimesBR fica em Ajustes. Em Explorar animes estão o catálogo completo e os filtros de áudio.

Ao abrir um anime agrupado, escolha a edição de áudio e depois o servidor. Cada servidor representa o site da edição. O player de vídeo é escolhido depois de abrir um episódio. Se apenas uma classe de áudio for conhecida, a seleção abre diretamente os servidores. Variantes sem indicação de áudio ficam como Áudio não informado enquanto a fonte não der evidência suficiente.

Catálogo, busca, favoritos e episódios exibem até 24 itens por página no novo fluxo. Quando a página remota tem mais itens, a próxima página local exibe os itens restantes. O agrupamento usa as variantes presentes na página carregada. Catálogos antigos podem ter variantes em páginas diferentes.

Associe uma edição a uma temporada TMDB pelo menu de contexto do servidor. Após confirmar que os números correspondem, os campos dos episódios são reaproveitados da resposta armazenada da temporada. A leitura SQLite de cada lista é feita em lote. Uma associação manual de episódio tem precedência.

Foram verificados os sites MetiAnimesOnline, AnimesDigital, SushiAnimes, AniTure, AnimesOnlines e AnimesOnlineCC. O último é a referência comum encontrada no Brazuca e no Spartan. A inspeção de páginas públicas não validou reprodução nesses seis sites. O fluxo novo mantém o adaptador direto do Goyabu, que pode continuar retornando HTTP 403 no aparelho. Gêneros e ano continuam disponíveis na navegação antiga do AnimesBR.

## AnimesOnlineCC e MetiAnimesOnline — 1.0.13

Em **Explorar animes** e **Últimos episódios**, escolha o site. **Buscar** consulta as fontes em paralelo e reúne as edições reconhecidas pelo agrupador. A reprodução e a navegação de episódios usam o adaptador da edição escolhida.

- **AnimesOnlineCC** lê o catálogo, temporadas, episódios e iframes Blogger na área de players da página pública. As opções do Blogger seguem para o resolvedor existente e a validação de mídia do AnimesPlay. Foi possível ver os iframes no navegador interativo. A consulta Python ao domínio expirou durante o teste e a reprodução final não foi validada.
- **MetiAnimesOnline** lê o catálogo, a busca e os episódios. A lista de Golden Curse retornou 16 episódios na consulta Python. A página pública de um episódio abriu uma verificação externa pelo botão oficial de assistir. O addon informa que o player é protegido e fica na etapa de navegação. A disponibilidade do catálogo deve ser conferida no Kodi.

A atualização mantém o ID e o layout da raiz. Foram executados 58 testes a partir do ZIP extraído.
