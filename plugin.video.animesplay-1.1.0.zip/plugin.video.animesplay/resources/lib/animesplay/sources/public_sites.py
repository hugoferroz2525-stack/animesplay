"""Catalog and episode adapters for the two inspected public websites."""
import re
from urllib.parse import urlencode, urljoin, urlsplit, urlunsplit

from animesplay.network.html import Tree, seasons_from_html
from animesplay.playback.validation import MediaUnavailable
from animesplay.sources.blogger.resolver import is_embed, resolve as resolve_blogger

EPISODE_NUMBER = re.compile(r'\b(?:EP|epis[oó]dio)\s*(\d+)\b', re.I)


def parse(markup):
    tree = Tree()
    tree.feed(markup)
    return tree.root


class PublicSite:
    def __init__(self, client):
        self.client = client

    def page_url(self, root, href, prefix):
        if not href:
            return ''
        try:
            parts = urlsplit(urljoin(root, href))
            if (parts.scheme != 'https' or parts.netloc != urlsplit(self.base).netloc
                    or not parts.path.startswith(prefix) or not parts.path[len(prefix):].strip('/')):
                return ''
            return urlunsplit(parts._replace(fragment=''))
        except ValueError:
            return ''

    def catalog(self, page=1):
        return self.cards(self.client.get(self.catalog_url(page), ttl=900))

    def search(self, query, page=1):
        if not query.strip():
            return []
        return self.cards(self.client.get(self.search_url(query, page), ttl=180))

    def latest(self, page=1):
        return self.episode_rows(parse(self.client.get(self.latest_url(page), ttl=60)))

    def cards(self, markup):
        items = {}
        for anchor in self.card_anchors(parse(markup)):
            url = self.page_url(self.base, anchor.attrs.get('href'), '/anime/')
            if not url or url in items:
                continue
            images = anchor.find(lambda n: n.tag == 'img')
            image = images[0].attrs if images else {}
            headings = anchor.find(lambda n: n.tag in ('h2', 'h3'))
            title = (headings[0].text() if headings else image.get('alt') or anchor.text()).strip()
            title = re.sub(r'\s+Todos os Epis[oó]dios Online\s*$', '', title, flags=re.I)
            if title:
                art = image.get('data-src') or image.get('src')
                items[url] = {'id': url, 'url': url, 'title': title, 'provider': self.id,
                              'icon': urljoin(self.base, art) if art else '', 'mediatype': 'tvshow'}
        return list(items.values())

    def episode_rows(self, root, parent=None):
        items = {}
        for anchor in root.find(lambda n: n.tag == 'a'):
            url = self.page_url(self.base, anchor.attrs.get('href'), '/episodio/')
            title = ' '.join(anchor.text().split())
            match = EPISODE_NUMBER.search(title)
            if not url or not match or url in items:
                continue
            item = {'id': url, 'url': url, 'title': title, 'provider': self.id,
                    'mediatype': 'episode', 'episode': int(match[1])}
            if parent:
                item.update(show_url=parent['url'], showtitle=parent['title'],
                            audio=parent.get('audio', ''), icon=parent.get('icon', ''))
            items[url] = item
        return list(items.values())

    def next_episode(self, item):
        number = item.get('episode')
        if type(number) is not int or not item.get('show_url'):
            return None
        entries = self.episodes({'url': item['show_url'], 'title': item.get('showtitle') or item['title'],
                                  'audio': item.get('audio', '')})
        matches = [entry for entry in entries if entry.get('episode') == number + 1
                   and entry.get('season') == item.get('season')]
        return matches[0] if len(matches) == 1 else None


class AnimesOnlineCC(PublicSite):
    id = 'animesonlinecc'
    base = 'https://animesonlinecc.to/'

    def catalog_url(self, page):
        return self.archive_url('anime', page)

    def latest_url(self, page):
        return self.archive_url('episodio', page)

    def archive_url(self, kind, page):
        page = int(page)
        return self.base + kind + ('/' if page <= 1 else '/page/{}/'.format(page))

    def search_url(self, query, page):
        params = {'s': query.strip()[:120]}
        if int(page) > 1:
            params['paged'] = int(page)
        return self.base + '?' + urlencode(params)

    def card_anchors(self, root):
        return [anchor for article in root.find(lambda n: n.tag == 'article')
                for anchor in article.find(lambda n: n.tag == 'a')]

    def episodes(self, item):
        url = self.page_url(self.base, item['url'], '/anime/')
        if not url:
            return []
        markup = self.client.get(url, ttl=600)
        episodes = {}
        for season in seasons_from_html(markup, url):
            for entry in season['episodes']:
                link = self.page_url(url, entry['url'], '/episodio/')
                if link:
                    episodes[link] = dict(entry, url=link, id=link, provider=self.id, mediatype='episode',
                                          show_url=url, showtitle=item['title'], icon=entry['thumb'],
                                          audio=item.get('audio', ''))
        if episodes:
            return list(episodes.values())
        root = parse(markup)
        titles = root.find(lambda n: n.has('episodiotitle'))
        return [entry for region in titles for entry in self.episode_rows(region, item)]

    def options(self, item):
        url = self.page_url(self.base, item['url'], '/episodio/')
        if not url:
            return []
        root = parse(self.client.get(url))
        choices = {}
        for box in root.find(lambda n: n.has('play-box-iframe')):
            for frame in box.find(lambda n: n.tag == 'iframe'):
                src = urljoin(url, frame.attrs.get('src') or '')
                if is_embed(src) and src not in choices:
                    label = 'Blogger {}'.format(len(choices) + 1)
                    choices[src] = {'kind': 'iframe', 'label': label, 'url': src}
        return list(choices.values())

    def resolve(self, episode, option):
        return resolve_blogger(option['url'], self.client)


class MetiAnimes(PublicSite):
    id = 'metianimes'
    base = 'https://metianimesonline.org/'

    def catalog_url(self, page):
        return self.base + 'animes/' + ('?pagina={}'.format(int(page)) if int(page) > 1 else '')

    def latest_url(self, page):
        return self.base + 'episodios/' + ('?pagina={}'.format(int(page)) if int(page) > 1 else '')

    def search_url(self, query, page):
        params = {'q': query.strip()[:120]}
        if int(page) > 1:
            params['pagina'] = int(page)
        return self.base + 'animes/?' + urlencode(params)

    def card_anchors(self, root):
        cards = root.find(lambda n: n.tag == 'a' and n.has('anime-card'))
        if cards:
            return cards
        return [anchor for region in root.find(lambda n: n.tag == 'main')
                for anchor in region.find(lambda n: n.tag == 'a')]

    def episodes(self, item):
        url = self.page_url(self.base, item['url'], '/anime/')
        if not url:
            return []
        root = parse(self.client.get(url, ttl=600))
        return [entry for region in root.find(lambda n: n.has('episodes'))
                for entry in self.episode_rows(region, item)]

    def genres(self):
        root = parse(self.client.get(self.base + 'generos/', ttl=3600))
        result = {}
        for node in root.find(lambda n: n.tag == 'a'):
            url = self.page_url(self.base, node.attrs.get('href'), '/genero/')
            if url and node.text():
                result[url] = {'url': url, 'title': node.text()}
        return list(result.values())

    def genre(self, url, page=1):
        safe = self.page_url(self.base, url, '/genero/')
        if not safe:
            raise ValueError('Gênero inválido')
        if int(page) > 1:
            safe += ('&' if '?' in safe else '?') + urlencode({'pagina': int(page)})
        return self.cards(self.client.get(safe, ttl=900))

    def options(self, item):
        url = self.page_url(self.base, item['url'], '/episodio/')
        if not url:
            return []
        root = parse(self.client.get(url))
        names = {'proplayer_leg': 'Pro Player · Legendado', 'myembed': 'Player alternativo',
                 'proplayer_dub': 'Pro Player · Dublado'}
        providers = list(dict.fromkeys(n.attrs.get('data-provider') for n in root.find(
            lambda n: n.tag == 'button' and n.attrs.get('data-provider') in names)))
        if not providers and 'player protegido' in root.text().casefold():
            providers = ['proplayer_leg', 'myembed']
        return [{'kind': 'metiplayer', 'id': key, 'label': names[key]} for key in providers]

    def resolve(self, episode, option):
        from animesplay.sources.metiplayer import Resolver
        return Resolver(self.client, cancelled=getattr(self, 'cancelled', None),
                        progress=getattr(self, 'progress', None)).resolve(episode['url'], option['id'])
