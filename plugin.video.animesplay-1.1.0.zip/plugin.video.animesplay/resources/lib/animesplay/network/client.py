"""Transporte compartilhado; cache somente de páginas públicas de catálogo."""
import http.cookiejar
import os
import sqlite3
import time
import urllib.parse
import urllib.request
import zlib
from contextlib import closing
from email.utils import parsedate_to_datetime
from urllib.error import HTTPError

MAX_BODY = 4 * 1024 * 1024
USER_AGENT = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'


def catalog_page(parts):
    if parts.scheme != 'https':
        return False
    paths = {
        'goyabu.io': ('/', '/lista-de-animes', '/lancamentos', '/anime/'),
        'metianimesonline.org': ('/', '/animes/', '/episodios/', '/anime/', '/generos/', '/genero/', '/ano/'),
        'animesonlinecc.to': ('/', '/anime/', '/episodio/'),
    }
    allowed = paths.get(parts.hostname, ())
    return (any(parts.path == path or (path.endswith('/') and path != '/' and parts.path.startswith(path)) for path in allowed)
            and not parts.path.startswith('/episodio/')
            and all(key in ('s', 'q', 'paged', 'pagina', 'l') for key, _ in urllib.parse.parse_qsl(parts.query)))


class Client:
    def __init__(self, profile=None, timeout=12, opener=None, clock=None, cache_enabled=True, cache_ttl=3600):
        self.opener = opener or urllib.request.build_opener(
            urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        self.timeout = timeout
        self.clock = clock or time.time
        self.cache_path = os.path.join(profile, 'catalog-cache.db') if profile else None
        self.last_request = {}
        self.catalog_retry_at = 0
        self.final_url = ''  # Efêmero; nunca gravado em diagnóstico ou cache de player.
        self.cache_enabled = cache_enabled
        self.cache_ttl = cache_ttl

    def _catalog_delay(self, host='goyabu.io'):
        if self.cache_path:
            try:
                with closing(sqlite3.connect(self.cache_path, timeout=0.25)) as conn:
                    row = conn.execute('SELECT retry_at FROM catalog_cooldown_v2 WHERE host=?', (host,)).fetchone()
                    if row:
                        return row[0] - self.clock()
            except (OSError, sqlite3.Error):
                pass
        return self.catalog_retry_at - self.clock() if host == getattr(self, '_cooldown_host', '') else 0

    def _remember_catalog_delay(self, retry_after, host='goyabu.io'):
        now = self.clock()
        try:
            wait = int(retry_after)
        except (TypeError, ValueError):
            try:
                wait = parsedate_to_datetime(retry_after).timestamp() - now
            except (TypeError, ValueError, OverflowError):
                wait = 30
        self.catalog_retry_at = now + max(1, min(wait, 3600))
        self._cooldown_host = host
        if self.cache_path:
            try:
                os.makedirs(os.path.dirname(self.cache_path), exist_ok=True)
                with closing(sqlite3.connect(self.cache_path, timeout=0.25)) as conn, conn:
                    conn.execute('CREATE TABLE IF NOT EXISTS catalog_cooldown_v2(host TEXT PRIMARY KEY, retry_at REAL)')
                    conn.execute('INSERT OR REPLACE INTO catalog_cooldown_v2 VALUES(?,?)', (host, self.catalog_retry_at))
            except (OSError, sqlite3.Error):
                pass

    def clear_catalog(self):
        if not self.cache_path or not os.path.isfile(self.cache_path):
            return True
        try:
            with closing(sqlite3.connect(self.cache_path, timeout=0.25)) as conn, conn:
                conn.execute('CREATE TABLE IF NOT EXISTS pages(url TEXT PRIMARY KEY,body TEXT,expires REAL)')
                conn.execute('DELETE FROM pages')
            return True
        except (OSError, sqlite3.Error):
            return False

    def _cached(self, url):
        if not self.cache_path:
            return None
        try:
            with closing(sqlite3.connect(self.cache_path, timeout=0.25)) as conn:
                row = conn.execute('SELECT body, expires FROM pages WHERE url=?', (url,)).fetchone()
                return row[0] if row and row[1] > self.clock() else None
        except (OSError, sqlite3.Error):
            return None

    def _save(self, url, body, ttl):
        if not self.cache_path or len(body.encode('utf-8')) > 512 * 1024:
            return
        try:
            os.makedirs(os.path.dirname(self.cache_path), exist_ok=True)
            with closing(sqlite3.connect(self.cache_path, timeout=0.25)) as conn:
                conn.execute('CREATE TABLE IF NOT EXISTS pages(url TEXT PRIMARY KEY,body TEXT,expires REAL)')
                conn.execute('DELETE FROM pages WHERE expires <= ?', (self.clock(),))
                conn.execute('INSERT OR REPLACE INTO pages VALUES(?,?,?)', (url, body, self.clock() + ttl))
                # Limit actual retained bytes as well as page count.
                while True:
                    count, size = conn.execute('SELECT count(*),coalesce(sum(length(CAST(body AS BLOB))),0) FROM pages').fetchone()
                    if count <= 64 and size <= 8 * 1024 * 1024:
                        break
                    conn.execute('DELETE FROM pages WHERE url=(SELECT url FROM pages ORDER BY expires LIMIT 1)')
                conn.commit()
        except (OSError, sqlite3.Error):
            pass  # Cache opcional: armazenamento indisponível não impede navegar.

    def get(self, url, post=None, referer=None, headers=None, ttl=0):
        headers = dict(headers or {})
        headers.setdefault('User-Agent', USER_AGENT)
        headers.setdefault('Accept', 'text/html,application/json')
        headers.setdefault('Accept-Encoding', 'gzip, deflate')
        if referer:
            headers['Referer'] = referer
        parts = urllib.parse.urlsplit(url)
        # The call site cannot accidentally cache a player, token, RPC or POST.
        eligible = self.cache_enabled and ttl > 0 and post is None and not referer and catalog_page(parts)
        self.final_url = url
        start = time.monotonic()
        self.last_request = {'cache': 'miss'}
        cached = self._cached(url) if eligible else None
        if cached is not None:
            self.last_request = {'cache': 'hit', 'elapsed_ms': 0}
            return cached
        if eligible and self._catalog_delay(parts.hostname) > 0:
            self.last_request = {'cache': 'miss', 'status': 429, 'elapsed_ms': 0}
            raise HTTPError(url, 429, 'Catálogo temporariamente limitado', {}, None)
        data = urllib.parse.urlencode(post).encode() if post is not None else None
        request = urllib.request.Request(url, data=data, headers=headers)
        try:
            response = self.opener.open(request, timeout=self.timeout)
        except HTTPError as error:
            error_headers = error.headers or {}
            self.last_request.update({
                'status': error.code,
                'elapsed_ms': int((time.monotonic() - start) * 1000),
                'redirecionamento': 'sim' if error.geturl() != url else 'não observado',
                'sinal Cloudflare': 'presente' if error_headers.get('CF-Ray') else 'ausente',
                'desafio Cloudflare': 'confirmado' if
                    error_headers.get('CF-Mitigated', '').lower() == 'challenge' else 'não indicado',
            })
            if eligible and error.code == 429:
                self._remember_catalog_delay(error.headers.get('Retry-After') if error.headers else None, parts.hostname)
            raise
        with response:
            final = response.geturl() if hasattr(response, 'geturl') else url
            self.final_url = final if isinstance(final, str) else url
            content = response.read(MAX_BODY + 1)
            if len(content) > MAX_BODY:
                raise ValueError('Resposta excedeu o limite')
            encoding = response.headers.get('Content-Encoding', '').lower()
            if encoding in ('gzip', 'deflate'):
                decoder = zlib.decompressobj(16 + zlib.MAX_WBITS if encoding == 'gzip' else zlib.MAX_WBITS)
                content = decoder.decompress(content, MAX_BODY + 1)
                if len(content) > MAX_BODY or decoder.unconsumed_tail:
                    raise ValueError('Resposta descompactada excedeu o limite')
                if not decoder.eof:
                    raise ValueError('Resposta compactada incompleta')
            charset = response.headers.get_content_charset() or 'utf-8'
            body = content.decode(charset, 'replace')
            self.last_request = {'cache': 'miss', 'status': response.status,
                                 'elapsed_ms': int((time.monotonic() - start) * 1000)}
            if eligible and catalog_page(urllib.parse.urlsplit(self.final_url)):
                # Don't retain challenge pages as if they were an empty catalog.
                lower = body[:16384].lower()
                if not any(marker in lower for marker in ('cf-chl-', 'just a moment', 'captcha')):
                    self._save(url, body, min(ttl, self.cache_ttl, 3600))
            return body
