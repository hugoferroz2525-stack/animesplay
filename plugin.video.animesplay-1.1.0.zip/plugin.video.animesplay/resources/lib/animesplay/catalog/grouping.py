import hashlib,re,unicodedata

def group(items):
 groups={}
 for item in items:
  title=AUDIO_MARKERS.sub('',item['title']).strip()
  normalized=''.join(c for c in unicodedata.normalize('NFKD',title.casefold()) if not unicodedata.combining(c))
  key=normalized+'|'+str(item.get('year',''))+'|'+item.get('mediatype','tvshow')
  if key not in groups:groups[key]=dict(item,id=hashlib.sha256(key.encode()).hexdigest(),title=title,variants=[])
  if not any(v['id']==item['id'] for v in groups[key]['variants']):groups[key]['variants'].append(item)
 return list(groups.values())


SOURCE_NAMES = {'goyabu': 'Goyabu', 'animesbr': 'AnimesBR',
                'animesonlinecc': 'AnimesOnlineCC', 'metianimes': 'MetiAnimesOnline'}
AUDIO_NAMES = {'dub': 'Dublado', 'sub': 'Legendado', 'unknown': 'Áudio não informado'}
AUDIO_MARKERS = re.compile(r'(?:\s|\[|\()(dublad[oa]s?|legendad[oa]s?|dub|leg|sub)(?:[\])])?$', re.I)


def edition_audio(item):
    audio = str(item.get('audio') or '').casefold().strip()
    if audio in ('dub', 'dublado', 'dublada', 'pt-br'):
        return 'dub'
    if audio in ('sub', 'leg', 'legendado', 'legendada'):
        return 'sub'
    match = AUDIO_MARKERS.search(item.get('title', ''))
    if not match:
        return 'unknown'
    return 'dub' if match[1].lower().startswith('dub') else 'sub'


def audio_editions(variants):
    editions = {}
    for variant in variants:
        editions.setdefault(edition_audio(variant), []).append(variant)
    return [(kind, editions[kind]) for kind in AUDIO_NAMES if kind in editions]
