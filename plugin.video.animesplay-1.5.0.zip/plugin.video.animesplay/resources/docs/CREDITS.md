Base independente Aurora Anime. Projeto derivado da experiência de revisão do pacote Brazuca fornecido pelo usuário. metadata.py, tmdb_config.py e playback_state.py reaproveitados do Aurora Play. Demais módulos desta base escritos para este projeto. Antes de distribuir componentes adicionais do Brazuca, preservar as licenças de cada arquivo. Não afiliado à Crunchyroll, Kodi ou TMDB.

blogger.py: implementação adaptada do fluxo observado no resolvedor Blogger do Brazuca/Aurora, com validação de estruturas. providers/goyabu.py e catalog.py escritos para este addon.

0.2.2: embed_media.py adaptado do fluxo GenericEmbedResolver e da leitura de candidatos do AnimeSoul 3.0.0 enviado pelo usuário, sob GPL-3.0. Alterações: HTMLParser, preservação dos parâmetros assinados, formatos validados e deduplicação. Licença em LICENSE-AnimeSoul.txt. A alternativa entre decodificação da fonte e embed foi integrada em providers/goyabu.py.

0.2.3: blogger_rpc.py e blogger.py adaptados do trecho de resolvedor AnimeSoul enviado pelo usuário; preservada licença do componente.

0.3.2: revisão do transporte, parsing Goyabu, extração declarativa de mídia, fallback Blogger, diagnósticos e testes. Revisão baseada nos ZIPs fornecidos, com preservação dos créditos anteriores. Não foi incorporado código do addon YouTube.

0.4.0: progresso Kodi, retomada, navegação, cooldown do catálogo e integração de trailers implementados no Aurora com base nas decisões registradas em CONSOLIDACAO-0.4.0.md. A integração de trailers usa a rota pública do addon Kodi YouTube.

0.5.0: o projeto Aurora Anime passa a se chamar AnimeSoul no Kodi. As artes são originais para esta edição. A consolidação das auditorias e o mapa dos módulos estão no LEIA-ME desta pasta.


AnimesPlay 1.1.0 (16/11/2026): resolvedor HTTP Meti, cache de respostas, camada de rotas, integração e artes de menu implementados para esta atualização. Referências inspecionadas nos ZIPs fornecidos: Flix (cache `cached`, `routing`, organização TMDB e configuração de cliente TMDB), Brazuca (hierarquia visual e categorias), YouTube (integração pública de trailers e limites do armazenamento local), Spartan (separação de navegação; seu carregador de código remoto não foi incorporado). As licenças e créditos anteriores foram preservados. Não foi copiado o `tmdb.py` inteiro do Flix nem o código dos resolvedores dos outros addons.

AnimesPlay 1.3.0: imagens de menu obtidas via TMDB; IDs e atribuição em ATUALIZACAO-1.3.0.md.

