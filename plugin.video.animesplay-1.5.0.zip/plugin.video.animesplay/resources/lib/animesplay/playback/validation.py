"""Probe pequeno antes de entregar mídia ao Kodi. Não grava URLs temporárias."""
from urllib.request import Request,urlopen
from urllib.error import HTTPError,URLError
from urllib.parse import urlsplit
class MediaUnavailable(ValueError):
 def __init__(self,message,code='media_unavailable'):
  super().__init__(message);self.code=code

def classify(data,content_type):
 prefix=data.lstrip();lower=prefix[:512].lower();mime=(content_type or '').split(';',1)[0].lower()
 if not data:raise MediaUnavailable('O servidor retornou uma resposta vazia.','empty_body')
 if b'ftyp' in data[:32] or b'styp' in data[:32]:return 'video/mp4'
 if prefix.startswith(b'#EXTM3U'):return 'application/vnd.apple.mpegurl'
 if b'<MPD' in prefix[:512] or b'<mpd' in lower:return 'application/dash+xml'
 if data.startswith(b'\x1aE\xdf\xa3'):return 'video/webm'
 if mime=='text/html' or any(x in lower for x in (b'<!doctype html',b'<html',b'site unavailable')):
  raise MediaUnavailable('O servidor devolveu uma página de indisponibilidade no lugar do vídeo.','html_response')
 if mime.startswith('audio/'):raise MediaUnavailable('O servidor devolveu somente áudio para este episódio.','audio_only')
 if mime.startswith('video/'):return mime
 raise MediaUnavailable('A resposta não pôde ser reconhecida como mídia.','unknown_media')

def probe(stream,opener=None):
 url=stream.get('url','')
 if urlsplit(url).scheme not in ('http','https'):raise MediaUnavailable('Endereço de mídia inválido.')
 headers=dict(stream.get('headers') or {});headers['Range']='bytes=0-2047'
 try:
  open_url=opener.open if opener else urlopen
  try:
   response=open_url(Request(url,headers=headers),timeout=12)
  except HTTPError as error:
   if error.code not in (403,405,416):raise
   error.close();headers.pop('Range',None)
   response=open_url(Request(url,headers=headers),timeout=12)
  with response:
   if response.status not in (200,206):raise MediaUnavailable('Resposta de mídia indisponível.')
   mime=classify(response.read(2048),response.headers.get('Content-Type',''))
 except MediaUnavailable:raise
 except HTTPError as error:raise MediaUnavailable('O servidor de vídeo recusou a mídia (HTTP {}).'.format(error.code),'http_'+str(error.code)) from None
 except (TimeoutError,URLError):raise MediaUnavailable('O servidor de vídeo demorou ou falhou ao conectar.','media_connection') from None
 except Exception:raise MediaUnavailable('Não foi possível acessar a mídia neste momento.') from None
 result=dict(stream,mime=mime)
 if mime=='application/vnd.apple.mpegurl':
  from animesplay.playback.hls import inspect
  try:result.update(inspect(stream,opener))
  except HTTPError as error:raise MediaUnavailable('O servidor recusou a playlist ou segmento HLS (HTTP {}).'.format(error.code),'hls_http_'+str(error.code)) from None
  except (TimeoutError,URLError):raise MediaUnavailable('Falha ao ler playlist ou segmento HLS.','hls_connection') from None
 return result
