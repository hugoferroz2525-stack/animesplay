"""Credencial TMDB somente nas configurações locais do Kodi."""
DEFAULT_API_KEY = ''
