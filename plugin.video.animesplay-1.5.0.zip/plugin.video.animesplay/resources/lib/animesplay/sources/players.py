"""Leitura limitada de players públicos; mantém sessão e assinatura originais."""
import base64
import json
import re
from urllib.parse import urljoin, urlsplit, parse_qs, urlencode
from animesplay.network.client import USER_AGENT
from animesplay.network.html import Tree
from animesplay.playback.validation import MediaUnavailable
from animesplay.sources.embeds import extract, direct, unpack_strings
from animesplay.sources.blogger.resolver import is_embed, resolve as blogger


def stream(url, referer, label='Automático'):
    return {'url': url, 'label': label, 'headers': {'Referer': referer, 'User-Agent': USER_AGENT}}


def resolve(url, client, referer='', depth=0):
    if depth > 4 or urlsplit(url).scheme not in ('http', 'https'):
        return []
    if is_embed(url):
        return blogger(url, client)
    p=urlsplit(url);q=parse_qs(p.query)
    if p.hostname=='api.anivideo.net' and p.path=='/videohls.php' and q.get('d'):
        return [stream(q['d'][0],url)]
    if direct(url):
        return [stream(url,referer)]
    if p.hostname=='aniture.p2pplay.online' and p.fragment:
        endpoint=urljoin(url,'/api/public/resolve')+'?'+urlencode({'file1':p.fragment})
        data=json.loads(client.get(endpoint,referer=url))
        if data.get('url'):return resolve(urljoin(url,data['url']),client,url,depth+1)
        raise MediaUnavailable('O player alternativo não disponibilizou este arquivo.','missing_player_file')
    markup=client.get(url,referer=referer or None)
    match=re.fullmatch(r'/video/([a-fA-F0-9]{32})/?',p.path)
    if match and p.hostname and p.hostname.startswith('embedplayer'):
        endpoint=urljoin(url,'/player/index.php')+'?'+urlencode({'data':match[1],'do':'getVideo'})
        data=json.loads(client.get(endpoint,post={'hash':match[1],'r':referer},referer=url,
                                   headers={'X-Requested-With':'XMLHttpRequest'}))
        # securedLink inclui a assinatura; videoSource pode apontar para um arquivo .txt interno.
        result=[]
        if data.get('securedLink'):result.append(stream(data['securedLink'],url,'VIP HLS'))
        for source in data.get('videoSources',[]):
            if isinstance(source,dict) and source.get('file'):result.append(stream(source['file'],url,source.get('label','VIP')))
        return result
    unpacked=unpack_strings(markup)
    scan=markup+'\n'+unpacked
    found=extract(scan,url)
    for match in re.finditer(r'''\b(?:file|src)\s*:\s*['"](https?://[^'"<>]+)['"]''',scan):
        if direct(match[1]) and not any(s['url']==match[1] for s in found):found.append(stream(match[1],url))
    if found:return [dict(s,headers={**s.get('headers',{}),'User-Agent':USER_AGENT}) for s in found]
    tree=Tree();tree.feed(markup)
    result=[]
    for frame in tree.root.find(lambda n:n.tag=='iframe' and (n.attrs.get('src') or n.attrs.get('data-src'))):
        target=urljoin(url,frame.attrs.get('src') or frame.attrs.get('data-src'))
        if any(x in target for x in ('doubleclick','googlesyndication','youtube.com','facebook.com')):continue
        try:result.extend(resolve(target,client,url,depth+1))
        except (OSError,ValueError):continue
    return result
