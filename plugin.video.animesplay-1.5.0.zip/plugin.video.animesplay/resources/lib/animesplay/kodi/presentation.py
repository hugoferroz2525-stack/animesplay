import html,re,unicodedata
def text(value):
 value=html.unescape(str(value or ''));value=re.sub('<[^>]+>','',value)
 return unicodedata.normalize('NFC',value.replace('\\n','\n').replace('\u200b','').replace('\ufeff','')).strip()
def latin(value):return bool(text(value)) and not re.search('[\u3000-\u9fff\uac00-\ud7af]',text(value))
def episode_name(item):
 value=text(item.get('episode_title') or item.get('title') or item.get('showtitle'))
 value=re.sub(r'(?i)^\s*(?:EP|epis[oó]dio)\s*\d+\s*(?:[—–:-]\s*)?(?:\d+\s*min\s*)?','',value)
 value=re.sub(r'(?i)\s+(?:epis[oó]dio\s*\d+\s*(?:T\d+)?\s*)?\d{2}-\d{2}-\d{4}\s*(?:\d+\s*min)?\s*$','',value)
 return ' '.join(value.split()) or text(item.get('showtitle')) or 'Episódio'
def episode_label(item):
 number=item.get('episode')
 if not isinstance(number,int):
  match=re.search(r'(?i)(?:epis[oó]dio|\bEP)\s*(\d+)',str(item.get('title','')));number=int(match[1]) if match else 0
 return '[B] EPISÓDIO {:02d}:[/B] [COLOR yellow]{}[/COLOR]'.format(number,episode_name(item))
