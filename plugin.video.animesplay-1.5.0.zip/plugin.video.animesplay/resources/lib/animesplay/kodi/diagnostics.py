"""Goyabu navigation diagnostics."""
from pathlib import Path

import xbmc
import xbmcgui


def record(profile, action, status, trace, items=None):
    import xbmc
    # Do not include URLs, search terms, headers or upstream response text.
    fields = [('Etapa', action), ('Resultado', status)]
    for key in ('status', 'cache', 'elapsed_ms', 'redirecionamento', 'sinal Cloudflare', 'desafio Cloudflare'):
        if key in trace:
            fields.append((key, trace[key]))
    if items is not None:
        fields.append(('Itens reconhecidos', items))
    report = '\n'.join('{}: {}'.format(key, value) for key, value in fields)
    xbmc.log('[AnimesPlay/Goyabu] ' + report.replace('\n', ' | '),
             getattr(xbmc,'LOGDEBUG',xbmc.LOGINFO) if status == 'ok' else xbmc.LOGWARNING)
    try:
        (Path(profile) / 'last-goyabu-navigation.txt').write_text(report, encoding='utf-8')
    except OSError:
        pass


def show(profile):
    path = Path(profile) / 'last-goyabu-navigation.txt'
    try:
        report = path.read_text(encoding='utf-8')
    except OSError:
        report = 'Ainda não há diagnóstico. Abra o catálogo ou os lançamentos primeiro.'
    xbmcgui.Dialog().textviewer('Diagnóstico Goyabu', report)


def event(profile, action, status, item=None, trace=None, offset=None, reason=None):
    """Histórico limitado sem endereços, tokens, cookies ou texto bruto de exceções."""
    import json, time, xbmc
    from animesplay.version import BUILD
    from animesplay.kodi.presentation import text
    item=item or {}
    fields={'build':BUILD,'time':int(time.time()),'action':action,'status':status}
    for key in ('provider','season','episode'):
        value=item.get(key)
        if type(value) in (str,int):fields[key]=value
    title=text(item.get('showtitle') or item.get('title') or '')[:160].replace('\n',' ')
    if title:fields['title']=title
    if offset is not None:fields['offset']=offset
    if reason:fields['reason']=reason
    if trace:
        fields['trace']=[{k:v[k] for k in ('stage','status','count','elapsed_ms','reason') if k in v} for v in trace[-40:]]
    path=Path(profile)/'recent-diagnostics.json'
    try:
        previous=json.loads(path.read_text(encoding='utf-8')) if path.exists() else []
        if not isinstance(previous,list):previous=[]
    except (OSError,ValueError):previous=[]
    try:path.write_text(json.dumps((previous+[fields])[-40:],ensure_ascii=False,indent=2),encoding='utf-8')
    except OSError:pass
    last_reason=reason or next((v.get('reason') for v in reversed(trace or []) if v.get('reason')),'')
    message='AnimesPlay '+BUILD+' | '+action+' | '+(title or 'menu')+' | '+status
    if type(item.get('episode')) is int:message+=' | T{} EP{}'.format(item.get('season') or 1,item['episode'])
    if offset is not None:message+=' | offset='+str(offset)
    if last_reason:message+=' | motivo='+str(last_reason)
    xbmc.log(message,xbmc.LOGWARNING if status=='failed' else xbmc.LOGINFO if action in ('play','runtime') else xbmc.LOGDEBUG)


def show_recent(profile):
    import json,xbmcgui
    path=Path(profile)/'recent-diagnostics.json'
    try:
        records=json.loads(path.read_text(encoding='utf-8'));report=json.dumps(records[-15:],ensure_ascii=False,indent=2)
    except (OSError,ValueError):report='Ainda não há registros desta versão. Abra uma lista ou episódio.'
    xbmcgui.Dialog().textviewer('AnimesPlay · diagnóstico recente',report)
