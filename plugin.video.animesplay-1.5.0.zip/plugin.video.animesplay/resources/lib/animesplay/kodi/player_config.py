"""Configuração de reprodução, sem alterar preferências globais do Kodi."""
HLS='application/vnd.apple.mpegurl'
DASH='application/dash+xml'

def configure(item,stream,addon,xbmc,headers):
    mime=stream['mime'];item.setMimeType(mime);item.setContentLookup(False)
    adaptive=mime==DASH or (mime==HLS and addon.getSetting('hls_player')=='1')
    if adaptive:
        if not xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
            from animesplay.playback.validation import MediaUnavailable
            raise MediaUnavailable('Ative InputStream Adaptive para este formato.','missing_inputstream')
        item.setProperty('inputstream','inputstream.adaptive')
        if headers:
            item.setProperty('inputstream.adaptive.stream_headers',headers)
            item.setProperty('inputstream.adaptive.manifest_headers',headers)
    return 'adaptive' if adaptive else 'native'
