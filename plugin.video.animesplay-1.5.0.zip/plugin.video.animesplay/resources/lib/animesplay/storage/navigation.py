"""Referências locais estáveis para URLs compactas do Kodi."""
import hashlib,json,os,re,sqlite3
from contextlib import closing
class Navigation:
 def __init__(self,profile):
  os.makedirs(profile,exist_ok=True);self.path=os.path.join(profile,'navigation.db')
 def put(self,item):
  payload=json.dumps(item,ensure_ascii=False,sort_keys=True,separators=(',',':'));key=hashlib.sha256(payload.encode()).hexdigest()[:24]
  with closing(sqlite3.connect(self.path,timeout=3)) as c,c:
   c.execute('CREATE TABLE IF NOT EXISTS items(key TEXT PRIMARY KEY,payload TEXT)');c.execute('INSERT OR IGNORE INTO items VALUES(?,?)',(key,payload))
  return key
 def get(self,key):
  if not re.fullmatch('[a-f0-9]{24}',key):raise ValueError('Referência inválida.')
  try:
   with closing(sqlite3.connect(self.path,timeout=3)) as c:row=c.execute('SELECT payload FROM items WHERE key=?',(key,)).fetchone()
  except sqlite3.Error:raise ValueError('Atalho indisponível. Abra novamente a lista de episódios.') from None
  if not row:raise ValueError('Atalho indisponível. Abra novamente o anime pelo catálogo.')
  return json.loads(row[0])
