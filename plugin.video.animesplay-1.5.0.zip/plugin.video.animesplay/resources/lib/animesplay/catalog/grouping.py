import hashlib,re,unicodedata

def group(items):
 groups={}
 flattened=[]
 for value in items:
  if value.get('variants'):
   shared={k:value[k] for k in ('tmdb_id','art','plot','year','_tmdb_title') if k in value}
   flattened.extend(dict(v,**shared) for v in value['variants'])
  else:flattened.append(value)
 for item in flattened:
  title=AUDIO_MARKERS.sub('',item['title']).strip()
  normalized=''.join(c for c in unicodedata.normalize('NFKD',title.casefold()) if c.isalnum() and not unicodedata.combining(c))
  key=('tmdb:'+str(item['tmdb_id']) if item.get('tmdb_id') else normalized)+'|'+item.get('mediatype','tvshow')
  if item.get('landing_episode'):key+='|s{}e{}'.format(item.get('season_hint') or item.get('season',1),item.get('episode',0))
  if key not in groups:groups[key]=dict(item,id=hashlib.sha256(key.encode()).hexdigest(),title=item.get('_tmdb_title') or title,variants=[])
  if not any(v['id']==item['id'] for v in groups[key]['variants']):groups[key]['variants'].append(item)
 return list(groups.values())


SOURCE_NAMES = {'goyabu': 'Goyabu', 'animesbr': 'AnimesBR',
                'animesonlinecc': 'AnimesOnlineCC', 'metianimes': 'MetiAnimesOnline', 'digital':'AnimesDigital', 'sushi':'SushiAnimes', 'aniture':'AniTure', 'onlines':'AnimesOnlines'}
AUDIO_NAMES = {'dub': 'Dublado', 'sub': 'Legendado', 'unknown': 'Áudio não informado'}
AUDIO_MARKERS = re.compile(r'(?:\s|\[|\()(dublad[oa]s?|legendad[oa]s?|dub|leg|sub)(?:[\])])?$', re.I)


def edition_audio(item):
    audio = str(item.get('audio') or '').casefold().strip()
    if audio in ('dub', 'dublado', 'dublada', 'pt-br'):
        return 'dub'
    if audio in ('sub', 'leg', 'legendado', 'legendada'):
        return 'sub'
    match = AUDIO_MARKERS.search(item.get('title', ''))
    if not match:
        return 'unknown'
    return 'dub' if match[1].lower().startswith('dub') else 'sub'


def audio_editions(variants):
    editions = {}
    for variant in variants:
        editions.setdefault(edition_audio(variant), []).append(variant)
    return [(kind, editions[kind]) for kind in AUDIO_NAMES if kind in editions]
