"""Descritores de fontes já agrupadas na obra escolhida; nunca contém mídia ou credenciais."""
import unicodedata
from urllib.parse import urlsplit
from animesplay.catalog.grouping import AUDIO_MARKERS
FIELDS=('id','url','title','provider','audio','season_hint','tmdb_id','year','mediatype','landing_episode')
HOSTS={'metianimes':'metianimesonline.org','goyabu':'goyabu.io','digital':'animesdigital.org','sushi':'sushianimes.com.br','aniture':'aniture-pt.com.br','onlines':'animesonlines.cc'}
def descriptor(value):return {k:value[k] for k in FIELDS if k in value}
def name(value):
    return ''.join(c for c in unicodedata.normalize('NFKD',AUDIO_MARKERS.sub('',value or '').casefold()) if c.isalnum() and not unicodedata.combining(c))
def compatible(primary,other):
    try:
        url=urlsplit(other['url'])
        if url.scheme!='https' or url.hostname!=HOSTS.get(other.get('provider')) or url.username or url.password:return False
        if primary.get('tmdb_id') and other.get('tmdb_id'):return str(primary['tmdb_id'])==str(other['tmdb_id'])
        if primary.get('year') and other.get('year') and str(primary['year'])!=str(other['year']):return False
        return bool(name(primary.get('showtitle') or primary.get('title'))) and name(primary.get('showtitle') or primary.get('title'))==name(other.get('title'))
    except (ValueError,KeyError,TypeError):return False
