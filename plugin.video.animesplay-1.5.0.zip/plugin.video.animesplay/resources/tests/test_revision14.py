import sys,json,unittest,tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock
from urllib.error import HTTPError
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'lib'))
from animesplay.playback.failover import Failover
from animesplay.playback.engine import PlaybackCancelled
from animesplay.playback.validation import MediaUnavailable
from animesplay.sources.websites import Sushi

class Revision14(unittest.TestCase):
 def test_sushi_srcdoc_resolves_official_declared_media(self):
  c=Mock();c.get.return_value='<iframe srcdoc="&lt;script&gt;window.playerEmbed=&quot;https://cdn.example/video.mp4?token=secret&quot;;&lt;/script&gt;"></iframe>'
  s=Sushi(c);s.token='csrf';m=s.resolve({'url':s.base+'episode'},{'id':'1'})[0]
  self.assertTrue(m['url'].endswith('token=secret'))
  self.assertEqual(m['headers']['Referer'],s.base)
  self.assertEqual(m['headers']['Origin'],s.base.rstrip('/'))
 def test_srcdoc_does_not_evaluate_javascript_or_accept_non_media(self):
  c=Mock();c.get.return_value='<iframe srcdoc="&lt;script&gt;window.playerEmbed=&quot;javascript:evil()&quot;;&lt;/script&gt;"></iframe>'
  s=Sushi(c);s.token='csrf';self.assertEqual(s.resolve({'url':s.base+'ep'},{'id':'1'}),[])
 def fixture(self,ep_audio='dub',ep_season=1,tmdb=1,duplicate=False):
  primary=SimpleNamespace();alternate=SimpleNamespace(search=Mock(return_value=[{'id':'show','url':'https://other/show','title':'Anime Dublado'}]))
  episode={'url':'https://other/ep','episode':1,'season':ep_season,'audio':ep_audio}
  alternate.episodes=Mock(return_value=[episode,dict(episode,url='https://other/ep2')] if duplicate else [episode])
  e=SimpleNamespace(show=Mock(return_value={'tmdb_id':1,'title':'Anime','_tmdb_title':'Anime'}),shows=Mock(return_value=[{'tmdb_id':tmdb,'url':'https://other/show','id':'show','title':'Anime Dublado','audio':'dub'}]))
  calls=[]
  def factory(adapter):
   engine=SimpleNamespace(adapter=adapter,trace=[])
   def play(item,**kwargs):
    calls.append(item)
    if adapter is primary:raise MediaUnavailable('403','http_403')
    engine.trace=[{'stage':'media_validation','status':'ok'}];return {'url':'https://cdn/media.mp4','mime':'video/mp4'}
   engine.play=play;return engine
  f=Failover({'aniture':primary,'sushi':alternate},e,engine_factory=factory)
  item={'provider':'aniture','url':'https://primary/ep','show_url':'https://primary/show','showtitle':'Anime Dublado','season':1,'episode':1,'audio':'dub'}
  return f,item,calls,alternate
 def test_failover_plays_same_episode_and_audio(self):
  f,item,calls,_=self.fixture();self.assertEqual(f.play(item)['mime'],'video/mp4')
  self.assertEqual(f.selected_episode['provider'],'sushi');self.assertEqual(calls[-1]['audio'],'dub')
  self.assertNotIn('https://',json.dumps(f.trace))
 def test_wrong_audio_season_or_identity_are_never_played(self):
  for kwargs in ({'ep_audio':'sub'},{'ep_season':2},{'tmdb':2},{'duplicate':True}):
   with self.subTest(kwargs=kwargs):
    f,item,calls,_=self.fixture(**kwargs)
    with self.assertRaises(MediaUnavailable):f.play(item)
    self.assertEqual(len(calls),1)
 def test_manual_choice_and_disabled_setting_do_not_switch_servers(self):
  for choice,enabled in [('manual',True),('auto',False)]:
   f,item,calls,other=self.fixture();f.enabled=enabled
   with self.assertRaises(MediaUnavailable):f.play(item,choice=choice)
   other.search.assert_not_called()
 def test_unknown_audio_does_not_guess(self):
  f,item,calls,other=self.fixture();item.pop('audio');item['showtitle']='Anime'
  with self.assertRaises(MediaUnavailable):f.play(item)
  other.search.assert_not_called()
 def test_cancel_does_not_consult_another_server(self):
  f,item,calls,other=self.fixture()
  with self.assertRaises(PlaybackCancelled):f.play(item,cancelled=lambda:True)
  other.search.assert_not_called()
 def test_parent_season_hint_matches_resets_only_episode_season(self):
  f,item,calls,other=self.fixture();item['season']=2
  f.enricher.shows.return_value[0]['season_hint']=2
  self.assertEqual(f.play(item)['mime'],'video/mp4');self.assertEqual(calls[-1]['season'],2)
 def test_goyabu_latest_parses_episode_from_episode_badge(self):
  from animesplay.sources.goyabu import Adapter
  c=Mock();c.get.return_value='<article class="boxEP"><a href="https://goyabu.io/123"><span class="title">Anime 2</span><span class="ep-type">Episódio 07</span></a></article>'
  self.assertEqual(Adapter(c).latest()[0]['episode'],7)

 def test_no_bundled_tmdb_credential(self):
  from animesplay.metadata.config import DEFAULT_API_KEY
  self.assertEqual(DEFAULT_API_KEY,'')
 def test_missing_tmdb_credential_does_not_make_unauthenticated_requests(self):
  from animesplay.metadata.tmdb import API
  with tempfile.TemporaryDirectory() as profile:
   self.assertEqual(API(profile,'').get('search/tv',{'query':'Anime'}),{})
