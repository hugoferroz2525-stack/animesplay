import sys,tempfile,unittest,json
from pathlib import Path
from unittest.mock import Mock,patch
from urllib.error import HTTPError
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'lib'))
from animesplay.storage.navigation import Navigation
from animesplay.catalog.grouping import group
from animesplay.kodi.presentation import episode_label,latin
from animesplay.metadata.enrichment import Enricher
from animesplay.metadata.tmdb import API
from animesplay.playback.validation import probe
from animesplay.sources.websites import Sushi,Aniture,Onlines

class Revision13(unittest.TestCase):
 def test_navigation_survives_restart_and_preserves_unicode(self):
  with tempfile.TemporaryDirectory() as p:
   value={'title':'Ação','plot':'private synopsis','url':'https://example.org/a'}
   key=Navigation(p).put(value)
   self.assertEqual(len(key),24);self.assertNotIn('private',key)
   self.assertEqual(Navigation(p).get(key),value)
   with self.assertRaises(ValueError):Navigation(p).get('../bad')
 def test_group_preserves_tmdb_art_and_distinct_episode(self):
  a={'id':'a','title':'Black Clover','tmdb_id':1,'art':{'poster':'poster'},'plot':'plot','landing_episode':True,'episode':1,'variants':[{'id':'a','title':'Black Clover','episode':1,'landing_episode':True}]}
  b={'id':'b','title':'Black Clover','tmdb_id':1,'episode':2,'landing_episode':True}
  rows=group([a,b]);self.assertEqual(len(rows),2)
  self.assertEqual(rows[0]['art'],a['art']);self.assertEqual(rows[0]['plot'],'plot')
 def test_verified_season_merges_but_preserves_edition_number(self):
  with tempfile.TemporaryDirectory() as p:
   e=Enricher(p,'token');e.api=Mock()
   e.api.get.side_effect=lambda path,params=None: {'results':[{'id':1,'name':'Black Clover','genre_ids':[16]}]} if path=='search/tv' else {'id':1,'name':'Black Clover','seasons':[{'season_number':1},{'season_number':2}]}
   a=e.show({'id':'a','url':'https://a','title':'Black Clover 2'})
   b=e.show({'id':'b','url':'https://b','title':'Black Clover'})
   self.assertEqual(a['season_hint'],2);rows=group([a,b]);self.assertEqual(len(rows),1)
   self.assertEqual(rows[0]['variants'][0]['season_hint'],2)
 def test_sequel_with_own_exact_identity_stays_separate(self):
  with tempfile.TemporaryDirectory() as p:
   e=Enricher(p,'token');e.api=Mock()
   e.api.get.side_effect=lambda path,params=None: {'results':[{'id':2,'name':'Anime 2','genre_ids':[16]}]} if path=='search/tv' else {'id':2,'name':'Anime 2'}
   a=e.show({'id':'a','url':'https://a','title':'Anime 2'})
   self.assertNotIn('season_hint',a)
   self.assertEqual(len(group([a,{'id':'b','title':'Anime','tmdb_id':1}])),2)
 def test_person_uses_official_latin_alias(self):
  with tempfile.TemporaryDirectory() as p:
   api=API(p,'token');api.get=Mock(return_value={'name':'日本語','also_known_as':['Taro Yamada']})
   d={'credits':{'crew':[{'id':1,'name':'日本語','department':'Writing'}]}}
   api.readable_credits(d);self.assertEqual(d['credits']['crew'][0]['name'],'Taro Yamada')
   self.assertTrue(latin('Ação'));self.assertFalse(latin('日本語'))
 def test_episode_format_cleans_site_dates_and_duration(self):
  label=episode_label({'episode':7,'title':'EP 7 24 min A promessa 10-10-2017'})
  self.assertEqual(label,'[B] EPISÓDIO 07:[/B] [COLOR yellow]A promessa[/COLOR]')
 def test_sushi_title_is_not_resolution_badge(self):
  rows=Sushi(Mock()).cards('<a href="/anime/black-clover-12"><div>HD</div><div class="list-title">Black Clover</div></a>')
  self.assertEqual(rows[0]['title'],'Black Clover')
 def test_wordpress_pagination_uses_page_path(self):
  self.assertEqual(Aniture(Mock()).archive('episodios/',2),'https://aniture-pt.com.br/episodios/page/2/')
  self.assertEqual(Onlines(Mock()).archive('ultimos-episodios/',3),'https://animesonlines.cc/ultimos-episodios/?ep_pg=3')
 def test_probe_retries_without_rejected_range(self):
  response=Mock(status=200,headers={'Content-Type':'video/mp4'});response.read.return_value=b'0000ftypisom';response.__enter__=Mock(return_value=response);response.__exit__=Mock(return_value=False)
  opener=Mock();opener.open.side_effect=[HTTPError('https://cdn/a',416,'range',{},None),response]
  self.assertEqual(probe({'url':'https://cdn/a'},opener)['mime'],'video/mp4')
  self.assertNotIn('Range',dict(opener.open.call_args.args[0].header_items()))

 def test_sushi_split_card_combines_image_and_real_title(self):
  html='<a href="/anime/black-clover-12" class="list-media"><div>HD</div><div data-src="/poster.jpg"></div></a><a href="/anime/black-clover-12" class="list-title">Black Clover</a><a href="/anime/black-clover-12" class="list-category">Ação</a>'
  rows=Sushi(Mock()).cards(html)
  self.assertEqual(rows[0]['title'],'Black Clover');self.assertTrue(rows[0]['icon'].endswith('poster.jpg'))
