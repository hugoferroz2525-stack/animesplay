import sys,unittest,tempfile,json,importlib
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock,patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'lib'))
from animesplay.playback.hls import inspect
from animesplay.playback.validation import MediaUnavailable
from animesplay.kodi.player_config import configure,HLS,DASH
from animesplay.storage.navigation import Navigation

def ts():return (b'G'+bytes(187))*4
class Response:
 def __init__(self,url,data):self.url=url;self.data=data;self.status=200;self.headers={}
 def __enter__(self):return self
 def __exit__(self,*args):pass
 def geturl(self):return self.url
 def read(self,n):return self.data[:n]
def opener(mapping):
 def read(req,**kwargs):return Response(req.full_url,mapping[req.full_url])
 return SimpleNamespace(open=Mock(side_effect=read))
class Revision15(unittest.TestCase):
 def test_hls_checks_separate_video_audio_and_opaque_segment_names(self):
  root='https://cdn.example/master.m3u8'
  files={root:b'#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="a",DEFAULT=YES,URI="audio.m3u8"\n#EXT-X-STREAM-INF:BANDWIDTH=100,RESOLUTION=1280x720,AUDIO="a"\nvideo.m3u8', 'https://cdn.example/video.m3u8':b'#EXTM3U\n#EXTINF:6,\nfile.txt\n#EXT-X-ENDLIST', 'https://cdn.example/file.txt':ts(), 'https://cdn.example/audio.m3u8':b'#EXTM3U\n#EXTINF:6,\naudio.txt\n#EXT-X-ENDLIST', 'https://cdn.example/audio.txt':b'\xff\xf1'+bytes(200)}
  result=inspect({'url':root},opener(files));self.assertFalse(result['is_live']);self.assertTrue(result['audio_checked']);self.assertEqual(result['container'],'mpegts')
 def test_manifest_success_does_not_hide_bad_segment(self):
  base='https://cdn.example/a.m3u8';op=opener({base:b'#EXTM3U\n#EXTINF:6,\nx\n#EXT-X-ENDLIST','https://cdn.example/x':b'<html>Denied</html>'})
  with self.assertRaises(MediaUnavailable) as cm:inspect({'url':base},op)
  self.assertEqual(cm.exception.code,'hls_html')
 def test_hls_without_endlist_is_live(self):
  base='https://cdn.example/a.m3u8';op=opener({base:b'#EXTM3U\n#EXTINF:6,\nx','https://cdn.example/x':ts()})
  self.assertTrue(inspect({'url':base},op)['is_live'])
 def test_hls_does_not_forward_authorization_to_other_host(self):
  base='https://a.example/a.m3u8';op=opener({base:b'#EXTM3U\n#EXTINF:6,\nhttps://b.example/x\n#EXT-X-ENDLIST','https://b.example/x':ts()})
  inspect({'url':base,'headers':{'Cookie':'private','Authorization':'private'}},op)
  self.assertFalse(any(k.lower() in ('cookie','authorization') for k,v in op.open.call_args.args[0].header_items()))
 def test_circular_hls_is_rejected(self):
  base='https://cdn.example/a.m3u8';op=opener({base:b'#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1\na.m3u8'})
  with self.assertRaises(MediaUnavailable):inspect({'url':base},op)
 def test_native_hls_default_and_adaptive_opt_in(self):
  addon=Mock();xbmc=Mock();item=Mock();addon.getSetting.return_value='0'
  self.assertEqual(configure(item,{'mime':HLS},addon,xbmc,'Referer=x'),'native');item.setProperty.assert_not_called()
  addon.getSetting.return_value='1';self.assertEqual(configure(item,{'mime':HLS},addon,xbmc,'h'),'adaptive')
  self.assertIn(('inputstream','inputstream.adaptive'),[c.args for c in item.setProperty.call_args_list])
 def test_dash_still_requires_adaptive(self):
  addon=Mock();addon.getSetting.return_value='0';xbmc=Mock();xbmc.getCondVisibility.return_value=False
  with self.assertRaises(MediaUnavailable):configure(Mock(),{'mime':DASH},addon,xbmc,'')
 def test_three_pages_reuse_persisted_episode_snapshot(self):
  modules={n:Mock() for n in ('xbmc','xbmcaddon','xbmcgui','xbmcplugin','xbmcvfs')}
  with patch.dict(sys.modules,modules):
   from animesplay.kodi.plugin import Plugin
   with tempfile.TemporaryDirectory() as profile:
    p=Plugin.__new__(Plugin);p.profile=profile;p.navigation=Navigation(profile);p.enricher=SimpleNamespace(show=lambda v:v,episodes=lambda parent,items:items);p.listing=Mock();p.row=Mock()
    source=Mock();source.episodes.return_value=[{'id':str(i),'url':'https://e/'+str(i),'episode':i+1,'title':'EP','audio':'dub','mediatype':'episode'} for i in range(100)]
    p.adapter=lambda v:source;p.args={'item':json.dumps({'url':'https://show','provider':'metianimes','title':'Anime','audio':'dub'})}
    with patch('animesplay.kodi.plugin.saved_records',return_value={}):
     for offset in (0,24,48):
      if offset:p.args={'item':json.dumps(p.row.call_args.kwargs['item']),'offset':str(offset)}
      p.episodes()
      self.assertEqual(p.listing.call_args.args[0][0]['episode'],offset+1)
    source.episodes.assert_called_once()
 def test_diagnostic_contains_episode_and_reason_without_urls(self):
  xbmc=Mock()
  with patch.dict(sys.modules,{'xbmc':xbmc}):
   from animesplay.kodi import diagnostics
   with tempfile.TemporaryDirectory() as profile:
    diagnostics.event(profile,'play','failed',{'showtitle':'Pokémon','episode':1,'provider':'aniture','url':'https://secret.invalid'},trace=[{'stage':'media_validation','reason':'http_403','url':'https://secret.invalid'}])
    data=Path(profile,'recent-diagnostics.json').read_text();self.assertIn('Pokémon',data);self.assertIn('http_403',data);self.assertNotIn('secret.invalid',data)
 def test_resume_waits_for_stable_duration_and_live_does_not_resume(self):
  stub=SimpleNamespace(Player=object,getCondVisibility=lambda _:True)
  with patch.dict(sys.modules,{'xbmc':stub,'xbmcaddon':Mock(),'xbmcgui':Mock(),'xbmcvfs':Mock()}):
   sys.modules.pop('animesplay.kodi.progress',None);mod=importlib.import_module('animesplay.kodi.progress')
   p=mod.EpisodePlayer(Mock(),Mock());p.seekTime=Mock();p.resume_target=856;p.resume_duration=None
   self.assertTrue(p.resume_if_ready(('k',{},1,1342)));p.seekTime.assert_not_called()
   self.assertTrue(p.resume_if_ready(('k',{},3,1342)));p.seekTime.assert_called_once_with(856)
   self.assertFalse(p.resume_if_ready(('k',{},4,1342)))
 def test_resume_does_not_override_user_seek(self):
  stub=SimpleNamespace(Player=object,getCondVisibility=lambda _:True)
  with patch.dict(sys.modules,{'xbmc':stub,'xbmcaddon':Mock(),'xbmcgui':Mock(),'xbmcvfs':Mock()}):
   sys.modules.pop('animesplay.kodi.progress',None);mod=importlib.import_module('animesplay.kodi.progress');p=mod.EpisodePlayer(Mock(),Mock());p.seekTime=Mock();p.resume_target=856
   self.assertFalse(p.resume_if_ready(('k',{},60,1342)));p.seekTime.assert_not_called()
 def test_linked_servers_work_without_tmdb_request(self):
  from animesplay.playback.failover import Failover
  primary=SimpleNamespace();alternate=SimpleNamespace(episodes=Mock(return_value=[{'url':'https://sushianimes.com.br/anime/pokemon-1-season-1-episode','episode':1,'season':1,'audio':'dub'}]))
  engines=[]
  def factory(source):
   e=SimpleNamespace(adapter=source,trace=[])
   def play(item,**kwargs):
    if source is primary:raise MediaUnavailable('Refused')
    e.trace=[{'stage':'media_validation','status':'ok'}];return {'mime':'video/mp4','url':'https://cdn.example/video.mp4'}
   e.play=play;return e
  enricher=Mock();enricher.show.side_effect=AssertionError('TMDB not needed for linked editions')
  parent={'title':'Pokémon Dublado','provider':'sushi','audio':'dub','url':'https://sushianimes.com.br/anime/pokemon-dublado'}
  item={'provider':'aniture','title':'EP1','showtitle':'Pokémon Dublado','season':1,'episode':1,'audio':'dub','_alternate_parents':[parent]}
  f=Failover({'aniture':primary,'sushi':alternate},enricher,engine_factory=factory)
  self.assertEqual(f.play(item)['mime'],'video/mp4');enricher.show.assert_not_called()
 def test_linked_descriptors_reject_different_year_and_strip_secrets(self):
  from animesplay.catalog.linked import compatible
  from animesplay.storage.history import public_episode
  parent={'title':'Anime Dublado','provider':'sushi','url':'https://sushianimes.com.br/anime/anime','year':2024,'headers':{'Cookie':'secret'}}
  self.assertFalse(compatible({'showtitle':'Anime','year':1997},parent))
  safe=public_episode({'id':'ep','_alternate_parents':[parent]})
  self.assertNotIn('secret',json.dumps(safe))
 def test_linked_parents_remain_available_on_later_episode_pages(self):
  # Parent payload is stored as a reference alongside the page snapshot, preserving related sources.
  with tempfile.TemporaryDirectory() as profile:
   n=Navigation(profile);value={'url':'https://metianimesonline.org/anime/pokemon','_alternate_parents':[{'url':'https://aniture-pt.com.br/animes-e-desenhos/pokemon','provider':'aniture'}]}
   key=n.put(value);self.assertEqual(n.get(key)['_alternate_parents'],value['_alternate_parents'])
