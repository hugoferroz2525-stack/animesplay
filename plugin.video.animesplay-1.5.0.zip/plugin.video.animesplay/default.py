"""Dispatch AnimesPlay routes declared by Kodi."""
import runpy
import sys
from pathlib import Path
from urllib.parse import parse_qsl, urlsplit

RESOURCES = Path(__file__).resolve().parent / 'resources'


def goyabu(query):
    sys.path.insert(0, str(RESOURCES / 'lib'))
    from animesplay.kodi.routes import dispatch
    try:
        dispatch(query)
    except Exception as error:
        # Includes initialization/route failures before Plugin.run starts.
        import xbmcaddon,xbmcgui,xbmcplugin,xbmcvfs,traceback
        from animesplay.kodi.diagnostics import event
        addon=xbmcaddon.Addon('plugin.video.animesplay')
        profile=str(Path(xbmcvfs.translatePath(addon.getAddonInfo('profile')))/'painel-goyabu')
        frames=traceback.extract_tb(error.__traceback__)
        origin=Path(frames[-1].filename).name+':'+str(frames[-1].lineno) if frames else 'startup'
        event(profile,query.get('action','home'),'failed',reason=type(error).__name__+' at '+origin)
        xbmcgui.Dialog().ok('AnimesPlay','Falha ao abrir a rota. O motivo e a versão foram registrados no diagnóstico recente.')
        if query.get('action') in ('play','autoplay'):
            xbmcplugin.setResolvedUrl(int(sys.argv[1]),False,xbmcgui.ListItem())
        else:xbmcplugin.endOfDirectory(int(sys.argv[1]),succeeded=False)
        addon=None


def main():
    query = dict(parse_qsl(sys.argv[2].lstrip('?'), keep_blank_values=True)) if len(sys.argv) > 2 else {}
    path=urlsplit(sys.argv[0]).path.strip('/').split('/')
    if urlsplit(sys.argv[0]).scheme == 'plugin' and path and path[0]:
        query.update(section='goyabu',action=path[0])
        if len(path)>1:query['key']=path[1]
    if not query or query.get('section') == 'goyabu':
        goyabu(query)
        return
    try:
        runpy.run_path(str(RESOURCES / 'legacy/animesbr.py'), init_globals={
            'PLUGIN_URL': 'plugin://plugin.video.animesplay/',
            'ROUTE_PARAMS': query,
        }, run_name='__main__')
    except ModuleNotFoundError as error:
        if error.name != 'fasthttp':
            raise
        goyabu({})


if __name__ == '__main__':
    main()
