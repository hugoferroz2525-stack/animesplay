import json
import logging
import sys
from urllib.parse import parse_qs, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from scraper import Resolver
from catalogo_multisite import listar_episodios, pesquisar, resolver_servidores


EPISODE = 'https://www.hinatasoul.com/videos/381293'
LOCAL = 'http://127.0.0.1:18743/videos/381293'


class KodiLog(logging.Handler):
    def emit(self, record):
        xbmc.log('AniPlayTest: ' + self.format(record), xbmc.LOGINFO)


def entrada(handle, titulo, rota, fontes=None, pasta=True):
    params = {'source': rota}
    if fontes is not None:
        params['fontes'] = json.dumps(fontes, ensure_ascii=False)
    item = xbmcgui.ListItem(label=titulo)
    if not pasta:
        item.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(handle, sys.argv[0] + '?' + urlencode(params),
                                item, isFolder=pasta)


def run():
    handle = int(sys.argv[1])
    params = parse_qs(sys.argv[2].lstrip('?'))
    target = params.get('source', [''])[0]
    fontes = json.loads(params.get('fontes', ['[]'])[0])
    if target in ('buscar', 'catalogo'):
        termo = xbmcgui.Dialog().input('Buscar anime').strip() if target == 'buscar' else ''
        if termo or target == 'catalogo':
            grupos, erros = pesquisar(termo or None, timeout=8)
            for grupo in grupos:
                entrada(handle, grupo.titulo, 'episodios', grupo.fontes)
            if erros:
                xbmcgui.Dialog().notification('Fontes indisponíveis', ', '.join(erros))
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return
    if target == 'episodios':
        grupos, erros = listar_episodios(fontes)
        for grupo in grupos:
            entrada(handle, grupo['titulo'], 'servidores', grupo['fontes'])
        if erros:
            xbmcgui.Dialog().notification('Fontes indisponíveis', ', '.join(erros))
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return
    if target == 'servidores':
        entrada(handle, 'Automático', 'reproduzir', fontes, pasta=False)
        for numero, fonte in enumerate(fontes, 1):
            entrada(handle, 'Servidor {} · {}'.format(numero, fonte['site']),
                    'reproduzir', [fonte], pasta=False)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return
    if target == 'reproduzir':
        video = resolver_servidores(fontes)
        item = xbmcgui.ListItem(label=video[0], path=video[1]) if video else xbmcgui.ListItem()
        xbmcplugin.setResolvedUrl(handle, bool(video), item)
        return
    if not target:
        entrada(handle, 'Animes em destaque', 'catalogo')
        entrada(handle, 'Buscar anime', 'buscar')
        for key, title in (('local', 'Vídeo de teste local'), ('live', 'HinataSoul — episódio 381293')):
            item = xbmcgui.ListItem(label=title)
            item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle, sys.argv[0] + '?' + urlencode({'source': key}),
                                        item, isFolder=False)
        xbmcplugin.endOfDirectory(handle)
        return
    if target not in ('local', 'live'):
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    logger = logging.getLogger('scraper')
    logger.setLevel(logging.INFO)
    logger.addHandler(KodiLog())
    result = Resolver(timeout=12).find_stream(LOCAL if target == 'local' else EPISODE)
    xbmc.log('AniPlayTest: source={} resolved={}'.format(target, bool(result)), xbmc.LOGINFO)
    item = xbmcgui.ListItem(label=result['title'], path=result['stream']) if result else xbmcgui.ListItem()
    xbmcplugin.setResolvedUrl(handle, bool(result), item)


run()
