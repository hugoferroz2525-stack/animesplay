"""Alternativas verificadas do mesmo episódio; preserva áudio e identidade TMDB."""
from urllib.error import HTTPError, URLError
from animesplay.catalog.grouping import group, edition_audio
from animesplay.playback.engine import Engine, PlaybackCancelled
from animesplay.playback.validation import MediaUnavailable

class Failover:
    def __init__(self,sources,enricher,engine_factory=Engine,enabled=True):
        self.sources=sources;self.enricher=enricher;self.engine_factory=engine_factory
        self.enabled=enabled;self.trace=[];self.selected_episode=None

    def alternatives(self,item,cancelled):
        number=item.get('episode');season=item.get('season',1);audio=edition_audio(item)
        if audio=='unknown':audio=edition_audio({'title':item.get('showtitle','')})
        if type(number) is not int or number<1 or type(season) is not int or audio=='unknown':return
        if not item.get('show_url') or not item.get('showtitle'):return
        parent=self.enricher.show({'id':item['show_url'],'url':item['show_url'],'title':item['showtitle'],'mediatype':'tvshow'})
        identity=parent.get('tmdb_id')
        if not identity:return
        query=parent.get('_tmdb_title') or parent['title']
        seen={item.get('url')}
        order=('sushi','digital','metianimes','goyabu','aniture','onlines')
        for provider in order:
            if provider==item.get('provider') or provider not in self.sources:continue
            if cancelled():raise PlaybackCancelled()
            source=self.sources[provider]
            try:
                shows=self.enricher.shows(group(source.search(query,1)))
                for show in shows:
                    if show.get('tmdb_id')!=identity:continue
                    for variant in show.get('variants',[show]):
                        variant_audio=edition_audio(variant)
                        # Unknown audio is accepted only by the adapter which validates its API language.
                        if variant_audio!=audio and not (provider=='metianimes' and variant_audio=='unknown'):continue
                        parent=dict(variant,audio=audio)
                        if cancelled():raise PlaybackCancelled()
                        episodes=source.episodes(parent)
                        matches=[]
                        for ep in episodes:
                            effective_season=ep.get('season',1)
                            if effective_season==1 and parent.get('season_hint'):effective_season=parent['season_hint']
                            ep_audio=edition_audio(ep)
                            if ep.get('episode')!=number or effective_season!=season:continue
                            if ep_audio not in (audio,'unknown'):continue
                            if ep.get('url') in seen:continue
                            matches.append(dict(ep,season=effective_season,audio=audio,provider=provider))
                        # Two entries with the same coordinates and audio are ambiguous.
                        unique={ep['url']:ep for ep in matches}
                        if len(unique)==1:
                            ep=next(iter(unique.values()));seen.add(ep['url']);yield ep
            except (OSError,ValueError,KeyError):continue

    def play(self,item,choice='auto',select=None,cancelled=None,accept=None,progress=None):
        cancelled=cancelled or (lambda:False);self.trace=[];last=None
        if cancelled():raise PlaybackCancelled()
        def attempt(episode,selected_choice,selected_select):
            engine=self.engine_factory(self.sources[episode.get('provider','goyabu')])
            engine.adapter.progress=progress
            try:
                media=engine.play(episode,choice=selected_choice,select=selected_select,cancelled=cancelled,accept=accept)
                self.selected_episode=episode;return media
            finally:self.trace.extend(engine.trace)
        try:return attempt(item,choice,select)
        except (MediaUnavailable,HTTPError,URLError) as error:last=error
        if not self.enabled or choice!='auto':raise last
        if cancelled():raise PlaybackCancelled()
        try:
            candidates=self.alternatives(item,cancelled)
            for index,episode in enumerate(candidates,1):
                if index>4:break
                if cancelled():raise PlaybackCancelled()
                if progress:progress(10,'Servidor indisponível. Tentando alternativa {}...'.format(index))
                self.trace.append({'stage':'alternate_server','status':'trying','count':index})
                try:return attempt(episode,'auto',None)
                except (MediaUnavailable,HTTPError,URLError) as error:last=error
        except (OSError,ValueError,KeyError):pass
        if isinstance(last,MediaUnavailable):raise last
        raise MediaUnavailable('Os servidores consultados recusaram este episódio.','all_servers_unavailable')
