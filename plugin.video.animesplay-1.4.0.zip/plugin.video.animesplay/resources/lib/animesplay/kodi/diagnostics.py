"""Goyabu navigation diagnostics."""
from pathlib import Path

import xbmc
import xbmcgui


def record(profile, action, status, trace, items=None):
    import xbmc
    # Do not include URLs, search terms, headers or upstream response text.
    fields = [('Etapa', action), ('Resultado', status)]
    for key in ('status', 'cache', 'elapsed_ms', 'redirecionamento', 'sinal Cloudflare', 'desafio Cloudflare'):
        if key in trace:
            fields.append((key, trace[key]))
    if items is not None:
        fields.append(('Itens reconhecidos', items))
    report = '\n'.join('{}: {}'.format(key, value) for key, value in fields)
    xbmc.log('[AnimesPlay/Goyabu] ' + report.replace('\n', ' | '),
             getattr(xbmc,'LOGDEBUG',xbmc.LOGINFO) if status == 'ok' else xbmc.LOGWARNING)
    try:
        (Path(profile) / 'last-goyabu-navigation.txt').write_text(report, encoding='utf-8')
    except OSError:
        pass


def show(profile):
    path = Path(profile) / 'last-goyabu-navigation.txt'
    try:
        report = path.read_text(encoding='utf-8')
    except OSError:
        report = 'Ainda não há diagnóstico. Abra o catálogo ou os lançamentos primeiro.'
    xbmcgui.Dialog().textviewer('Diagnóstico Goyabu', report)
