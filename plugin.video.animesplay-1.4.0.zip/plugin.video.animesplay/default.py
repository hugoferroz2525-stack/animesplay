"""Dispatch AnimesPlay routes declared by Kodi."""
import runpy
import sys
from pathlib import Path
from urllib.parse import parse_qsl, urlsplit

RESOURCES = Path(__file__).resolve().parent / 'resources'


def goyabu(query):
    sys.path.insert(0, str(RESOURCES / 'lib'))
    from animesplay.kodi.routes import dispatch
    dispatch(query)


def main():
    query = dict(parse_qsl(sys.argv[2].lstrip('?'), keep_blank_values=True)) if len(sys.argv) > 2 else {}
    path=urlsplit(sys.argv[0]).path.strip('/').split('/')
    if urlsplit(sys.argv[0]).scheme == 'plugin' and path and path[0]:
        query.update(section='goyabu',action=path[0])
        if len(path)>1:query['key']=path[1]
    if not query or query.get('section') == 'goyabu':
        goyabu(query)
        return
    try:
        runpy.run_path(str(RESOURCES / 'legacy/animesbr.py'), init_globals={
            'PLUGIN_URL': 'plugin://plugin.video.animesplay/',
            'ROUTE_PARAMS': query,
        }, run_name='__main__')
    except ModuleNotFoundError as error:
        if error.name != 'fasthttp':
            raise
        goyabu({})


if __name__ == '__main__':
    main()
