from aniplay import videotag
from functools import lru_cache
from contextlib import closing
import os
import sys
import xbmcgui
import xbmcplugin
from source import recent_searches
from urllib.parse import urlencode
from aniplay.runtime import root, cache, handle, action, addon
from aniplay.titles import show_title

@lru_cache(maxsize=1)
def playback_progress():
    from aniplay.storage.history import History
    from aniplay.runtime import profile
    with closing(History(profile).connect()) as db:
        return {url:(position,duration,watched) for url,position,duration,watched in
                db.execute('SELECT id,position,duration,watched FROM episodes')}


def yellow(s):
    return '[COLOR FFFFD32D]' + str(s) + '[/COLOR]'

def rated(name, data):
    return name + ('  ' + yellow('★ %.1f' % data['vote_average']) if data.get('vote_average') and (data.get('vote_count') or 'vote_count' not in data) else '')

listed = 0
pending_items = []

def flush():
    if pending_items:
        xbmcplugin.addDirectoryItems(handle,pending_items,len(pending_items))
        pending_items.clear()


def configure_actions(li, route, params, details, data, label, thumb, fan):
    context = []
    if route == 'show':
        command = 'unfavorite' if action == 'favorites' else 'favorite'
        args = dict(action=command,url=params['url'],title=details['title'],art=thumb)
        address = sys.argv[0]+'?'+urlencode(args)
        caption = 'Remover da minha lista' if command=='unfavorite' else 'Salvar na minha lista'
        identify = sys.argv[0]+'?'+urlencode(dict(action='identify',url=params['url'],title=data.get('name') or (params or {}).get('episode_title') or (params or {}).get('title') or label))
        context.extend([(caption,'RunPlugin('+address+')'),('Identificar no TMDB','RunPlugin('+identify+')')])
    def command_url(command, **values):
        return sys.argv[0]+'?'+urlencode(dict(action=command,**values))
    if route == 'show':
        values=dict(url=params['url'],title=data.get('name') or (params or {}).get('episode_title') or (params or {}).get('title') or label,art=thumb,plot=details['plot'])
        for caption,command,method in [('Elenco','cast','Container.Update'),('Títulos semelhantes','similar','Container.Update'),('Trailer','trailer','RunPlugin'),('Exportar para a biblioteca do Kodi','export','RunPlugin')]:
            context.extend([(caption,method+'('+command_url(command,**values)+')')])
    if route == 'query' and params:
        context.extend([('Editar esta busca','RunPlugin('+command_url('edit_term',term=params['term'])+')'),('Apagar esta busca','RunPlugin('+command_url('delete_term',term=params['term'])+')')])
    if route in ('play','episodes') and params and params.get('showid'):
        values={k:params[k] for k in ('showid','season','local') if params.get(k) != '' and k in params}
        if route=='episodes' or 'local' in values:
            context.extend([('Trailer','RunPlugin('+command_url('trailer',**values)+')')])
    if route == 'play':
        values=dict(params,plot=details['plot'],fan=fan)
        caption = 'Informações do filme' if params.get('movie_id') else 'Informações do episódio'
        context.extend([(caption,'RunPlugin('+command_url('episode_info',**values)+')')])
        if params.get('movie_id'):
            context.append(('Trailer', 'RunPlugin('+command_url('trailer',movie_id=params['movie_id'])+')'))
        edit_url = sys.argv[0]+'?'+urlencode(dict(action='opening',url=params['url']))
        context.extend([('Ajustar abertura deste episódio','RunPlugin('+edit_url+')')])
        progress=playback_progress().get(params['url'])
        if progress:
            position,duration,watched=progress
            tag=li.getVideoInfoTag()
            tag.setPlaycount(int(watched))
            if not watched:
                tag.setResumePoint(position,duration)
        li.setProperty('IsPlayable','true')
    if context:
        li.addContextMenuItems(context)


def item(label, route, params=None, data=None, art='', icon='play', info=None, cast=None, fan=''):
    global listed
    from aniplay.menu_metadata import resolve
    data = resolve(route,params,cache) if data is None else data
    params = params or {}
    fields = dict(info or {})
    title = data.get('name') or params.get('episode_title') or params.get('title') or label
    if route == 'show' and action != 'calendar_day':
        title = show_title(label, data, addon.getSettingBool('original_titles'))
        label = title
    if route == 'play':
        fields = {**videotag.episode_fields(params), **fields}
    if route == 'show' and data.get('media_type') in ('tv', 'movie'):
        fields['mediatype'] = {'tv': 'tvshow', 'movie': 'movie'}[data['media_type']]
    title = fields.pop('title', title)
    if route in ('show', 'play', 'episodes'):
        label = rated(label, data)
    li = xbmcgui.ListItem(label=label, offscreen=True)
    icon_path = os.path.join(root, 'resources', 'icons', icon + '.png')
    details, thumb, fan = videotag.decorate(li, data, title=title, fields=fields, art=art,
                                            fan=fan or data.get('site_fanart') or os.path.join(root, 'fanart.jpg'),
                                            icon=icon_path, cast_override=cast)
    configure_actions(li,route,params,details,data,label,thumb,fan)
    path = sys.argv[0] + '?' + urlencode(dict(action=route, **(params or {})))
    pending_items.append((path,li,route not in ('play','prompt','person_prompt','settings','clear')))
    listed += 1

def search_menu():
    item('Nova busca','prompt',icon='search',info=dict(plot='Digite o título em português, japonês ou inglês.'))
    item('Buscar pessoa','person_prompt',icon='person',info=dict(plot='Buscar artistas e encontrar os animes disponíveis no Bakashi.'))
    terms = recent_searches(cache.user)
    for term in terms:
        item(term,'query',dict(term=term),icon='repeat',info=dict(plot='Repetir a busca por '+term+'.'))
    if terms:
        item('Limpar histórico','clear',icon='clear',info=dict(plot='Abrir a confirmação para apagar as pesquisas deste perfil.'))
