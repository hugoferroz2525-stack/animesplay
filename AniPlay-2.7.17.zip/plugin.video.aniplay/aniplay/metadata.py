import json
import re
from urllib.parse import urlencode
from aniplay.runtime import addon, token, image_base
from aniplay.network import TMDB_HOST
from aniplay.tmdb_match import bakashi_metadata, index, slug, unique_hit, title_variants, dated_hit

def tm(path, db, *, cached_only=False, **params):
    if not token:
        return {}
    headers = {}
    if re.fullmatch(r'[0-9a-fA-F]{32}',token):
        params['api_key'] = token
    else:
        headers['Authorization'] = 'Bearer ' + token
    url = 'https://api.themoviedb.org/3/' + path + '?' + urlencode({'language':addon.getSetting('tmdb_language') or 'pt-BR', **params})
    try:
        return json.loads(db.get(url, headers, 86400 * (addon.getSettingInt('tmdb_days') or 7), json.loads, host=TMDB_HOST, cached_only=cached_only))
    except (ValueError, OSError):
        return {}

def get_image(data, key, size="original"):
    """Adaptado de Flix/lib/tmdb.py."""
    path = data.get(key)
    return image_base + size + path if path else ''


def reference(url, db):
    db.user.execute('CREATE TABLE IF NOT EXISTS tmdb_choice (slug TEXT PRIMARY KEY, kind TEXT, id INTEGER)')
    choice = db.user.execute('SELECT kind,id FROM tmdb_choice WHERE slug=?',(slug(url),)).fetchone()
    return (*choice,None) if choice else index().get(slug(url))


def search(name, db):
    return [h for h in tm('search/multi',db,query=name).get('results',[])
            if h.get('media_type') in ('movie','tv')]


def details(kind, ident, db, full=False, *, cached_only=False):
    params = {}
    if full and kind != 'collection':
        params = dict(append_to_response='credits,images,external_ids,alternative_titles,videos,keywords,content_ratings' if kind=='tv'
                      else 'credits,images,external_ids,alternative_titles,videos,keywords,release_dates',include_image_language='pt,en,null')
    data = tm('%s/%s' % (kind,ident),db,cached_only=cached_only,**params)
    if data:
        data['media_type'] = kind
        if kind == 'movie':
            data.update(name=data.get('title'),original_name=data.get('original_title'),
                        first_air_date=data.get('release_date'))
    return data


def lookup(name, db, url, full=False, year=None):
    ref = reference(url,db)
    if ref:
        return details(ref[0],ref[1],db,full)
    fallback = bakashi_metadata().get(slug(url))
    if fallback:
        return dict(fallback)
    titles = title_variants(name)
    hits = {}
    for title in titles:
        for hit in search(title,db):
            hits[hit['media_type'],hit['id']] = hit
    results = list(hits.values())
    match = dated_hit(titles,results,year) if year else {}
    if not match:
        candidates = {}
        for title in titles:
            hit = unique_hit(title,results)
            if hit:
                candidates[hit['media_type'],hit['id']] = hit
        match = next(iter(candidates.values())) if len(candidates)==1 else {}
    return details(match['media_type'],match['id'],db,full) if match else {}


def trailer_url(videos):
    key = next((v['key'] for v in videos if v.get('site') == 'YouTube'
                and v.get('type') == 'Trailer' and v.get('key')), None)
    return 'plugin://plugin.video.youtube/play/?' + urlencode({'video_id': key}) if key else ''


def generic_title(value):
    return not value or bool(re.fullmatch(r'(?:episódio|episode)\s+\d+', value.strip(), re.I))


def needs_episode_translation(data):
    return any(not data.get(key) for key in ('overview', 'still_path')) or generic_title(data.get('name'))


def merge_episode_translation(data, fallback):
    for key in ('name', 'overview', 'still_path'):
        replace = not data.get(key) or (key == 'name' and generic_title(data.get('name'))
                                        and not generic_title(fallback.get('name')))
        if replace and fallback.get(key):
            data[key] = fallback[key]
    return data


def episode_details(show_id, season, episode, db):
    route = f'tv/{show_id}/season/{season}/episode/{episode}'
    data = tm(route, db, append_to_response='credits,images,external_ids,videos')
    if data.get('id') and needs_episode_translation(data):
        merge_episode_translation(data, tm(route, db, language='en-US'))
    return data


def season_details(ident, number, db, *, cached_only=False):
    route = 'tv/%s/season/%s' % (ident,number)
    season = tm(route,db,append_to_response='credits',cached_only=cached_only)
    episodes = season.get('episodes',[])
    if any(needs_episode_translation(episode) for episode in episodes):
        english = tm(route,db,language='en-US',cached_only=cached_only)
        translated = {episode['id']: episode for episode in english.get('episodes', [])}
        for episode in episodes:
            merge_episode_translation(episode, translated.get(episode['id'], {}))
    return season
