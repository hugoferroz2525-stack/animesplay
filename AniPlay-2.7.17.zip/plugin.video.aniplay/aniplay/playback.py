from aniplay.flix_ui import notification
from aniplay.opening import saved
import xbmc
import xbmcgui
import xbmcplugin
from source import audio_sources
from source import UA, media
from aniplay.tmdb_match import slug
import re
from urllib.parse import urlencode
from aniplay.validation import probe_media
from aniplay.runtime import addon, cache, handle, q
from aniplay.storage.history import History, PENDING, media_key
from aniplay.runtime import profile
import json
from aniplay.data_files import load as load_data
import sys
import time

def skip_mode():
    value = addon.getSetting('skip_mode').strip().lower()
    if value.startswith('deslig'):
        return 'off'
    if value.startswith('auto'):
        return 'auto'
    return 'button'


def resolve_audio(groups, audio, names):
    failures = []
    while True:
        for frame in groups[audio]:
            try:
                stream,markers = media(frame,q['url'],cache)
                mime = probe_media(stream,frame)
                break
            except (OSError,ValueError) as exc:
                reason = getattr(exc, 'code', type(exc).__name__)
                failures.append(reason)
                xbmc.log('AniPlay: fonte %s · %s' % (audio, reason), xbmc.LOGWARNING)
                continue
        else:
            if names:
                choice = xbmcgui.Dialog().select(audio+' indisponível. Tentar outro áudio?',names)
                if choice >= 0:
                    audio = names.pop(choice)
                    continue
            refused = failures and all(code in ('source_denied', 'http_401', 'http_403', 'hls_http_401', 'hls_http_403', 401, 403) for code in failures)
            message = 'O servidor recusou o acesso ao vídeo.' if refused else 'O servidor não entregou um vídeo reproduzível.'
            notification(message, heading='Fonte indisponível', icon='alert')
            xbmcplugin.setResolvedUrl(handle,False,xbmcgui.ListItem())
            return
        break
    return audio,stream,markers,mime,frame


def stream_item(stream, mime, frame):
    li = xbmcgui.ListItem(path=stream+'|'+urlencode({'Referer':frame,'User-Agent':UA,'Accept':'*/*'}))
    if mime == 'application/vnd.apple.mpegurl':
        headers = urlencode({'Referer':frame,'User-Agent':UA,'Accept':'*/*'})
        li.setPath(stream)
        li.setProperty('inputstream','inputstream.adaptive')
        if int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0]) < 21:
            li.setProperty('inputstream.adaptive.manifest_type','hls')
        li.setProperty('inputstream.adaptive.manifest_headers',headers)
        li.setProperty('inputstream.adaptive.stream_headers',headers)
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)
    return li


def play():
    from aniplay.episode_context import restore
    body = cache.get(q['url'])
    groups = audio_sources(body,q['url'])
    if not groups:
        raise ValueError('Este episódio está sem player disponível.')
    names = list(groups)
    show_key = slug(q['show_url']) if q.get('show_url') else re.sub(r'-[0-9]+-episodio-.*$', '',slug(q['url']))
    remember = addon.getSettingBool('remember_audio')
    cache.user.execute('CREATE TABLE IF NOT EXISTS audio_preferences (anime TEXT PRIMARY KEY, audio TEXT)')
    preferred = cache.user.execute('SELECT audio FROM audio_preferences WHERE anime=?',(show_key,)).fetchone() if remember else None
    if len(names)>1:
        choice = xbmcgui.Dialog().select('Como quer assistir?',names,preselect=names.index(preferred[0]) if preferred and preferred[0] in names else -1)
        if choice < 0:
            xbmcplugin.setResolvedUrl(handle,False,xbmcgui.ListItem())
            return
    else:
        choice = 0

    audio = names.pop(choice)
    resolved=resolve_audio(groups,audio,names)
    if not resolved:
        return
    audio,stream,markers,mime,frame=resolved
    snapshot = {}
    try:
        snapshot = restore(q)
    except (OSError, ValueError, KeyError):
        xbmc.log('AniPlay: metadados do episódio indisponíveis', xbmc.LOGWARNING)
    notification(audio,'Áudio selecionado','dub' if 'dubl' in audio.lower() else 'sub')
    li=stream_item(stream,mime,frame)
    episode = dict(id=q['url'], url=q['url'], title=q.get('title') or q['url'].split('/')[-1],
                   icon=q.get('art',''), audio=audio)
    episode.update({k:q[k] for k in ('showid','season','local','raw','movie_id','show_url','show_title','episode_title') if q.get(k)})
    offset = History(profile).resume(episode['id'])
    if offset:
        choice = xbmcgui.Dialog().select('Reprodução', [
            'Continuar de %d:%02d' % divmod(int(offset),60), 'Ver desde o início'])
        if choice < 0:
            xbmcplugin.setResolvedUrl(handle,False,xbmcgui.ListItem())
            return
        if choice == 1:
            offset = 0
    from aniplay.subtitles import attach
    attach(li, q, addon, profile)
    markers = saved(cache.user,q['url']) or markers
    mode = skip_mode()
    intervals = []
    if markers and mode != 'off' and 0 <= markers[0] < markers[1]:
        intervals.append(('op', *markers))
    pending = dict(skip_enabled=mode != 'off',skip_mode=mode,keys=[media_key(stream), media_key(sys.argv[0]+sys.argv[2])],
                   expires=time.time()+120, item=episode, resume=offset, skip=intervals)
    if mode != 'off':
        ids = load_data('aniskip-ids.json')
        show_id = q.get('showid','')
        absolute_id = ids.get(show_id+'/absolute')
        mal = absolute_id or ids.get(show_id+'/'+q.get('season',''))
        number = q.get('raw' if absolute_id else 'local','')
        if mal and number.isdigit():
            pending['aniskip'] = [mal,int(number)]
            pending['allowed'] = ['op'] + (['ed'] if addon.getSettingBool('skip_end') else [])
    if remember:
        with cache.user:
            cache.user.execute('INSERT OR REPLACE INTO audio_preferences VALUES (?,?)',(show_key,audio))
    from aniplay import videotag
    data = snapshot.get('data', {})
    title = data.get('name') or q.get('episode_title') or q.get('title') or episode['title']
    videotag.decorate(li, data, title=title, fields=videotag.episode_fields(q),
                     art=q.get('art', ''), fan=snapshot.get('fan', ''),
                     cast_override=snapshot.get('cast'))
    xbmcgui.Window(10000).setProperty(PENDING,json.dumps(pending))
    xbmcplugin.setResolvedUrl(handle,True,li)
    return
