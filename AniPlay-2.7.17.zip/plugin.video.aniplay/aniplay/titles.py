"""Rótulos para o Kodi. O número publicado continua separado do número do TMDB."""
import re


def show_title(site, data, original=False):
    title = (data.get('original_name') if original else None) or data.get('name') or site
    edition = re.search(r'\b(dublad[oa]|legendad[oa]|director.s cut|versão do diretor)\b', site, re.I)
    if edition and edition[0].casefold() not in title.casefold():
        title += ' · ' + edition[0]
    return title


def season_title(number, name, fallback):
    if fallback in ('Especiais', 'Filmes', 'Filme', 'Coleção', 'Outros episódios'):
        return fallback
    base = f'Temporada {number}'
    generic = not name or re.fullmatch(r'(?:temporada|season)\s*\d+', name.strip(), re.I)
    return base if generic else f'{base} · {name}'


def episode_title(number, title, series=''):
    title = (title or '').strip()
    number = str(number or '')
    if number.isdigit():
        number = f'{int(number):02d}'
    heading = f'Episódio {number}' if number else ''
    if heading and re.fullmatch(r'(?:episódio|episode)\s+\d+', title, re.I):
        title = ''
    return ' · '.join(part for part in (series, heading, title) if part)
