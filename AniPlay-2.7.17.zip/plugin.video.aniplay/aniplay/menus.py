from datetime import datetime

HOME = [
    ('Continuar assistindo','continue','resume','Retome os episódios que você interrompeu.'),
    ('Assistidos','watched','watched','Reveja os episódios que você concluiu.'),
    ('Minha lista','favorites','favorites','Abra os animes que você salvou pelo menu de contexto.'),
    ('Histórico de reprodução','recent','history','Volte aos últimos episódios que começaram a tocar.'),
    ('Lançamentos','latest','latest','Veja os episódios publicados recentemente pelo Bakashi.'),
    ('Catálogo completo','catalog','all','Explore o catálogo de animes, página por página.'),
    ('Em alta no Bakashi','trending','trending','Animações japonesas disponíveis no Bakashi por popularidade no TMDB.'),
    ('Explorar por filtro','filters','filters','Escolha gênero, formato, ano ou situação de lançamento.'),
    ('Buscar e ver histórico','search','search','Procure um anime pelo nome ou repita uma busca anterior.'),
    ('Calendário de lançamentos','calendar','calendar','Consulte a programação por dia no horário do seu dispositivo.'),
    ('Configurações','settings','settings','Configure metadados, áudio, botão de abertura, biblioteca e cache.'),
]
DAYS = ('Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado','Domingo')


def schedule(days):
    grouped = {}
    for entries in days.values():
        for entry in entries:
            if not entry.get('airing_at'):
                continue
            when = datetime.fromtimestamp(entry['airing_at'])
            grouped.setdefault(when.date(),{})[(when,entry['title'],entry['episode'])] = entry
    return grouped
