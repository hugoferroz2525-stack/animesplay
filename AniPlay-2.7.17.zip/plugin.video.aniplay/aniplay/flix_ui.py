"""Utilidades adaptadas de Flix/lib/tmdb.py e lib/api/flix/kodi.py (MIT)."""
from pathlib import Path
import xbmcgui

ART = Path(__file__).resolve().parent.parent / 'resources' / 'icons'


def notification(message, heading='AniPlay', icon='play', time=3500, sound=False):
    xbmcgui.Dialog().notification('[COLOR FFFFD32D]'+heading+'[/COLOR]',message,str(ART/(icon+'.png')),time,sound)


def get_cast(cast):
    return [dict(name=c.get('name',''),role=c.get('character',''),
                 thumbnail='https://image.tmdb.org/t/p/w342'+c['profile_path'] if c.get('profile_path') else '',
                 order=i) for i,c in enumerate(cast,1)]


def directors(crew):
    return [c['name'] for c in crew if c.get('job')=='Director']


def writers(crew):
    return list(dict.fromkeys(c['name'] for c in crew if c.get('department')=='Writing' or c.get('job')=='Writer'))
