import logging
import sys
from urllib.parse import parse_qs, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from scraper import Resolver


EPISODE = 'https://www.hinatasoul.com/videos/381293'
LOCAL = 'http://127.0.0.1:18743/videos/381293'


class KodiLog(logging.Handler):
    def emit(self, record):
        xbmc.log('AniPlayTest: ' + self.format(record), xbmc.LOGINFO)


def run():
    handle = int(sys.argv[1])
    target = parse_qs(sys.argv[2].lstrip('?')).get('source', [''])[0]
    if not target:
        for key, title in (('local', 'Vídeo de teste local'), ('live', 'HinataSoul — episódio 381293')):
            item = xbmcgui.ListItem(label=title)
            item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle, sys.argv[0] + '?' + urlencode({'source': key}),
                                        item, isFolder=False)
        xbmcplugin.endOfDirectory(handle)
        return
    if target not in ('local', 'live'):
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    logger = logging.getLogger('scraper')
    logger.setLevel(logging.INFO)
    logger.addHandler(KodiLog())
    result = Resolver(timeout=12).find_stream(LOCAL if target == 'local' else EPISODE)
    xbmc.log('AniPlayTest: source={} resolved={}'.format(target, bool(result)), xbmc.LOGINFO)
    item = xbmcgui.ListItem(label=result['title'], path=result['stream']) if result else xbmcgui.ListItem()
    xbmcplugin.setResolvedUrl(handle, bool(result), item)


run()
