def metadata_numbers(rows, episodes, offset, edition=None):
    """Return the metadata number for each source row, preserving the display number."""
    raw = [int(entry['num']) if entry['num'].isdigit() else None for entry,_ in rows]
    local = [number for _,number in rows]
    if edition is not None:
        return [edition[n-1] if n and 0<n<=len(edition) else None for n in local]
    if not episodes:
        return local
    first = min(episodes)
    numbers = [n for n in raw if n is not None]
    if first > 1:
        if numbers and min(numbers) < first:
            return [first+n-1 if n else None for n in local]
        return raw
    if (offset and numbers and min(numbers)>offset and max(numbers)>max(episodes)
            and all(n-offset in episodes for n in numbers)):
        return [n-offset if n else None for n in raw]
    return local
