"""Busca agrupada e navegação por fonte no AniPlay."""
import json
import re
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
from time import monotonic
from urllib.parse import urlencode, urlsplit

from source import BASE, Cache, cards
from aniplay.flix_ui import notification
from aniplay.metadata import lookup, season_details
from aniplay.network import validate_url
from aniplay.providers.catalog import FONTES, extrair_animes, extrair_episodios
from aniplay.providers.grouping import agrupar_animes
from aniplay.providers.scraper import Document, next_page
from aniplay.runtime import cache, database, profile, q
from aniplay.storage.history import History
from aniplay.titles import clean_text, episode_title, season_title
from aniplay.views import item, yellow

SOURCES = {name: (base, kind) for name, base, kind in (('Bakashi', BASE, 'bakashi'), *FONTES)}
HOSTS = {name: urlsplit(base).hostname for name, (base, _) in SOURCES.items()}
MAX_SEARCH_PAGES = 12
MAX_EPISODE_PAGES = 150


def check_source(site, url):
    if site not in HOSTS:
        raise ValueError('Servidor desconhecido.')
    validate_url(url, HOSTS[site])


def page(db, site, url):
    check_source(site, url)
    return db.get(url, host=HOSTS[site])


def search_source(site, term):
    origin, kind = SOURCES[site]
    query = {'hinata': 'busca', 'anitube': 's', 'bakashi': 'search'}[kind]
    path = '/lista-de-animes' if kind == 'bakashi' else '/busca' if term else '/'
    address = origin + path + ('?' + urlencode({query: term}) if term else '')
    found, visited = [], set()
    deadline = monotonic() + 12
    db = Cache(database)
    try:
        while (address and address not in visited and len(visited) < MAX_SEARCH_PAGES
               and monotonic() < deadline):
            visited.add(address)
            html = page(db, site, address)
            if kind == 'bakashi':
                entries = [(row['name'], row['url'], row['art']) for row in cards(html)]
            else:
                entries = extrair_animes(html, address, kind)
            for name, url, image in entries:
                try:
                    check_source(site, url)
                except ValueError:
                    continue
                if urlsplit(url).path not in ('', '/'):
                    found.append((site, clean_text(name), url, image))
            address = next_page(Document(html).root, address)[0] if term and entries else ''
    except (OSError, ValueError):
        return found, site if not found else ''
    finally:
        db.user.close()
        db.db.close()
    return found, ''


def browse():
    from aniplay.catalog import catalog_metadata

    term = q.get('term', '').strip()
    if not term:
        item('Buscar anime nos servidores', 'prompt', dict(search_route='multi_catalog'), icon='search')
    with ThreadPoolExecutor(max_workers=len(SOURCES)) as workers:
        lists = list(workers.map(lambda site: search_source(site, term), SOURCES))
    groups = agrupar_animes([row for rows, _ in lists for row in rows])
    bakashi = [source for group in groups for source in group.fontes if source['site'] == 'Bakashi']
    metadata = catalog_metadata([{'url': src['url'], 'name': src['title']} for src in bakashi])
    by_url = {src['url']: data for src, data in zip(bakashi, metadata)}
    for group in groups:
        data = next((by_url[src['url']] for src in group.fontes if by_url.get(src['url'])), {})
        art = next((src['imagem'] for src in group.fontes if src['imagem']), '')
        item(group.titulo, 'multi_servers', dict(title=group.titulo, art=art,
             sources=json.dumps(group.fontes, ensure_ascii=False, separators=(',', ':'))), data, art,
             info=dict(title=group.titulo, mediatype='tvshow'))
    unavailable = [site for _, site in lists if site]
    if unavailable:
        notification('Sem resposta de ' + ', '.join(unavailable), 'Catálogo multisservidor', 'alert')
    return bool(groups)


def servers():
    sources = json.loads(q['sources'])
    if not isinstance(sources, list):
        raise ValueError('Lista de servidores inválida.')
    bakashi = ''
    for src in sources:
        if src['site'] == 'Bakashi':
            check_source('Bakashi', src['url'])
            bakashi = src['url']
            break
    counts = {}
    audio = re.search(r'\b(dublad[oa]|legendad[oa]|dub|sub)\s*[\])]?$', q['title'], re.I)
    preferred_audio = ('Dublado' if audio[1].lower().startswith('dub') else 'Legendado') if audio else ''
    for src in sources:
        site, url = src['site'], src['url']
        check_source(site, url)
        counts[site] = counts.get(site, 0) + 1
        label = site if counts[site] == 1 else f'{site} · {counts[site]}'
        art = src.get('imagem') or q.get('art', '')
        if site == 'Bakashi':
            item(label, 'show', dict(url=url, art=art, preferred_audio=preferred_audio, server_entry='1'), {}, art, info=dict(title=label))
        else:
            item(label, 'multi_seasons', dict(site=site, url=url, title=q['title'],
                 source_title=src.get('title', q['title']), bakashi=bakashi, art=art),
                 {}, art, info=dict(title=label))


def episode_numbers(title, url):
    path = urlsplit(url).path
    label = clean_text(title)
    pair = re.search(r'\bS(\d+)\s*E(\d+(?:[.,]\d+)?)\b', label, re.I)
    if not pair:
        pair = re.search(r'(?:^|[/_-])S(\d+)E(\d+(?:[.,]\d+)?)(?:$|[/_-])', path, re.I)
    if pair:
        return int(pair[1]), Decimal(pair[2].replace(',', '.'))
    season = re.search(r'\b(?:temporada|season)\s+(\d+)\b', label, re.I)
    if not season:
        season = re.search(r'/(?:season|temporada)[-/](\d+)(?:/|$)', path, re.I)
    number = re.search(r'\b(?:ep\.?|epis[oó]dio|episode)\s*[-:#]?\s*(\d+(?:[.,]\d+)?)\b', label, re.I)
    if not number:
        number = re.fullmatch(r'(\d+(?:[.,]\d+)?)', label)
    if not number:
        number = re.search(r'[-/](?:ep|episodio|episode)[-/]?(\d+(?:[.,]\d+)?)/?$', path, re.I)
    return (int(season[1]) if season else None,
            Decimal(number[1].replace(',', '.')) if number else None)


def group_episodes(entries, show):
    numbered = [(title, url, art, *episode_numbers(title, url)) for title, url, art in entries]
    official = sorted((row for row in show.get('seasons', []) if row.get('season_number', 0) > 0),
                      key=lambda row: row['season_number'])
    ranges = []
    offset = 0
    for row in official:
        count = row.get('episode_count') or 0
        if not count:
            break
        ranges.append((offset, offset + count, row['season_number']))
        offset += count
    explicit = any(s is not None for _, _, _, s, _ in numbered)
    buckets = {}
    for title, url, art, season, number in numbered:
        local = number
        if season is None and not explicit and number is not None:
            for start, end, mapped in ranges:
                if start < number <= end:
                    season, local = mapped, number - start
                    break
            if season is None and len(ranges) > 1 and number > offset:
                season = -1
        if season is None:
            season = -1 if explicit else 1
        buckets.setdefault(season, []).append((title, url, art, local, number))
    for rows in buckets.values():
        rows.sort(key=lambda row: (row[3] is None, row[3] or 0))
    return dict(sorted(buckets.items(), key=lambda pair: (pair[0] < 0, pair[0])))


def load_episodes(site, url):
    kind = SOURCES[site][1]
    entries, visited = {}, set()
    while url and url not in visited and len(visited) < MAX_EPISODE_PAGES:
        visited.add(url)
        try:
            rows, url, _ = extrair_episodios(page(cache, site, url), url, kind)
        except (OSError, ValueError):
            if not entries:
                raise
            notification('Parte da lista de episódios está indisponível.', site, 'alert')
            break
        for row in rows:
            try:
                check_source(site, row[1])
            except ValueError:
                continue
            entries.setdefault(row[1], row)
    if url and len(visited) == MAX_EPISODE_PAGES:
        notification('A lista atingiu o limite de páginas.', site, 'alert')
    return list(entries.values())


def seasons():
    site, url = q['site'], q['url']
    check_source(site, url)
    if site == 'Bakashi':
        raise ValueError('Selecione o servidor pelo catálogo.')
    bk = q.get('bakashi', '')
    if bk:
        check_source('Bakashi', bk)
    title = q.get('title', '')
    source_title = q.get('source_title', title)
    data = lookup(re.sub(r'\s*[\[(]?(?:dublad[oa]|legendad[oa]|dub|sub)[\])]?\s*$', '', source_title, flags=re.I),
                  cache, bk or url, full=True)
    episodes = group_episodes(load_episodes(site, url), data)
    official = {part['season_number']: part for part in data.get('seasons', [])}
    art = q.get('art', '')
    selected = q.get('season')
    if selected is None:
        watched_urls = History(profile).watched_for_show(url)
        params = {key: value for key, value in q.items() if key != 'action'}
        for number, rows in episodes.items():
            info = official.get(number, {})
            heading = season_title(number, info.get('name'), 'Outros episódios' if number < 0 else '')
            prefix, separator, arc = heading.partition(' · ')
            label = prefix + separator + (yellow(arc) if arc else '')
            total = len(rows)
            watched = sum(row[1] in watched_urls for row in rows)
            item(f'{label} ({total})', 'multi_episodes', dict(params, season=number),
                 info, art, icon='season', info=dict(title=label, sorttitle=heading, mediatype='season',
                 tvshowtitle=title, season=max(0, number)), season_progress=(watched, total))
        return
    number = int(selected)
    show_id = data.get('id') if data.get('media_type') == 'tv' and number >= 0 else None
    tmdb = season_details(show_id, number, cache) if show_id else {}
    details = {entry['episode_number']: entry for entry in tmdb.get('episodes', [])}
    cast = (tmdb.get('credits') or data.get('credits') or {}).get('cast')
    for name, link, thumb, local, raw in episodes.get(number, []):
        if local is not None and local == int(local):
            local = int(local)
        meta = dict(details.get(local, {}))
        if not meta.get('overview') and data.get('overview'):
            meta['overview'] = data['overview']
        suffix = re.search(r'\b(?:ep\.?|epis[oó]dio|episode)\s*[-:#]?\s*\d+(?:[.,]\d+)?\s*[-:·–]\s*(.+)$', name, re.I)
        heading = meta.get('name') or (suffix[1] if suffix else name if local is None else '')
        label = episode_title(local, heading)
        params = dict(url=link, provider=site, show_url=url, show_title=title, title=label, art=thumb or art,
                      episode_title=heading, season=number, raw=raw if raw is not None else '',
                      local=local if local is not None else '')
        if show_id:
            params['showid'] = show_id
        item(label, 'play', params, meta, params['art'], icon='episode', cast=cast)
